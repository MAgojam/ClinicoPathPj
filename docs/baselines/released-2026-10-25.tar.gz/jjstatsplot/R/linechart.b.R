#' @title Line Chart for Time Series and Trend Analysis
#' @description
#' Creates comprehensive line charts for time series analysis and trend visualization
#' in clinical and pathological research. This function supports multiple groups,
#' confidence intervals, trend lines, and statistical overlays, making it ideal for
#' analyzing longitudinal data, treatment responses, and biomarker trends over time.
#'
#' @details
#' The line chart function is designed specifically for clinical research applications
#' where visualization of trends and patterns over time or ordered categories is crucial.
#' It provides extensive customization options and statistical features to create
#' publication-ready plots for clinical studies.
#'
#' Key features:
#' - Multiple group support for comparative analysis
#' - Confidence intervals and trend lines
#' - Clinical color palettes and themes
#' - Reference lines for normal ranges/thresholds
#' - Statistical correlation analysis
#' - Professional publication-ready appearance
#'
#' Common clinical applications:
#' - Laboratory values over time
#' - Treatment response monitoring
#' - Biomarker evolution
#' - Dose-response relationships
#' - Survival probability trends
#' - Quality metrics tracking
#'
#' @examples
#' \dontrun{
#' # Basic time series analysis
#' result <- linechart(
#'   data = patient_data,
#'   xvar = "visit_month",
#'   yvar = "hemoglobin_level"
#' )
#'
#' # Grouped analysis with confidence intervals
#' result <- linechart(
#'   data = treatment_data,
#'   xvar = "time_point",
#'   yvar = "tumor_size",
#'   groupby = "treatment_arm",
#'   confidence = TRUE,
#'   trendline = TRUE
#' )
#'
#' # Clinical monitoring with reference line
#' result <- linechart(
#'   data = lab_data,
#'   xvar = "days_post_treatment",
#'   yvar = "white_blood_cell_count",
#'   refline = 4000,
#'   reflineLabel = "Normal Lower Limit"
#' )
#' }
#'
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @return An \code{R6} class generator object for the \code{linechartClass} backend; used internally by the jamovi analysis wrapper and not called directly.

linechartClass <- if (requireNamespace('jmvcore', quietly=TRUE)) R6::R6Class(
    "linechartClass",
    inherit = linechartBase,
    private = list(

        # Use one explicit formatter for result text so numeric precision is
        # stable regardless of namespace imports or the caller's print options.
        .fmtNum = function(x, digits = 3) {
            if (length(x) != 1 || !is.finite(x)) return("NA")
            formatC(signif(x, digits), format = "fg", flag = "#", digits = digits)
        },

        # Rows dropped during preparation, recorded so .checkDataQuality() can
        # report them in the results panel. warning() only reaches the R console.
        .n_excluded_missing   = 0L,
        .n_excluded_nonfinite = 0L,
        .n_rows_analysed      = 0L,

        # Initialize results and validate dependencies
        .init = function() {
            # Apply user-specified plot dimensions so the Width/Height options
            # actually resize the rendered Image. Bounds come from min/max in
            # linechart.a.yaml: jmvcore's own OptionInteger check rejects an
            # out-of-range value before any code here runs ("width must be
            # between 300 and 1200 (is 5000)"), which is why the module no longer
            # carries its own .validateParameters() - it was unreachable.
            # Dependency checking happens once at runtime in .run() (and again in
            # the separate render phase in .plot()).
            self$results$plot$setSize(self$options$width, self$options$height)

            # The summary table has a fixed row set, so build the skeleton (rowKey
            # + statistic label) here; .populateSummary() then only fills `value`.
            # Group Names is gated on the groupby option - the SAME condition
            # .populateSummary() uses - so every rowKey it sets exists on every
            # path (setRow() on a missing rowKey aborts the analysis).
            summaryTable <- self$results$summary
            summaryTable$addRow(rowKey = "n_obs", values = list(
                statistic = .("Number of Observations")))
            summaryTable$addRow(rowKey = "n_x", values = list(
                statistic = .("Number of X-axis Points")))
            summaryTable$addRow(rowKey = "n_groups", values = list(
                statistic = .("Number of Groups")))
            if (!is.null(self$options$groupby))
                summaryTable$addRow(rowKey = "group_names", values = list(
                    statistic = .("Group Names")))
            summaryTable$addRow(rowKey = "y_mean", values = list(
                statistic = .("Y Mean")))
            summaryTable$addRow(rowKey = "y_median", values = list(
                statistic = .("Y Median")))
            summaryTable$addRow(rowKey = "y_sd", values = list(
                statistic = .("Y Standard Deviation")))
            summaryTable$addRow(rowKey = "y_range", values = list(
                statistic = .("Y Range")))

            # Initialize with enhanced welcome message if no variables selected
            if (is.null(self$options$xvar) || is.null(self$options$yvar)) {
                private$.showWelcomeMessage()

                # Hide results until data is provided
                self$results$naturalSummary$setVisible(FALSE)
                self$results$summary$setVisible(FALSE)
                self$results$correlation$setVisible(FALSE)
                self$results$assumptions$setVisible(FALSE)
                self$results$plot$setVisible(FALSE)
            }
        },

        .run = function() {
            # Two error channels, deliberately. A pre-flight failure - no data at
            # all - cannot produce any results, so it is raised here, OUTSIDE the
            # tryCatch below, and reaches jamovi's own error banner. Every
            # validation reject() inside the pipeline (.cleanData(), and the
            # dependency gate) is caught by .handleError(), which renders it in
            # the `todo` panel together with a concrete recovery suggestion,
            # because those failures are things the user can fix by changing a
            # variable or the data. Both halves are pinned by tests: the empty
            # dataset asserts expect_error(), the in-pipeline ones assert on the
            # panel text. Do not merge them without changing those tests.
            #
            # Early exits for missing data or variables.
            #
            # A bare return() here left the panel completely blank - no welcome
            # text (variables ARE selected, so .init() did not write one) and no
            # explanation. reject() states the reason; setVisible() is reserved
            # for option-driven visibility, not for signalling failure.
            if (is.null(self$data) || nrow(self$data) == 0) {
                if (!is.null(self$options$xvar) && !is.null(self$options$yvar))
                    jmvcore::reject(.("The dataset has no rows, so there is nothing to chart. If a row filter is active, it may be excluding every case."))
                return()
            }

            if (is.null(self$options$xvar) || is.null(self$options$yvar)) {
                return()
            }

            # Hide welcome message and show results
            self$results$todo$setVisible(FALSE)
            self$results$naturalSummary$setVisible(TRUE)
            self$results$summary$setVisible(TRUE)
            self$results$plot$setVisible(TRUE)

            # Reset the notice/instructions Html once per run. .checkDataQuality()
            # appends to this output, so without a reset the same data-quality
            # warnings accumulate (duplicate) across successive run cycles.
            self$results$todo$setContent("")

            # Main analysis pipeline with comprehensive error handling
            tryCatch({
                # Check dependencies at runtime
                private$.checkDependencies()

                # Prepare and validate data
                private$.checkpoint()  # Checkpoint before expensive data cleaning
                data <- private$.cleanData()
                if (is.null(data)) return()

                # Perform misuse detection
                private$.checkDataQuality(data)

                # Calculate summary statistics
                private$.checkpoint()  # Checkpoint before statistical calculations
                summary_stats <- private$.calculateSummary(data)
                private$.populateSummary(summary_stats)

                # Calculate correlation once if trend line requested, then thread
                # the result into the natural-language summary, the correlation
                # table, and the assumptions panel (avoids recomputing cor.test/lm).
                correlation_stats <- NULL
                if (self$options$trendline) {
                    private$.checkpoint()  # Checkpoint before correlation analysis
                    correlation_stats <- private$.calculateCorrelation(data)
                }

                # Generate natural language summary (reuses correlation_stats)
                private$.generateNaturalSummary(summary_stats, data, correlation_stats)

                if (self$options$trendline) {
                    private$.populateCorrelation(correlation_stats)
                    private$.populateAssumptions(data, correlation_stats)
                    self$results$correlation$setVisible(TRUE)
                    self$results$assumptions$setVisible(TRUE)
                } else {
                    self$results$correlation$setVisible(FALSE)
                    self$results$assumptions$setVisible(FALSE)
                }

                # Save plot data for rendering
                private$.savePlotData(data)

            }, error = function(e) {
                private$.handleError(e)
            })
        },

        # Comprehensive data cleaning and validation
        .cleanData = function() {
            # Extract variables
            xvar <- self$options$xvar
            yvar <- self$options$yvar
            groupby <- self$options$groupby

            # Select required columns
            required_vars <- c(xvar, yvar)
            if (!is.null(groupby)) {
                required_vars <- c(required_vars, groupby)
            }

            # Check if variables exist in data
            missing_vars <- setdiff(required_vars, names(self$data))
            if (length(missing_vars) > 0) {
                jmvcore::reject(paste(.("Variables not found in data:"), paste(missing_vars, collapse = ", ")))
            }

            # Select and clean data
            data <- self$data[required_vars]

            # Validate X variable
            x_data <- data[[xvar]]
            if (is.character(x_data)) {
                # Try to convert to factor with meaningful ordering
                unique_values <- unique(x_data)
                if (all(grepl("^[0-9.-]+$", unique_values, perl = TRUE))) {
                    # Looks numeric, convert
                    x_data <- as.numeric(x_data)
                    if (any(is.na(x_data))) {
                        jmvcore::reject(.("X-axis variable contains non-numeric values that cannot be converted."))
                    }
                } else {
                    # Convert to ordered factor
                    x_data <- factor(x_data)
                }
                data[[xvar]] <- x_data
            } else if (is.factor(x_data)) {
                # Check if factor levels are meaningful for ordering
                levels_numeric <- suppressWarnings(as.numeric(levels(x_data)))
                if (!any(is.na(levels_numeric))) {
                    # Reorder factor levels numerically
                    data[[xvar]] <- factor(x_data, levels = levels(x_data)[order(levels_numeric)])
                }
            }

            # Validate Y variable (must be numeric)
            y_data <- jmvcore::toNumeric(data[[yvar]])
            if (!is.numeric(y_data) || all(is.na(y_data))) {
                jmvcore::reject(.("Y-axis variable must be numeric (continuous variable)."))
            }
            data[[yvar]] <- y_data

            # Validate grouping variable if provided
            if (!is.null(groupby)) {
                group_data <- data[[groupby]]
                if (is.character(group_data)) {
                    data[[groupby]] <- factor(group_data)
                } else if (!is.factor(group_data)) {
                    data[[groupby]] <- factor(group_data)
                }

                # A high group count reaches the user through .checkDataQuality()
                # ("Many groups detected ..."), which writes into the results panel.
                # A warning() here only reached the R console, which jamovi never
                # shows, so it was a duplicate of an invisible message.
            }

            # Remove rows with missing values.
            #
            # complete.cases() follows is.na(), which is TRUE for NaN but FALSE for
            # Inf, so infinite values used to survive this filter. They then reached
            # `var(y) == 0` below, where var() returns NaN and `NaN == 0` is NA, so
            # `if (NA)` aborted the run with "missing value where TRUE/FALSE needed"
            # - a message that tells a clinician nothing, under a heading that then
            # advised removing MISSING values, which is not what went wrong.
            complete_before <- nrow(data)
            data <- data[complete.cases(data), , drop = FALSE]

            n_nonfinite <- 0L
            num_cols <- names(data)[vapply(data, is.numeric, logical(1))]
            if (length(num_cols) > 0 && nrow(data) > 0) {
                finite_rows <- Reduce(`&`, lapply(data[num_cols], is.finite))
                n_nonfinite <- sum(!finite_rows)
                if (n_nonfinite > 0)
                    data <- data[finite_rows, , drop = FALSE]
            }
            complete_after <- nrow(data)

            if (complete_after == 0) {
                jmvcore::reject(.("No usable rows remain after removing missing and infinite values. Please check the selected variables."))
            }

            # Record exclusions so they can be shown in the results panel.
            # warning() alone goes to the R console, which the jamovi user never
            # sees, so dropped rows were invisible in the GUI.
            private$.n_excluded_missing  <- complete_before - complete_after - n_nonfinite
            private$.n_excluded_nonfinite <- n_nonfinite
            private$.n_rows_analysed      <- complete_after

            # Enhanced minimum data requirements with suggestions
            if (nrow(data) < 3) {
                jmvcore::reject(.fmt(
                    .("At least 3 complete observations are required for line chart analysis. The current dataset has {n} observation(s). Consider checking for missing values or selecting different variables."),
                    n = nrow(data)))
            }

            # Enhanced variation check with suggestions
            if (var(data[[yvar]], na.rm = TRUE) == 0) {
                jmvcore::reject(.("The Y-axis variable has no variation (all values are identical). Line charts require variation in the Y variable. Please select a different variable with varying values."))
            }

            # (refline is a numeric Number option: no non-numeric validation needed here)

            # CRITICAL FIX: Sort data by x-variable to prevent zig-zag lines
            # For longitudinal data, observations must be ordered by time/sequence
            # to correctly connect points chronologically
            if (!is.null(groupby)) {
                # Sort by grouping variable first, then by x-variable
                # This ensures each group's points are connected in correct order
                data <- data[order(data[[groupby]], data[[xvar]]), ]
            } else {
                # Sort by x-variable only for ungrouped data
                data <- data[order(data[[xvar]]), ]
            }

            return(data)
        },

        # Calculate summary statistics
        .calculateSummary = function(data) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar
            groupby <- self$options$groupby

            summary_stats <- list()

            # Basic data information
            summary_stats$n_observations <- nrow(data)
            summary_stats$n_x_points <- length(unique(data[[xvar]]))

            # Y variable statistics
            y_data <- data[[yvar]]
            summary_stats$y_mean <- mean(y_data, na.rm = TRUE)
            summary_stats$y_median <- median(y_data, na.rm = TRUE)
            summary_stats$y_sd <- sd(y_data, na.rm = TRUE)
            summary_stats$y_min <- min(y_data, na.rm = TRUE)
            summary_stats$y_max <- max(y_data, na.rm = TRUE)
            summary_stats$y_range <- summary_stats$y_max - summary_stats$y_min

            # Group information if applicable
            if (!is.null(groupby)) {
                summary_stats$n_groups <- length(unique(data[[groupby]]))
                summary_stats$group_names <- paste(unique(data[[groupby]]), collapse = ", ")
            } else {
                summary_stats$n_groups <- 1
                summary_stats$group_names <- .("Single group")
            }

            return(summary_stats)
        },

        # Calculate correlation statistics
        .calculateCorrelation = function(data) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar
            groupby <- self$options$groupby

            correlation_stats <- list()

            # CRITICAL FIX: Check for grouped data or repeated measures
            # and provide both naive and adjusted statistics when appropriate
            n_unique_x <- length(unique(data[[xvar]]))
            n_observations <- nrow(data)
            avg_obs_per_x <- n_observations / n_unique_x

            # Flag if likely repeated measures (multiple obs per x-value)
            # TODO (correctness): the > 1.5 threshold is a rough heuristic. A grouped dataset
            #   with one observation per group per time-point can legitimately produce
            #   avg_obs_per_x > 1.5 without being "repeated measures" in the statistical
            #   sense. Consider using a patient/subject ID option (if available) to detect
            #   true within-subject replication, or document the heuristic in the panel.
            has_repeated_measures <- avg_obs_per_x > 1.5  # More than 1.5 obs per x on average

            # No warning() here: the independence caveat reaches the user through
            # correlation_stats$independence_note (the "Statistical Validity" row of
            # the correlation table), through .interpretCorrelation(), and through
            # the Independence bullet in the assumptions panel.
            if (!is.null(groupby)) {
                correlation_stats$has_grouping <- TRUE
            }

            if (has_repeated_measures) {
                # Only naive (independence-assuming) statistics are computed and
                # shown; no patient-level aggregate statistics are produced. The
                # caveat is carried to the user by independence_note and the
                # interpretation columns below, not by warning().
                correlation_stats$has_repeated_measures <- TRUE
            }

            # Overall correlation (if X is numeric)
            x_data <- data[[xvar]]
            y_data <- data[[yvar]]

            if (is.numeric(x_data) && length(unique(x_data)) >= 2) {
                # NAIVE STATISTICS (assume independence - for reference only)
                # Pearson correlation
                cor_result <- cor.test(x_data, y_data, method = "pearson")
                correlation_stats$pearson_r_naive <- cor_result$estimate
                correlation_stats$pearson_p_naive <- cor_result$p.value
                correlation_stats$pearson_ci_lower_naive <- cor_result$conf.int[1]
                correlation_stats$pearson_ci_upper_naive <- cor_result$conf.int[2]

                # Spearman correlation (rank-based)
                # Tied ranks make the exact Spearman test unavailable. Request
                # the asymptotic calculation explicitly in that case so the
                # backend does not emit a console-only warning, and carry the
                # inferential limitation into the visible results table.
                has_spearman_ties <- anyDuplicated(x_data) > 0L ||
                    anyDuplicated(y_data) > 0L
                cor_spearman <- cor.test(
                    x_data,
                    y_data,
                    method = "spearman",
                    exact = if (has_spearman_ties) FALSE else NULL)
                correlation_stats$spearman_r_naive <- cor_spearman$estimate
                correlation_stats$spearman_p_naive <- cor_spearman$p.value
                correlation_stats$spearman_has_ties <- has_spearman_ties

                # Linear regression statistics
                lm_result <- lm(y_data ~ x_data)
                correlation_stats$slope_naive <- coef(lm_result)[2]
                correlation_stats$intercept_naive <- coef(lm_result)[1]
                correlation_stats$r_squared_naive <- summary(lm_result)$r.squared
                correlation_stats$regression_p_naive <- summary(lm_result)$coefficients[2, 4]
                slope_scale <- stats::sd(y_data) / stats::sd(x_data)
                correlation_stats$slope_is_zero <-
                    is.finite(slope_scale) &&
                    abs(correlation_stats$slope_naive) <=
                        sqrt(.Machine$double.eps) * slope_scale

                # Set "display" values - use naive with clear labeling
                correlation_stats$pearson_r <- correlation_stats$pearson_r_naive
                correlation_stats$pearson_p <- correlation_stats$pearson_p_naive
                correlation_stats$pearson_ci_lower <- correlation_stats$pearson_ci_lower_naive
                correlation_stats$pearson_ci_upper <- correlation_stats$pearson_ci_upper_naive
                correlation_stats$spearman_r <- correlation_stats$spearman_r_naive
                correlation_stats$spearman_p <- correlation_stats$spearman_p_naive
                correlation_stats$slope <- correlation_stats$slope_naive
                correlation_stats$intercept <- correlation_stats$intercept_naive
                correlation_stats$r_squared <- correlation_stats$r_squared_naive
                correlation_stats$regression_p <- correlation_stats$regression_p_naive

                # Add methodology note for interpretation
                if (has_repeated_measures || !is.null(groupby)) {
                    correlation_stats$independence_note <-
                        .("IMPORTANT LIMITATION: these statistics assume independent observations. For longitudinal data with repeated measures they may overstate significance. Consider aggregating to patient-level summaries (for example a slope per patient), using mixed-effects models in specialised software, or interpreting the p-values as exploratory descriptives only.")
                }

            } else {
                # For categorical X, calculate trend test if ordered
                if ((is.ordered(x_data) || is.factor(x_data)) && length(unique(x_data)) >= 2) {
                    # Jonckheere-Terpstra trend test would be ideal here
                    # For now, use basic ANOVA
                    anova_result <- anova(lm(y_data ~ x_data))
                    correlation_stats$anova_f <- anova_result$`F value`[1]
                    correlation_stats$anova_p <- anova_result$`Pr(>F)`[1]
                    # An F with no degrees of freedom cannot be interpreted or
                    # reported, so carry both df alongside it.
                    correlation_stats$anova_df1 <- anova_result$Df[1]
                    correlation_stats$anova_df2 <- anova_result$Df[2]
                }
            }

            return(correlation_stats)
        },

        # Populate summary table. Rows are created in .init(); only the `value`
        # cells are written here.
        .populateSummary = function(summary_stats) {
            table <- self$results$summary

            table$setRow(rowKey = "n_obs", values = list(
                value = as.character(summary_stats$n_observations)))

            table$setRow(rowKey = "n_x", values = list(
                value = as.character(summary_stats$n_x_points)))

            table$setRow(rowKey = "n_groups", values = list(
                value = as.character(summary_stats$n_groups)))

            if (!is.null(self$options$groupby))
                table$setRow(rowKey = "group_names", values = list(
                    value = summary_stats$group_names))

            table$setRow(rowKey = "y_mean", values = list(
                value = private$.fmtNum(summary_stats$y_mean)))

            table$setRow(rowKey = "y_median", values = list(
                value = private$.fmtNum(summary_stats$y_median)))

            table$setRow(rowKey = "y_sd", values = list(
                value = private$.fmtNum(summary_stats$y_sd)))

            table$setRow(rowKey = "y_range", values = list(
                value = paste(private$.fmtNum(summary_stats$y_min), "-",
                              private$.fmtNum(summary_stats$y_max))))
        },

        # Enhanced correlation table with copy-ready interpretations
        .populateCorrelation = function(correlation_stats) {
            table <- self$results$correlation
            table$deleteRows()

            row_num <- 1
            
            # Extract flags for repeated measures and grouping
            has_repeated_measures <- isTRUE(correlation_stats$has_repeated_measures)
            has_grouping <- isTRUE(correlation_stats$has_grouping)

            # Pearson correlation with enhanced interpretation
            if (!is.null(correlation_stats$pearson_r)) {
                # Create copy-ready sentence
                copy_ready <- private$.generateCopyReadyCorrelation(correlation_stats)

                table$addRow(rowKey = row_num, values = list(
                    measure = .("Pearson Correlation"),
                    value = correlation_stats$pearson_r,
                    ci_lower = correlation_stats$pearson_ci_lower,
                    ci_upper = correlation_stats$pearson_ci_upper,
                    pvalue = correlation_stats$pearson_p,
                    interpretation = private$.interpretCorrelation(correlation_stats$pearson_r,
                                                                   correlation_stats$pearson_p,
                                                                   has_repeated_measures,
                                                                   has_grouping)
                ))
                row_num <- row_num + 1

                table$addRow(rowKey = row_num, values = list(
                    measure = .("R-squared (Effect Size)"),
                    value = correlation_stats$r_squared,
                    interpretation = .fmt(
                        .("{percent}% of variance explained. {interpretation}"),
                        percent = round(correlation_stats$r_squared * 100, 1),
                        interpretation = private$.interpretEffectSize(correlation_stats$r_squared))
                ))
                row_num <- row_num + 1

                # Enhanced slope interpretation
                slope_is_zero <- isTRUE(correlation_stats$slope_is_zero)
                slope_interpretation <- if (slope_is_zero) {
                    .("No linear trend: The estimated regression slope is effectively zero at numerical precision.")
                } else if (correlation_stats$slope > 0) {
                    .fmt(
                        .("Positive trend: Each unit increase in X corresponds to an average {slope} unit increase in Y."),
                        slope = private$.fmtNum(abs(correlation_stats$slope)))
                } else {
                    .fmt(
                        .("Negative trend: Each unit increase in X corresponds to an average {slope} unit decrease in Y."),
                        slope = private$.fmtNum(abs(correlation_stats$slope)))
                }

                table$addRow(rowKey = row_num, values = list(
                    measure = .("Regression Slope"),
                    value = correlation_stats$slope,
                    pvalue = correlation_stats$regression_p,
                    interpretation = slope_interpretation
                ))
                row_num <- row_num + 1

                # Add copy-ready summary as a special row
                table$addRow(rowKey = row_num, values = list(
                    measure = .("Copy-Ready Summary"),
                    value = "",
                    interpretation = copy_ready
                ))
                row_num <- row_num + 1

                # Add independence assumption warning if applicable
                if (!is.null(correlation_stats$independence_note)) {
                    table$addRow(rowKey = row_num, values = list(
                        measure = .("Statistical Validity"),
                        value = "",
                        interpretation = correlation_stats$independence_note
                    ))
                    row_num <- row_num + 1
                }
            }

            # Spearman correlation with enhanced interpretation
            if (!is.null(correlation_stats$spearman_r)) {
                spearman_note <- if (isTRUE(correlation_stats$spearman_has_ties)) {
                    paste0(
                        " ",
                        .("The p-value uses an asymptotic approximation because tied ranks prevent exact inference."))
                } else {
                    ""
                }
                table$addRow(rowKey = row_num, values = list(
                    measure = .("Spearman Correlation (Rank-based)"),
                    value = correlation_stats$spearman_r,
                    pvalue = correlation_stats$spearman_p,
                    interpretation = paste0(private$.interpretCorrelation(correlation_stats$spearman_r,
                                                                         correlation_stats$spearman_p,
                                                                         has_repeated_measures,
                                                                         has_grouping),
                                          " ", .("This rank-based measure is less sensitive to extreme values than Pearson correlation."),
                                          spearman_note)
                ))
                row_num <- row_num + 1
            }

            # ANOVA for categorical X with enhanced interpretation
            if (!is.null(correlation_stats$anova_f)) {
                anova_interpretation <- if (correlation_stats$anova_p < 0.05) {
                    .("Significant differences between groups were detected (p < 0.05). Post-hoc testing is recommended to identify specific group differences.")
                } else {
                    .("No statistically significant differences between groups were detected (p \u2265 0.05). This result does not establish equivalence between the group means.")
                }

                anova_label <- if (!is.null(correlation_stats$anova_df1)) {
                    .fmt(.("ANOVA F-statistic (df {df1}, {df2})"),
                         df1 = correlation_stats$anova_df1,
                         df2 = correlation_stats$anova_df2)
                } else {
                    .("ANOVA F-statistic")
                }
                table$addRow(rowKey = row_num, values = list(
                    measure = anova_label,
                    value = correlation_stats$anova_f,
                    pvalue = correlation_stats$anova_p,
                    interpretation = anova_interpretation
                ))
            }
        },

        # Generate copy-ready correlation interpretation
        .generateCopyReadyCorrelation = function(correlation_stats) {
            r <- correlation_stats$pearson_r
            p <- correlation_stats$pearson_p
            r_squared <- correlation_stats$r_squared
            
            has_repeated_measures <- isTRUE(correlation_stats$has_repeated_measures)
            has_grouping <- isTRUE(correlation_stats$has_grouping)

            # Determine significance
            sig_level <- if (p < 0.001) "p < 0.001" else if (p < 0.01) "p < 0.01" else paste0("p = ", round(p, 3))
            is_significant <- p < 0.05

            # Build copy-ready sentence
            correlation_is_zero <- isTRUE(all.equal(
                unname(r), 0, tolerance = sqrt(.Machine$double.eps)))
            direction <- if (r > 0) .("positive") else .("negative")
            strength <- private$.correlationStrength(r)

            copy_ready <- if (correlation_is_zero) {
                .fmt(
                    .("The analysis found a negligible correlation between the variables (r = {r}, {p}). The correlation explains {variance}% of the variance, and the relationship is not statistically significant."),
                    r = round(r, 3), p = sig_level,
                    variance = round(r_squared * 100, 1))
            } else if (is_significant) {
                .fmt(
                    .("The analysis found a {strength} {direction} correlation between the variables (r = {r}, {p}). The correlation explains {variance}% of the variance, and the relationship is statistically significant."),
                    strength = strength, direction = direction, r = round(r, 3),
                    p = sig_level, variance = round(r_squared * 100, 1))
            } else {
                .fmt(
                    .("The analysis found a {strength} {direction} correlation between the variables (r = {r}, {p}). The correlation explains {variance}% of the variance, and the relationship is not statistically significant."),
                    strength = strength, direction = direction, r = round(r, 3),
                    p = sig_level, variance = round(r_squared * 100, 1))
            }
            
            # Add caution if needed
            if (has_repeated_measures) {
                copy_ready <- paste0(copy_ready, " ", .("Note: Results should be interpreted with caution as repeated X values were observed. This does not identify repeated subjects; verify whether observations are independent."))
            } else if (has_grouping) {
                copy_ready <- paste0(copy_ready, " ", .("Note: Results should be interpreted with caution as grouped data may mask within-group patterns."))
            } else if (is_significant) {
                copy_ready <- paste0(copy_ready, " ", .("Statistical significance reflects sample size as well as the size of the association; the magnitude of r and the R-squared value reported above describe the strength of the relationship. Correlation does not imply causation."))
            }

            return(copy_ready)
        },

        # Single source of truth for correlation-strength wording.
        # Convention: absolute Pearson r (NOT R-squared) on a five-level scale
        #   |r| < 0.10  negligible
        #   |r| < 0.30  weak
        #   |r| < 0.50  moderate
        #   |r| < 0.70  strong
        #   |r| >= 0.70 very strong
        # Used by .generateCopyReadyCorrelation(), .interpretCorrelation(), and
        # .generateNaturalSummary() so all three report consistent strength labels.
        .correlationStrength = function(r) {
            if (is.na(r)) return(.("undetermined"))
            abs_r <- abs(r)
            if (abs_r < 0.1) {
                .("negligible")
            } else if (abs_r < 0.3) {
                .("weak")
            } else if (abs_r < 0.5) {
                .("moderate")
            } else if (abs_r < 0.7) {
                .("strong")
            } else {
                .("very strong")
            }
        },

        # Interpret effect size.
        # NOTE: this is a variance-explained (R-squared) scale and is deliberately
        # distinct from .correlationStrength() (which labels |r|). The R-squared
        # thresholds below are intentionally conservative for clinical reporting.
        .interpretEffectSize = function(r_squared) {
            label <- if (r_squared >= 0.5) {
                .("Large effect size")
            } else if (r_squared >= 0.25) {
                .("Medium effect size")
            } else if (r_squared >= 0.1) {
                .("Small effect size")
            } else {
                .("Very small effect size")
            }
            .fmt(
                .("{label}. Whether an association of this magnitude matters in a given setting depends on the outcome and the context, and cannot be read off R-squared alone."),
                label = label)
        },

        # Enhanced correlation interpretation with clinical context
        .interpretCorrelation = function(r, p_value, has_repeated_measures = FALSE, has_grouping = FALSE) {
            if (is.na(r) || is.na(p_value)) return(.("Not available"))

            # Significance levels with clinical interpretation
            # Report the plain-language phrase, not an asterisk code. clinical_sig
            # was already computed here and then thrown away, so the correlation
            # table read "moderate positive correlation (**)" - a notation a
            # clinician should not have to decode. The numeric p now has its own
            # column, so the asterisks carried no information the table lacks.
            clinical_sig <- if (p_value < 0.05) .("statistically significant") else .("not statistically significant")

            # Strength label (single source of truth: .correlationStrength)
            strength <- private$.correlationStrength(r)

            # Create copy-ready interpretation
            correlation_is_zero <- isTRUE(all.equal(
                unname(r), 0, tolerance = sqrt(.Machine$double.eps)))
            # One translatable sentence with placeholders, not word fragments
            # glued in English order - the same shape .generateCopyReadyCorrelation()
            # already uses.
            base_interpretation <- if (correlation_is_zero) {
                .fmt(.("negligible correlation, {sig}"), sig = clinical_sig)
            } else {
                direction <- if (r > 0) .("positive") else .("negative")
                .fmt(.("{strength} {direction} correlation, {sig}"),
                     strength = strength, direction = direction, sig = clinical_sig)
            }

            # Add clinical context
            if (has_repeated_measures) {
                clinical_note <- .("Caution: Repeated measures detected. Standard correlation assumes independence and may overstate significance.")
            } else if (has_grouping) {
                clinical_note <- .("Caution: Grouped data detected. Correlation across groups may mask within-group patterns (Simpson's paradox).")
            } else {
                clinical_note <- .("Correlation does not imply causation.")
            }

            return(paste0(base_interpretation, " - ", clinical_note))
        },

        # Enhanced color palette with accessibility focus
        .getColorPalette = function(n_colors) {
            palette_name <- self$options$colorPalette

            if (n_colors == 1) {
                return("#2E86AB")  # High contrast single color
            }

            # Enhanced palettes with better contrast and colorblind accessibility
            palette_colors <- switch(palette_name,
                "default" = c("#2E86AB", "#A23B72", "#F18F01", "#C73E1D", "#7FB069", "#8E6C8A"),
                "colorblind" = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00"),
                "viridis" = c("#440154", "#31688e", "#35b779", "#fde725", "#21908c", "#5dc863"),
                "clinical" = c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"),
                # Default fallback with high contrast
                c("#2E86AB", "#A23B72", "#F18F01", "#C73E1D", "#7FB069", "#8E6C8A")
            )

            # Interpolate additional distinct colors when more groups are
            # requested than the base palette provides (up to 10 groups are
            # permitted). Interpolating keeps groups 7-10 visually
            # distinguishable instead of cycling/repeating identical colors.
            if (n_colors > length(palette_colors)) {
                palette_colors <- grDevices::colorRampPalette(palette_colors)(n_colors)
            }

            return(palette_colors[1:n_colors])
        },

        # Generate statistical assumptions panel
        .populateAssumptions = function(data, correlation_stats = NULL) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar

            # Build assumptions content
            assumptions_html <- paste0(
                "<div class='alert alert-info'>",
                "<h5>", .("Statistical Assumptions & Guidelines"), "</h5>",
                "<p>", .("Understanding the assumptions behind your analysis helps ensure valid interpretation."), "</p>",
                "</div>"
            )

            # Core assumptions for line charts
            assumptions_html <- paste0(assumptions_html,
                "<div class='card'>",
                "<div class='card-header'><strong>", .("Line Chart Assumptions"), "</strong></div>",
                "<div class='card-body'>",
                "<ul>",
                "<li>", .("<strong>Continuous Y-variable:</strong> The outcome variable should be numeric and measurable."), "</li>",
                "<li>", .("<strong>Ordered X-variable:</strong> Time points or sequence should have meaningful order."), "</li>",
                "<li>", .("<strong>Independence:</strong> Observations should be independent unless using appropriate methods for correlated data."), "</li>",
                "</ul>",
                "</div>",
                "</div><br>"
            )

            # Trend analysis assumptions (if applicable)
            if (self$options$trendline && !is.null(correlation_stats)) {
                x_data <- data[[xvar]]
                y_data <- data[[yvar]]

                # Check linearity (basic)
                linearity_check <- if (is.numeric(x_data)) {
                    # Simple linearity assessment using correlation vs polynomial fit
                    linear_r2 <- correlation_stats$r_squared
                    quadratic_model <- tryCatch({
                        lm(y_data ~ stats::poly(x_data, 2))
                    }, error = function(e) NULL)

                    if (!is.null(quadratic_model)) {
                        quad_r2 <- summary(quadratic_model)$r.squared
                        improvement <- quad_r2 - linear_r2
                        if (improvement > 0.05) {
                            .("Potential non-linear relationship detected. Consider polynomial or spline fitting.")
                        } else {
                            .("The linear relationship assumption appears reasonable.")
                        }
                    } else {
                        .("Unable to assess linearity automatically.")
                    }
                } else {
                    .("Linearity assessment not applicable for categorical X-variable.")
                }

                # Check normality of residuals (basic)
                homoscedasticity_check <- .("Homoscedasticity check not applicable for this analysis.")
                normality_check <- if (is.numeric(x_data) && !is.null(correlation_stats$pearson_r)) {
                    lm_model <- lm(y_data ~ x_data)
                    residuals <- residuals(lm_model)

                    # Homoscedasticity was listed below as a key assumption but was
                    # never tested, so the panel asserted something it had not
                    # checked. Screen it by rank-correlating the absolute residuals
                    # against the fitted values: a reliable non-constant-variance
                    # signal that needs no extra dependency (a Breusch-Pagan test
                    # would pull in lmtest for no added value at these sample sizes).
                    homoscedasticity_check <- if (length(residuals) >= 4) {
                        bp <- tryCatch(
                            suppressWarnings(cor.test(abs(residuals), stats::fitted(lm_model),
                                                      method = "spearman", exact = FALSE)),
                            error = function(e) NULL)
                        if (is.null(bp) || is.na(bp$p.value)) {
                            .("Unable to assess constant variance automatically.")
                        } else if (bp$p.value <= 0.05) {
                            .fmt(.("Residual spread changes with the fitted value (Spearman p = {p}), so the constant-variance assumption is doubtful. Confidence intervals and p-values from the linear fit may be too narrow."),
                                 p = private$.fmtNum(bp$p.value))
                        } else {
                            .fmt(.("Residual spread looks constant across fitted values (Spearman p = {p})."),
                                 p = private$.fmtNum(bp$p.value))
                        }
                    } else {
                        .("Insufficient data to assess constant variance.")
                    }
                    if (length(residuals) >= 3) {
                        shapiro_result <- tryCatch({
                            shapiro.test(residuals)
                        }, error = function(e) NULL)

                        if (!is.null(shapiro_result)) {
                            if (shapiro_result$p.value > 0.05) {
                                .("Residuals appear normally distributed (Shapiro-Wilk p > 0.05).")
                            } else {
                                .("Residuals may not be normally distributed (Shapiro-Wilk p \u2264 0.05). Consider robust methods.")
                            }
                        } else {
                            .("Unable to test normality of residuals.")
                        }
                    } else {
                        .("Insufficient data for residual normality testing.")
                    }
                } else {
                    .("Normality check not applicable for this analysis.")
                }

                assumptions_html <- paste0(assumptions_html,
                    "<div class='card'>",
                    "<div class='card-header'><strong>", .("Trend Analysis Assumptions"), "</strong></div>",
                    "<div class='card-body'>",
                    "<h6>", .("Key Assumptions:"), "</h6>",
                    "<ul>",
                    "<li>", .("<strong>Linearity:</strong> The relationship between variables is approximately linear."), "</li>",
                    "<li>", .("<strong>Independence:</strong> Data points are independent of each other."), "</li>",
                    "<li>", .("<strong>Normality:</strong> Residuals are approximately normally distributed."), "</li>",
                    "<li>", .("<strong>Homoscedasticity:</strong> Variance of residuals is constant across fitted values."), "</li>",
                    "</ul>",
                    "<h6>", .("Assumption Checks:"), "</h6>",
                    "<ul>",
                    "<li>", linearity_check, "</li>",
                    "<li>", normality_check, "</li>",
                    "<li>", homoscedasticity_check, "</li>",
                    "</ul>",
                    "</div>",
                    "</div><br>"
                )
            }

            # Clinical interpretation guidelines
            assumptions_html <- paste0(assumptions_html,
                "<div class='card'>",
                "<div class='card-header'><strong>", .("Clinical Interpretation Guidelines"), "</strong></div>",
                "<div class='card-body'>",
                "<h6>", .("Effect Size Interpretation:"), "</h6>",
                "<ul>",
                "<li>", .("<strong>R\u00b2 \u2265 0.50:</strong> Large effect - at least 50% of the variance accounted for"), "</li>",
                "<li>", .("<strong>R\u00b2 = 0.25-0.49:</strong> Medium effect - 25% to 49% of the variance accounted for"), "</li>",
                "<li>", .("<strong>R\u00b2 = 0.10-0.24:</strong> Small effect - 10% to 24% of the variance accounted for"), "</li>",
                "<li>", .("<strong>R\u00b2 < 0.10:</strong> Very small effect - under 10% of the variance accounted for"), "</li>",
                "</ul>",
                "<h6>", .("Confidence Intervals:"), "</h6>",
                "<p>", .("When displayed, confidence intervals show the uncertainty around trend lines. Wider intervals indicate greater uncertainty."), "</p>",
                "<h6>", .("Sample Size Considerations:"), "</h6>",
                "<p>", .("Minimum recommendations: 10+ observations for basic trends, 30+ for reliable confidence intervals, 50+ for robust correlation analysis."), "</p>",
                "</div>",
                "</div>"
            )

            self$results$assumptions$setContent(assumptions_html)
        },

        # Enhanced plot theme with accessibility improvements
        .getPlotTheme = function() {
            theme_name <- self$options$theme

            base_theme <- switch(theme_name,
                "default" = ggplot2::theme_gray(),
                "minimal" = ggplot2::theme_minimal(),
                "classic" = ggplot2::theme_classic(),
                "publication" = ggplot2::theme_bw() +
                    ggplot2::theme(
                        panel.grid.minor = ggplot2::element_blank(),
                        strip.background = ggplot2::element_blank(),
                        legend.position = "bottom",
                        # Enhanced accessibility
                        text = ggplot2::element_text(size = 12, colour = "black"),
                        axis.title = ggplot2::element_text(size = 14, colour = "black"),
                        axis.text = ggplot2::element_text(size = 11, colour = "black"),
                        plot.title = ggplot2::element_text(size = 16, hjust = 0.5, colour = "black", face = "bold"),
                        legend.text = ggplot2::element_text(size = 11, colour = "black"),
                        legend.title = ggplot2::element_text(size = 12, colour = "black", face = "bold"),
                        # Improve contrast
                        panel.border = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.5),
                        axis.line = ggplot2::element_line(colour = "black", linewidth = 0.5)
                    ),
                ggplot2::theme_gray()  # fallback
            )

            # Add custom modifications for clinical publications with accessibility
            if (theme_name == "publication") {
                base_theme <- base_theme +
                    ggplot2::theme(
                        # High contrast for accessibility
                        panel.background = ggplot2::element_rect(fill = "white", colour = "black"),
                        plot.background = ggplot2::element_rect(fill = "white", colour = NA),
                        # Better grid lines
                        panel.grid.major = ggplot2::element_line(colour = "grey80", linewidth = 0.3),
                        # Enhanced text readability
                        axis.ticks = ggplot2::element_line(colour = "black", linewidth = 0.5),
                        axis.ticks.length = ggplot2::unit(0.15, "cm")
                    )
            }

            return(base_theme)
        },

        # Main plotting function - now modular and testable
        .plot = function(image, ggtheme, theme, ...) {
            # Get plot data
            plot_data <- image$state
            if (is.null(plot_data)) return(FALSE)

            private$.checkpoint()  # Checkpoint before plot generation

            # Check dependencies before plotting
            private$.checkDependencies()

            # Build plot using modular approach
            p <- private$.buildBasePlot(plot_data)
            p <- private$.addGroupingAndLines(p, plot_data)
            p <- private$.addTrendlines(p, plot_data)
            p <- private$.addReferenceLines(p, plot_data)
            p <- private$.addLabelsAndTheme(p, plot_data)

            # Print plot
            print(p)
            TRUE
        },

        # Save plot data
        .savePlotData = function(data) {
            # Set plot state for rendering
            self$results$plot$setState(data)
        },

        # === NEW HELPER FUNCTIONS FOR MODULAR DESIGN ===

        # Check dependencies at runtime
        .checkDependencies = function() {
            # ggplot2 only. dplyr used to be listed here but is never called
            # anywhere in this analysis, so a missing dplyr aborted the run for a
            # package it does not use.
            required_packages <- c("ggplot2")
            missing_packages <- required_packages[!sapply(required_packages, requireNamespace, quietly = TRUE)]

            if (length(missing_packages) > 0) {
                error_msg <- paste0(
                    "The following required packages are not installed: ",
                    paste(missing_packages, collapse = ", "),
                    "\n\nPlease install them using:\n",
                    "install.packages(c(", paste0("'", missing_packages, "'", collapse = ", "), "))",
                    "\n\nFor help with installation, see your system administrator or R documentation."
                )

                self$results$todo$setContent(paste0(
                    "<div class='alert alert-danger'>",
                    "<h4>", .("Missing Dependencies"), "</h4>",
                    "<p>", gsub("\n", "<br>", error_msg), "</p>",
                    "</div>"
                ))
                jmvcore::reject(.fmt(
                    .("This analysis needs the {pkgs} package(s), which are not installed. Install them and run the analysis again."),
                    pkgs = paste(missing_packages, collapse = ", ")))
            }
        },

        # Enhanced welcome message
        .showWelcomeMessage = function() {
            welcome_msg <- paste0(
                "<div class='alert alert-info'>",
                "<h4>", .("Welcome to Line Chart Analysis"), "</h4>",
                "<p>", .("This function creates comprehensive line charts for time series and trend analysis in clinical research."), "</p>",

                "<div class='alert alert-success'>",
                "<h5>", .("Quick Start Guide:"), "</h5>",
                "<ol>",
                "<li>", .("Select your X-axis variable (time points, visits, or sequence)"), "</li>",
                "<li>", .("Select your Y-axis variable (measurements, lab values, or biomarkers)"), "</li>",
                "<li>", .("Optionally add a grouping variable (treatment arms, patient groups)"), "</li>",
                "<li>", .("Choose display options (confidence intervals, trend lines, reference lines)"), "</li>",
                "</ol>",
                "</div>",

                "<h5>", .("Clinical Applications:"), "</h5>",
                "<div class='row'>",
                "<div class='col-md-6'>",
                "<ul>",
                "<li>", .("Longitudinal biomarker tracking"), "</li>",
                "<li>", .("Treatment response monitoring"), "</li>",
                "<li>", .("Laboratory value trends"), "</li>",
                "</ul>",
                "</div>",
                "<div class='col-md-6'>",
                "<ul>",
                "<li>", .("Disease progression analysis"), "</li>",
                "<li>", .("Dose-response relationships"), "</li>",
                "<li>", .("Quality metrics over time"), "</li>",
                "</ul>",
                "</div>",
                "</div>",

                "<div class='alert alert-warning'>",
                "<h6>", .("Statistical Notes:"), "</h6>",
                "<ul>",
                "<li>", .("Minimum 3 time points recommended for trend analysis"), "</li>",
                "<li>", .("Consider using confidence intervals for small sample sizes"), "</li>",
                "<li>", .("Reference lines help identify clinically significant thresholds"), "</li>",
                "</ul>",
                "</div>",
                "</div>"
            )

            self$results$todo$setContent(welcome_msg)
        },

        # Data quality and misuse detection
        .checkDataQuality = function(data) {
            xvar <- self$options$xvar
            groupby <- self$options$groupby

            warnings <- c()

            # Exclusions first: every statistic below is computed on the rows that
            # survived, so the reader needs to know how many did not.
            if (private$.n_excluded_missing > 0)
                warnings <- c(warnings, sprintf(
                    .("%d row(s) were excluded because of missing values; %d rows were analyzed."),
                    private$.n_excluded_missing, private$.n_rows_analysed))

            if (private$.n_excluded_nonfinite > 0)
                warnings <- c(warnings, sprintf(
                    .("%d row(s) held infinite values (Inf or -Inf) and were excluded; %d rows were analyzed. Infinite values are usually a division by zero or a log of zero upstream - check the source variable."),
                    private$.n_excluded_nonfinite, private$.n_rows_analysed))

            # A line needs at least two distinct x positions. With one, the chart is
            # a vertical strip of points, and the trend/correlation statistics
            # describe nothing - but it rendered silently.
            n_x <- length(unique(data[[xvar]]))
            if (n_x < 2)
                warnings <- c(warnings, sprintf(
                    .("All observations share a single X value (%s). A line chart needs at least two distinct X positions; no trend can be shown or estimated from one."),
                    base::format(unique(data[[xvar]])[1])))

            # Say what the confidence band actually is. geom_smooth() fits its own
            # model: a straight line by default, loess when Smooth is on. The
            # visible line is geom_line(), which connects the observed points. So
            # the ribbon is NOT the uncertainty around the line being drawn, and a
            # reader will assume it is. Verified against predict(lm, interval =
            # "confidence"): the band matches to 0 difference, i.e. it is exactly a
            # linear-fit CI.
            if (isTRUE(self$options$confidence)) {
                warnings <- c(warnings, if (isTRUE(self$options$smooth))
                    .("The shaded band is the 95% confidence interval of a LOESS fit, not the uncertainty of the plotted points themselves.")
                else
                    .("The shaded band is the 95% confidence interval of a straight-line (linear regression) fit, while the plotted line connects the observed values. The band therefore describes a linear trend, not the line you see; enable Smooth line if you want the band and the line to match."))
            }

            # Check minimum data requirements for different analyses
            if (self$options$trendline && nrow(data) < 5) {
                warnings <- c(warnings, .("Warning: Less than 5 data points available for trend analysis. Results may be unreliable."))
            }

            if (self$options$confidence && nrow(data) < 10) {
                warnings <- c(warnings, .("Warning: Small sample size (< 10 observations) may produce unreliable confidence intervals."))
            }

            # Check for too many groups
            if (!is.null(groupby)) {
                n_groups <- length(unique(data[[groupby]]))
                if (n_groups > 8) {
                    warnings <- c(warnings, .fmt(
                        .("Many groups detected ({n}). Consider reducing groups or using faceting for clarity."),
                        n = n_groups))
                }

                # Check group balance
                group_counts <- table(data[[groupby]])
                if (min(group_counts) < 3) {
                    warnings <- c(warnings, .("Warning: Some groups have very few observations (< 3). Consider combining small groups."))
                }
            }

            # Check X-axis spacing for time series
            if (is.numeric(data[[xvar]])) {
                x_diff <- diff(sort(unique(data[[xvar]])))
                if (length(unique(round(x_diff, 6))) > 1) {
                    warnings <- c(warnings, .("Note: Unequal time intervals detected. Trend interpretation should account for irregular spacing."))
                }
            }

            # Display warnings if any
            if (length(warnings) > 0) {
                warning_html <- paste0(
                    "<div class='alert alert-warning'>",
                    "<h6>", .("Data Quality Alerts:"), "</h6>",
                    "<ul>",
                    paste0("<li>", warnings, "</li>", collapse = ""),
                    "</ul>",
                    "</div>"
                )

                # Append to existing content if any
                existing_content <- self$results$todo$content
                if (!is.null(existing_content) && nchar(existing_content) > 0) {
                    self$results$todo$setContent(paste0(existing_content, warning_html))
                } else {
                    self$results$todo$setContent(warning_html)
                }
                self$results$todo$setVisible(TRUE)
            }
        },

        # Generate natural language summary.
        # correlation_stats is threaded in from .run() (computed once) to avoid a
        # second cor.test/lm pass; falls back to computing it only if not supplied.
        .generateNaturalSummary = function(summary_stats, data, correlation_stats = NULL) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar
            groupby <- self$options$groupby

            # Basic summary
            summary_text <- paste0(
                "<div class='alert alert-info'>",
                "<h5>", .("Analysis Summary"), "</h5>",
                "<p><strong>", .("Dataset:"), "</strong> ", summary_stats$n_observations, " ", .("observations"),
                " ", .("across"), " ", summary_stats$n_x_points, " ", .("time points"), "</p>"
            )

            # Add group information (group_names is user data -> escape for HTML)
            if (!is.null(groupby) && summary_stats$n_groups > 1) {
                summary_text <- paste0(summary_text,
                    "<p><strong>", .("Groups:"), "</strong> ", summary_stats$n_groups, " ", .("groups"), " (", jmvcore::htmlEscape(summary_stats$group_names), ")</p>"
                )
            }

            # Add Y variable summary (yvar is a user column name -> escape for HTML)
            summary_text <- paste0(summary_text,
                "<p><strong>", jmvcore::htmlEscape(yvar), "</strong> ", .("ranges from"), " ",
                private$.fmtNum(summary_stats$y_min), " ", .("to"), " ", private$.fmtNum(summary_stats$y_max),
                " (mean: ", private$.fmtNum(summary_stats$y_mean), ", SD: ", private$.fmtNum(summary_stats$y_sd), ")</p>"
            )

            # Add trend information if available
            if (self$options$trendline && is.numeric(data[[xvar]])) {
                # Reuse the correlation computed once in .run(); compute here only
                # if it was not supplied (defensive fallback).
                if (is.null(correlation_stats)) {
                    correlation_stats <- private$.calculateCorrelation(data)
                }
                if (!is.null(correlation_stats$slope)) {
                    slope_is_zero <- isTRUE(correlation_stats$slope_is_zero)
                    trend_sentence <- if (slope_is_zero) {
                        .fmt(
                            .("No clear linear trend was detected (R\u00b2 = {r2})."),
                            r2 = round(correlation_stats$r_squared, 3))
                    } else {
                        trend_direction <- if (correlation_stats$slope > 0) {
                            .("increasing")
                        } else {
                            .("decreasing")
                        }
                        .fmt(
                            .("A {strength} {direction} trend was detected (R\u00b2 = {r2})."),
                            strength = private$.correlationStrength(
                                correlation_stats$pearson_r),
                            direction = trend_direction,
                            r2 = round(correlation_stats$r_squared, 3))
                    }

                    summary_text <- paste0(
                        summary_text,
                        "<p><strong>", .("Trend:"), "</strong> ",
                        trend_sentence, "</p>")
                }
            }

            summary_text <- paste0(summary_text, "</div>")

            # FIXED: Use dedicated naturalSummary output instead of appending to todo
            self$results$naturalSummary$setContent(summary_text)
            self$results$naturalSummary$setVisible(TRUE)
        },

        # Enhanced error handling
        .handleError = function(e) {
            error_suggestions <- list(
                "not found" = .("Check that all selected variables exist in your dataset."),
                "numeric" = .("Ensure the Y-axis variable contains numeric values. Convert text numbers if needed."),
                "missing" = .("Remove rows with missing values or select variables with complete data."),
                "groups" = .("Verify that the grouping variable has meaningful categories."),
                "packages" = .("Install required packages using the provided commands.")
            )

            # Find relevant suggestion
            # TODO (forward-looking): this string-match dispatch on e$message is fragile - 
            #   any rewording of the validation rejects in .cleanData() / .checkDependencies()
            #   silently breaks the mapping. Now that those sites use jmvcore::reject(),
            #   pass a stable `code = "..."` argument from each reject() site and switch
            #   this loop to dispatch on conditionMessage/class instead of substring grep.
            suggestion <- .("Please verify your data and variable selections.")
            for (pattern in names(error_suggestions)) {
                if (grepl(pattern, e$message, ignore.case = TRUE)) {
                    suggestion <- error_suggestions[[pattern]]
                    break
                }
            }

            error_msg <- paste0(
                "<div class='alert alert-danger'>",
                "<h4>", .("Analysis Error"), "</h4>",
                "<p><strong>", .("Error:"), "</strong> ", jmvcore::htmlEscape(e$message), "</p>",
                "<p><strong>", .("Suggestion:"), "</strong> ", suggestion, "</p>",
                "<details>",
                "<summary>", .("Common Solutions"), "</summary>",
                "<ul>",
                "<li>", .("Ensure variables contain appropriate data types (numeric for Y-axis)"), "</li>",
                "<li>", .("Check for missing values and remove incomplete cases"), "</li>",
                "<li>", .("Verify that grouping variables have multiple levels"), "</li>",
                "<li>", .("Ensure at least 3 observations are available for analysis"), "</li>",
                "</ul>",
                "</details>",
                "</div>"
            )
            self$results$todo$setContent(error_msg)
            self$results$todo$setVisible(TRUE)
        },

        # === MODULAR PLOT BUILDING FUNCTIONS ===

        # Build base plot with modern aes() syntax
        .buildBasePlot = function(plot_data) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar

            # Use modern aes() with .data pronoun instead of deprecated aes_string()
            p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[xvar]], y = .data[[yvar]]))
            return(p)
        },

        # Add grouping, lines, confidence intervals, and points
        .addGroupingAndLines = function(p, plot_data) {
            groupby <- self$options$groupby

            if (!is.null(groupby)) {
                # Add grouping aesthetics
                p <- p + ggplot2::aes(color = .data[[groupby]], group = .data[[groupby]])

                # Get colors
                n_groups <- length(unique(plot_data[[groupby]]))
                colors <- private$.getColorPalette(n_groups)

                # Add confidence intervals if requested
                if (self$options$confidence) {
                    private$.checkpoint(flush = FALSE)
                    method <- if (self$options$smooth) "loess" else "lm"
                    p <- p + ggplot2::geom_smooth(method = method, alpha = 0.2)
                }

                # Add main lines
                if (self$options$smooth) {
                    p <- p + ggplot2::geom_smooth(method = "loess", se = FALSE, linewidth = 1.2)
                } else {
                    p <- p + ggplot2::geom_line(linewidth = 1.2)
                }

                # Add points if requested
                if (self$options$points) {
                    p <- p + ggplot2::geom_point(size = 2.5, alpha = 0.8)
                }

                # Set colors
                p <- p + ggplot2::scale_color_manual(values = colors)

            } else {
                # Single group
                color <- private$.getColorPalette(1)

                # Add confidence interval if requested
                if (self$options$confidence) {
                    private$.checkpoint(flush = FALSE)
                    method <- if (self$options$smooth) "loess" else "lm"
                    p <- p + ggplot2::geom_smooth(method = method, alpha = 0.2, color = color, fill = color)
                }

                # Add main line
                if (self$options$smooth) {
                    p <- p + ggplot2::geom_smooth(method = "loess", se = FALSE, color = color, linewidth = 1.2)
                } else {
                    p <- p + ggplot2::geom_line(color = color, linewidth = 1.2)
                }

                # Add points if requested
                if (self$options$points) {
                    p <- p + ggplot2::geom_point(color = color, size = 2.5, alpha = 0.8)
                }
            }

            return(p)
        },

        # Add trend lines
        .addTrendlines = function(p, plot_data) {
            if (!self$options$trendline) return(p)

            xvar <- self$options$xvar
            groupby <- self$options$groupby

            # Only add trend lines for numeric X variables
            if (is.numeric(plot_data[[xvar]])) {
                if (!is.null(groupby)) {
                    p <- p + ggplot2::geom_smooth(method = "lm", se = FALSE, linetype = "dashed", alpha = 0.7, linewidth = 0.8)
                } else {
                    p <- p + ggplot2::geom_smooth(method = "lm", se = FALSE, linetype = "dashed",
                                                 color = "black", alpha = 0.7, linewidth = 0.8)
                }
            }

            return(p)
        },

        # Add reference lines
        .addReferenceLines = function(p, plot_data) {
            # Gated by its own switch rather than by "value != 0". Treating 0 as
            # the off-sentinel made the most common clinical reference line -
            # change from baseline, a difference, a log fold-change - impossible
            # to draw.
            if (!isTRUE(self$options$showRefline)) return(p)

            if (is.null(self$options$refline) || is.na(self$options$refline)) return(p)
            refline_value <- as.numeric(self$options$refline)
            if (is.na(refline_value)) return(p)

            refline_label <- if (!is.null(self$options$reflineLabel) &&
                                nchar(self$options$reflineLabel) > 0) {
                self$options$reflineLabel
            } else {
                .("Reference")
            }

            p <- p +
                ggplot2::geom_hline(yintercept = refline_value,
                                   linetype = "dotted", color = "red", linewidth = 1) +
                ggplot2::annotate("text", x = Inf, y = refline_value,
                                 label = refline_label, hjust = 1.1, vjust = -0.5,
                                 color = "red", size = 3.5, fontface = "bold")

            return(p)
        },

        # Add labels and theme
        .addLabelsAndTheme = function(p, plot_data) {
            xvar <- self$options$xvar
            yvar <- self$options$yvar
            groupby <- self$options$groupby

            # Determine labels
            xlabel <- if (!is.null(self$options$xlabel) && nchar(self$options$xlabel) > 0) {
                self$options$xlabel
            } else {
                xvar
            }

            ylabel <- if (!is.null(self$options$ylabel) && nchar(self$options$ylabel) > 0) {
                self$options$ylabel
            } else {
                yvar
            }

            plot_title <- if (!is.null(self$options$title) && nchar(self$options$title) > 0) {
                self$options$title
            } else {
                if (!is.null(groupby)) {
                    paste(ylabel, .("by"), xlabel, .("and"), groupby)
                } else {
                    paste(ylabel, .("by"), xlabel)
                }
            }

            # Add labels
            p <- p + ggplot2::labs(
                x = xlabel,
                y = ylabel,
                title = plot_title,
                color = if (!is.null(groupby)) groupby else NULL
            )

            # Apply theme
            p <- p + private$.getPlotTheme()

            return(p)
        }
    )
)
