#' @title Raincloud Plot for Distribution Visualization
#' @return Raincloud plot using ggdist for comprehensive distribution analysis
#'
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @importFrom magrittr %>%
#' @importFrom ggplot2 ggplot aes geom_boxplot coord_flip labs theme_minimal theme_classic
#' @importFrom ggplot2 scale_fill_manual scale_color_manual theme element_text facet_wrap
#' @importFrom ggplot2 theme_bw scale_fill_viridis_d scale_color_viridis_d
#' @importFrom ggdist stat_halfeye stat_dots
#' @importFrom dplyr group_by summarise mutate n
#' @importFrom RColorBrewer brewer.pal
#' @importFrom scales alpha
#' @importFrom stringr str_to_title
#' @importFrom htmltools HTML
#' @importFrom moments skewness kurtosis
#' @importFrom viridis viridis
raincloudClass <- if (requireNamespace("jmvcore")) R6::R6Class("raincloudClass",
    inherit = raincloudBase,
    private = list(

        .init = function() {
            # Input validation for numeric parameters
            if (!is.null(self$options$alpha_violin)) {
                if (self$options$alpha_violin < 0 || self$options$alpha_violin > 1) {
                    jmvcore::reject(.("Violin transparency must be between 0 and 1"), code = "")
                }
            }
            
            if (!is.null(self$options$alpha_dots)) {
                if (self$options$alpha_dots < 0 || self$options$alpha_dots > 1) {
                    jmvcore::reject(.("Dots transparency must be between 0 and 1"), code = "")
                }
            }
            
            if (!is.null(self$options$violin_width)) {
                if (self$options$violin_width < 0.1 || self$options$violin_width > 2) {
                    jmvcore::reject(.("Violin width must be between 0.1 and 2"), code = "")
                }
            }
            
            if (!is.null(self$options$box_width)) {
                if (self$options$box_width < 0.05 || self$options$box_width > 1) {
                    jmvcore::reject(.("Box plot width must be between 0.05 and 1"), code = "")
                }
            }
            
            if (!is.null(self$options$dots_size)) {
                if (self$options$dots_size < 0.1 || self$options$dots_size > 5) {
                    jmvcore::reject(.("Dots size must be between 0.1 and 5"), code = "")
                }
            }
        },

        .escapeVar = function(var_name) {
            # Safely escape variable names for FORMULA strings only (not data[[ ]] keys).
            # jmvcore::composeTerm() backtick-quotes AND escapes any embedded backtick,
            # so pathological column names cannot corrupt the formula string.
            if (is.null(var_name) || var_name == "") return(NULL)
            jmvcore::composeTerm(var_name)
        },

        .run = function() {

            # Check if required variables have been selected
            if (is.null(self$options$dep_var) || is.null(self$options$group_var)) {
                intro_msg <- "
                <div style='background-color: rgba(33, 152, 239, 0.13); padding: 20px; border-radius: 8px; margin: 20px 0; color: inherit;'>
                <h3 style='color: #1976d2; margin-top: 0;'> Welcome to Raincloud Plot Visualization!</h3>
                <p><strong>Comprehensive distribution analysis</strong> using ggdist raincloud plots</p>
                <p>Based on R-Bloggers tutorial: 'Make a Raincloud Plot to Visualize Distribution in ggplot2'</p>
                
                <h4 style='color: #1976d2;'>Required Variables:</h4>
                <ol>
                <li><strong>Dependent Variable:</strong> Continuous variable for distribution analysis</li>
                <li><strong>Grouping Variable:</strong> Categorical variable for group comparisons</li>
                </ol>
                
                <h4 style='color: #1976d2;'>What Raincloud Plots Show:</h4>
                <ul>
                <li><strong>Half-Violin Plot:</strong> Probability density distribution shape</li>
                <li><strong>Box Plot:</strong> Median, quartiles, and outliers</li>
                <li><strong>Data Points:</strong> Individual observations as dots</li>
                <li><strong>Distribution Patterns:</strong> Multimodality, skewness, spread</li>
                </ul>
                
                <h4 style='color: #1976d2;'>Perfect For:</h4>
                <ul>
                <li><strong>Clinical Research:</strong> Compare patient groups and biomarker distributions</li>
                <li><strong>Data Exploration:</strong> Reveal patterns hidden in traditional box plots</li>
                <li><strong>Quality Control:</strong> Identify outliers and distribution anomalies</li>
                <li><strong>Publications:</strong> Comprehensive, publication-ready visualizations</li>
                </ul>
                
                <p style='font-size: 12px; color: #555; margin-top: 20px;'>
                 <em>Raincloud plots combine three visualization techniques for complete distribution understanding</em>
                </p>
                </div>"
                
                self$results$todo$setContent(intro_msg)
                return()
            } else {
                self$results$todo$setContent("")
            }

            # Validate dataset
            if (nrow(self$data) == 0) {
                jmvcore::reject(.("Error: The provided dataset contains no complete rows. Please check your data and try again."))
            }

            # Safely require ggdist
            if (!requireNamespace("ggdist", quietly = TRUE)) {
                error_msg <- "
                <div style='color: red; background-color: rgba(255, 33, 67, 0.09); padding: 20px; border-radius: 8px;'>
                <h4>ggdist Package Required</h4>
                <p>The ggdist package is required for raincloud plot functionality.</p>
                <p>Please install it using: <code>install.packages('ggdist')</code></p>
                </div>"
                self$results$interpretation$setContent(error_msg)
                return()
            }

            # Get data and variables
            dataset <- self$data
            dep_var <- self$options$dep_var
            group_var <- self$options$group_var
            facet_var <- self$options$facet_var
            color_var <- self$options$color_var

            # Prepare analysis data
            required_vars <- c(dep_var, group_var)
            if (!is.null(facet_var) && facet_var != "") {
                required_vars <- c(required_vars, facet_var)
            }
            if (!is.null(color_var) && color_var != "") {
                required_vars <- c(required_vars, color_var)
            }
            # A variable used in two roles (e.g. facet_var == group_var) must not
            # be selected twice: dataset[c("g","g")] silently yields a duplicate
            # column renamed "g.1", and the missing-value listing below then
            # reports the same variable twice.
            required_vars <- unique(required_vars)

            analysis_data <- dataset[required_vars]
            analysis_data <- analysis_data[complete.cases(analysis_data), ]
            
            if (nrow(analysis_data) == 0) {
                jmvcore::reject(.("Error: No complete cases found for the selected variables."))
            }

            # Convert variables to appropriate types.
            #
            # as.numeric() on a FACTOR returns the level INDICES (1, 2, 3 ...),
            # not the numbers the labels spell - a factor of "10","20","30"
            # silently becomes 1,2,3 and every statistic below is computed on
            # rank codes. The GUI's `permitted: numeric` keeps factors out of the
            # picker, but an R-API caller reaches here. as.character() first is
            # exact for both factors and numerics.
            dep_raw <- analysis_data[[dep_var]]
            analysis_data[[dep_var]] <- if (is.factor(dep_raw))
                suppressWarnings(as.numeric(as.character(dep_raw)))
            else suppressWarnings(as.numeric(dep_raw))

            # complete.cases() follows is.na(), which is TRUE for NaN but FALSE
            # for Inf, so an infinite value survives the filter above and then
            # destroys every mean, SD and axis range downstream. The coercion may
            # also have just produced fresh NAs from unparseable text.
            n_before_finite <- nrow(analysis_data)
            analysis_data <- analysis_data[is.finite(analysis_data[[dep_var]]), , drop = FALSE]
            n_nonfinite <- n_before_finite - nrow(analysis_data)
            if (nrow(analysis_data) == 0)
                jmvcore::reject(.("No usable numeric values remain in the dependent variable after removing missing and non-finite entries."))

            analysis_data[[group_var]] <- droplevels(as.factor(analysis_data[[group_var]]))
            
            if (!is.null(facet_var) && facet_var != "") {
                analysis_data[[facet_var]] <- as.factor(analysis_data[[facet_var]])
            }
            if (!is.null(color_var) && color_var != "" && color_var != group_var) {
                analysis_data[[color_var]] <- as.factor(analysis_data[[color_var]])
            }

            # Summary info for users
            group_counts <- table(analysis_data[[group_var]])
            min_group <- min(group_counts)
            max_group <- max(group_counts)
            imbalance_note <- if (max_group / min_group > 5) " <span style='color:#d9534f'>(unbalanced groups; interpret comparisons cautiously)</span>" else ""

            missing_counts <- sapply(required_vars, function(v) sum(is.na(dataset[[v]])))
            missing_msg <- paste0(
                "<ul style='margin:6px 0;'>",
                paste0("<li>", htmltools::htmlEscape(required_vars), ": ", missing_counts, " missing</li>", collapse = ""),
                "</ul>"
            )
            # Guard against a near-continuous grouping variable (permitted: numeric)
            # that coerces to hundreds of factor levels/palette colors.
            high_cardinality_note <- if (length(group_counts) > 20)
                paste0(" <span style='color:#d9534f'>(the grouping variable has ",
                       length(group_counts),
                       " levels; a near-continuous grouping variable yields an unreadable plot and unreliable tests - consider a categorical grouping variable)</span>")
            else ""

            # Faceting by the grouping variable puts exactly one group in each
            # panel, which destroys the side-by-side comparison the plot exists
            # to make. It is accepted, but the user is told why the plot looks
            # degenerate instead of being left to guess.
            redundant_role_note <- if (!is.null(facet_var) && facet_var != "" && facet_var == group_var)
                paste0(" ", .("<span style='color:#d9534f'>(the faceting variable is the same as the grouping variable, so each panel contains a single group and the groups can no longer be compared side by side)</span>"))
            else ""

            summary_msg <- paste0(
                "<div style='background-color: rgba(138, 155, 172, 0.06);padding:12px;border-radius:8px;margin-bottom:12px; color: inherit;'>",
                "<strong>Data summary:</strong> ", nrow(analysis_data), " complete rows (removed ",
                nrow(dataset) - nrow(analysis_data), " with missing values). ",
                length(group_counts), " groups: ",
                paste(paste0(htmltools::htmlEscape(names(group_counts)), " (n=", group_counts, ")"), collapse = ", "),
                ".", imbalance_note, high_cardinality_note, redundant_role_note,
                if (n_nonfinite > 0) paste0(
                    " <span style='color:#d9534f'>(", n_nonfinite,
                    " further row(s) removed for non-finite or non-numeric values in ",
                    htmltools::htmlEscape(dep_var), ")</span>") else "",
                "<br><strong>Missing by variable:</strong>", missing_msg,
                if (min_group < 10) " <span style='color:#d9534f'>(some groups have n < 10; estimates may be imprecise and assumptions need careful assessment)</span>" else "",
                "</div>"
            )
            self$results$todo$setContent(summary_msg)

            # Generate summary statistics if requested
            if (self$options$show_statistics) {
                private$.checkpoint()  # Checkpoint before statistics calculation
                stats_html <- private$.generate_statistics(analysis_data, dep_var, group_var)
                self$results$statistics$setContent(stats_html)
            }
            
            # Generate outlier analysis if requested
            if (self$options$show_outliers) {
                private$.checkpoint()  # Checkpoint before outlier detection
                outlier_html <- private$.generate_outlier_analysis(analysis_data, dep_var, group_var)
                self$results$outliers$setContent(outlier_html)
            }
            
            # Generate normality tests if requested
            if (self$options$normality_test) {
                private$.checkpoint()  # Checkpoint before normality tests
                normality_html <- private$.generate_normality_tests(analysis_data, dep_var, group_var)
                self$results$normality$setContent(normality_html)
            }
            
            # Generate group comparisons if requested
            if (self$options$comparison_test) {
                private$.checkpoint()  # Checkpoint before group comparison tests
                comparison_html <- private$.generate_group_comparisons(analysis_data, dep_var, group_var)
                self$results$comparison$setContent(comparison_html)
            }
            
            # Generate interpretation guide
            interpretation_html <- private$.generate_interpretation_guide(analysis_data, dep_var, group_var)
            # Log-transform validation lives in .run() (never in the render function):
            # a non-positive dependent variable cannot be shown on a log scale.
            if (isTRUE(self$options$log_transform) && any(analysis_data[[dep_var]] <= 0)) {
                interpretation_html <- paste0(
                    interpretation_html,
                    "<div style='background-color: rgba(216, 33, 50, 0.18);color: inherit;padding:12px;border-radius:8px;margin-top:12px;'>",
                    .("Log transform was requested but the dependent variable contains non-positive values; the log scale was skipped."),
                    "</div>"
                )
            }
            self$results$interpretation$setContent(interpretation_html)

            # Store data AND visual options for plotting using setState
            image <- self$results$plot
            plotState <- list(
                data = analysis_data,
                # Include visual options to trigger updates
                color_palette = self$options$color_palette,
                plot_theme = self$options$plot_theme,
                show_violin = self$options$show_violin,
                show_boxplot = self$options$show_boxplot,
                show_dots = self$options$show_dots,
                show_outliers = self$options$show_outliers,
                dots_side = self$options$dots_side,
                orientation = self$options$orientation,
                violin_width = self$options$violin_width,
                box_width = self$options$box_width,
                dots_size = self$options$dots_size,
                alpha_violin = self$options$alpha_violin,
                alpha_dots = self$options$alpha_dots,
                plot_title = self$options$plot_title,
                x_label = self$options$x_label,
                y_label = self$options$y_label,
                log_transform = self$options$log_transform
            )
            image$setState(plotState)

        },

        .plot = function(image, ggtheme, theme, ...) {

            # Extract data from state
            if (is.null(image$state) || is.null(image$state$data)) {
                return()
            }
            analysis_data <- image$state$data
            dep_var <- self$options$dep_var
            group_var <- self$options$group_var
            facet_var <- self$options$facet_var
            color_var <- self$options$color_var
            
            # Determine color mapping
            color_mapping <- if (!is.null(color_var) && color_var != "" && color_var != group_var) {
                color_var
            } else {
                group_var
            }
            
            # Create base plot
            # Use aes() with .data pronoun for safety with special characters
            p <- ggplot2::ggplot(analysis_data, ggplot2::aes(x = .data[[group_var]], y = .data[[dep_var]],
                                                             fill = .data[[color_mapping]], color = .data[[color_mapping]]))
            
            # Add raincloud components based on options
            if (self$options$show_violin) {
                p <- p + ggdist::stat_halfeye(
                    alpha = self$options$alpha_violin,
                    width = self$options$violin_width,
                    .width = 0,
                    point_colour = NA
                )
            }
            
            if (self$options$show_boxplot) {
                p <- p + ggplot2::geom_boxplot(
                    width = self$options$box_width,
                    alpha = 0.7,
                    outlier.shape = if (self$options$show_outliers) 16 else NA
                )
            }
            
            if (self$options$show_dots) {
                dots_side <- self$options$dots_side
                p <- p + ggdist::stat_dots(
                    side = dots_side,
                    dotsize = self$options$dots_size,
                    alpha = self$options$alpha_dots
                )
            }
            
            # Apply orientation
            if (self$options$orientation == "horizontal") {
                p <- p + ggplot2::coord_flip()
            }
            
            # Add faceting if specified
            if (!is.null(facet_var) && facet_var != "") {
                facet_safe <- private$.escapeVar(facet_var)
                p <- p + ggplot2::facet_wrap(jmvcore::asFormula(paste("~", facet_safe)))
            }
            
            # Apply color palette. Transparency is handled once by the geom alpha
            # (stat_halfeye / stat_dots); do not also pre-alpha the fill palette,
            # which would compound transparency and bleed into the boxplot fill.
            colors <- private$.get_color_palette(length(levels(analysis_data[[color_mapping]])))
            p <- p + ggplot2::scale_fill_manual(values = colors)
            p <- p + ggplot2::scale_color_manual(values = colors)
            
            # Apply theme
            p <- p + private$.get_plot_theme()
            
            # Add labels - keep each label tied to its aesthetic (x = group, y = dep).
            # coord_flip() rotates the axes visually but does NOT reassign the x/y
            # titles, so the labels must not be swapped by orientation.
            x_label <- if (self$options$x_label != "") self$options$x_label else group_var
            y_label <- if (self$options$y_label != "") self$options$y_label else dep_var
            plot_title <- if (self$options$plot_title != "") self$options$plot_title else .("Raincloud Plot - Distribution Visualization")
            
            p <- p + ggplot2::labs(
                title = plot_title,
                x = x_label,
                y = y_label,
                fill = color_mapping,
                color = color_mapping
            )

            # Render-only: apply the log scale when valid. The non-positive-value
            # warning is emitted in .run() (render functions must not mutate other outputs).
            if (isTRUE(self$options$log_transform) && !any(analysis_data[[dep_var]] <= 0)) {
                p <- p + ggplot2::scale_y_continuous(trans = "log10")
            }
            
            print(p)
            TRUE
        },

        .get_color_palette = function(n_colors) {
            palette_name <- self$options$color_palette
            # `separator_prism` is the "--- GraphPad Prism Palettes ---" divider,
            # which the List makes selectable. It is not a palette; name it as the
            # default rather than letting it fall through the else branch unnamed.
            if (identical(palette_name, "separator_prism")) palette_name <- "default"
            
            if (palette_name == "viridis") {
                if (requireNamespace("viridis", quietly = TRUE)) {
                    return(viridis::viridis(n_colors))
                } else {
                    # Fallback to similar color scheme
                    return(grDevices::heat.colors(n_colors))
                }
            } else if (palette_name == "clinical") {
                clinical_colors <- c("#2E86AB", "#A23B72", "#F18F01", "#C73E1D", "#593E2C", "#8E6C8A")
                return(rep(clinical_colors, length.out = n_colors))
            } else if (palette_name == "pastel") {
                pastel_colors <- c("#FFB3BA", "#BAFFC9", "#BAE1FF", "#FFFFBA", "#FFDFBA", "#E0BBE4")
                return(rep(pastel_colors, length.out = n_colors))
            } else if (palette_name %in% c("set1", "set2", "dark2")) {
                palette_r_name <- switch(palette_name,
                    "set1" = "Set1",
                    "set2" = "Set2", 
                    "dark2" = "Dark2"
                )
                if (n_colors <= 8) {
                    return(RColorBrewer::brewer.pal(min(max(3, n_colors), 8), palette_r_name))
                } else {
                    base_colors <- RColorBrewer::brewer.pal(8, palette_r_name)
                    return(grDevices::colorRampPalette(base_colors)(n_colors))
                }
            # GraphPad Prism color palettes
            } else if (palette_name %in% c("prism_floral", "prism_candy_bright", "prism_office", 
                                          "prism_pastels", "prism_colorblind_safe", "prism_ocean", "prism_spring")) {
                return(private$.get_prism_palette_colors(palette_name, n_colors))
            } else {
                # Default ggplot2 colors
                return(scales::hue_pal()(n_colors))
            }
        },
        
        .get_prism_palette_colors = function(palette_name, n_colors) {
            # Convert internal palette names to ggprism names
            prism_name <- switch(palette_name,
                "prism_floral" = "floral",
                "prism_candy_bright" = "candy_bright",
                "prism_office" = "office",
                "prism_pastels" = "pastels",
                "prism_colorblind_safe" = "colorblind_safe",
                "prism_ocean" = "ocean",
                "prism_spring" = "spring",
                "floral"  # fallback
            )
            
            if (requireNamespace("ggprism", quietly = TRUE)) {
                # Get colors from ggprism package
                tryCatch({
                    ggprism::prism_colour_pal(palette = prism_name)(n_colors)
                }, error = function(e) {
                    # Fallback to viridis if ggprism palette fails
                    if (requireNamespace("viridis", quietly = TRUE)) {
                        viridis::viridis(n_colors)
                    } else {
                        grDevices::heat.colors(n_colors)
                    }
                })
            } else {
                # Fallback to viridis if ggprism not available
                if (requireNamespace("viridis", quietly = TRUE)) {
                    viridis::viridis(n_colors)
                } else {
                    grDevices::heat.colors(n_colors)
                }
            }
        },

        .get_plot_theme = function() {
            theme_name <- self$options$plot_theme
            # As above: the "--- GraphPad Prism Themes ---" divider is selectable.
            if (identical(theme_name, "separator_theme")) theme_name <- "clinical"
            
            base_theme <- switch(theme_name,
                "clinical" = ggplot2::theme_minimal() + 
                    ggplot2::theme(
                        panel.grid.minor = ggplot2::element_blank(),
                        panel.border = ggplot2::element_rect(fill = NA, color = "grey20"),
                        plot.title = ggplot2::element_text(size = 14, face = "bold", hjust = 0.5),
                        axis.title = ggplot2::element_text(size = 12),
                        legend.title = ggplot2::element_text(size = 11, face = "bold"),
                        strip.text = ggplot2::element_text(size = 11, face = "bold")
                    ),
                "minimal" = ggplot2::theme_minimal(),
                "classic" = ggplot2::theme_classic(),
                "publication" = ggplot2::theme_bw() +
                    ggplot2::theme(
                        plot.title = ggplot2::element_text(size = 16, face = "bold", hjust = 0.5),
                        axis.title = ggplot2::element_text(size = 14, face = "bold"),
                        axis.text = ggplot2::element_text(size = 12),
                        legend.title = ggplot2::element_text(size = 12, face = "bold"),
                        strip.text = ggplot2::element_text(size = 12, face = "bold")
                    ),
                "tidyquant" = ggplot2::theme_minimal() +
                    ggplot2::theme(
                        panel.grid.major = ggplot2::element_line(color = "grey90"),
                        panel.grid.minor = ggplot2::element_blank(),
                        plot.title = ggplot2::element_text(size = 14, face = "bold")
                    ),
                # GraphPad Prism themes
                "prism_default" = private$.get_prism_theme("default"),
                "prism_white" = private$.get_prism_theme("white"),
                "prism_publication" = private$.get_prism_theme("publication"),
                ggplot2::theme_minimal()  # fallback
            )
            
            return(base_theme)
        },
        
        .get_prism_theme = function(theme_type) {
            base_size <- 12
            
            if (requireNamespace("ggprism", quietly = TRUE)) {
                # Use authentic ggprism themes
                switch(theme_type,
                    "default" = ggprism::theme_prism(base_size = base_size),
                    "white" = ggprism::theme_prism(base_size = base_size, axis_text_angle = 0),
                    "publication" = ggprism::theme_prism(base_size = base_size) +
                        ggplot2::theme(
                            plot.title = ggplot2::element_text(size = base_size + 2, face = "bold", hjust = 0.5),
                            axis.title = ggplot2::element_text(size = base_size + 1, face = "bold"),
                            legend.background = ggplot2::element_rect(fill = "white", colour = "black"),
                            panel.border = ggplot2::element_rect(colour = "black", fill = NA)
                        ),
                    ggprism::theme_prism(base_size = base_size)  # fallback
                )
            } else {
                # Fallback themes that approximate Prism styling
                ggplot2::theme_minimal(base_size = base_size) +
                    ggplot2::theme(
                        panel.border = ggplot2::element_rect(colour = "black", fill = NA),
                        axis.line = ggplot2::element_line(colour = "black"),
                        panel.grid.major = ggplot2::element_blank(),
                        panel.grid.minor = ggplot2::element_blank(),
                        plot.title = ggplot2::element_text(size = base_size + 2, face = "bold", hjust = 0.5)
                    )
            }
        },

        .generate_statistics = function(data, dep_var, group_var) {
            # Generate comprehensive statistics table
            
            # Calculate skewness and kurtosis with fallback
            calc_skewness <- function(x) {
                if (requireNamespace("moments", quietly = TRUE)) {
                    tryCatch(moments::skewness(x, na.rm = TRUE), error = function(e) NA)
                } else {
                    # Simple skewness approximation
                    n <- length(x[!is.na(x)])
                    if (n < 3) return(NA)
                    x_clean <- x[!is.na(x)]
                    m <- mean(x_clean)
                    s <- sqrt(mean((x_clean - m)^2))
                    if (s == 0) return(NA_real_)
                    sum((x_clean - m)^3) / (n * s^3)
                }
            }
            
            calc_kurtosis <- function(x) {
                if (requireNamespace("moments", quietly = TRUE)) {
                    tryCatch(moments::kurtosis(x, na.rm = TRUE), error = function(e) NA)
                } else {
                    # Simple kurtosis approximation
                    n <- length(x[!is.na(x)])
                    if (n < 4) return(NA)
                    x_clean <- x[!is.na(x)]
                    m <- mean(x_clean)
                    s <- sqrt(mean((x_clean - m)^2))
                    if (s == 0) return(NA_real_)
                    sum((x_clean - m)^4) / (n * s^4)
                }
            }
            
            private$.checkpoint()  # Checkpoint before calculating statistics for all groups
            stats_summary <- data %>%
                dplyr::group_by(.data[[group_var]]) %>%
                dplyr::summarise(
                    n = dplyr::n(),
                    mean = round(mean(.data[[dep_var]], na.rm = TRUE), 3),
                    median = round(median(.data[[dep_var]], na.rm = TRUE), 3),
                    sd = round(sd(.data[[dep_var]], na.rm = TRUE), 3),
                    mad = round(mad(.data[[dep_var]], na.rm = TRUE), 3),
                    q1 = round(quantile(.data[[dep_var]], 0.25, na.rm = TRUE), 3),
                    q3 = round(quantile(.data[[dep_var]], 0.75, na.rm = TRUE), 3),
                    iqr = round(stats::IQR(.data[[dep_var]], na.rm = TRUE), 3),
                    min_val = round(min(.data[[dep_var]], na.rm = TRUE), 3),
                    max_val = round(max(.data[[dep_var]], na.rm = TRUE), 3),
                    skewness = round(calc_skewness(.data[[dep_var]]), 3),
                    kurtosis = round(calc_kurtosis(.data[[dep_var]]), 3),
                    .groups = "drop"
                )
            
            stats_html <- paste0(
                "<div style='background-color: rgba(138, 155, 172, 0.06); padding: 20px; border-radius: 8px; margin-bottom: 20px; color: inherit;'>",
                "<h3 style='color: #495057; margin-top: 0;'> Distribution Summary Statistics</h3>",
                "<table style='width: 100%; border-collapse: collapse; font-family: Arial, sans-serif;'>",
                "<thead><tr style='background-color: #6c757d; color: white;'>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Group</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>N</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Mean</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Median</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>SD</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>MAD</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>IQR</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Range</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Skewness</th>",
                "<th style='padding: 8px; border: 1px solid #dee2e6;'>Kurtosis</th>",
                "</tr></thead><tbody>"
            )
            
            for (i in seq_len(nrow(stats_summary))) {
                row_bg <- if (i %% 2 == 0) "#ffffff" else "#f8f9fa"
                stats_html <- paste0(
                    stats_html,
                    "<tr style='background-color: ", row_bg, ";'>",
                    "<td><strong>", htmltools::htmlEscape(as.character(stats_summary[[group_var]][i])), "</strong></td>",
                    "<td>", stats_summary$n[i], "</td>",
                    "<td>", stats_summary$mean[i], "</td>",
                    "<td>", stats_summary$median[i], "</td>",
                    "<td>", stats_summary$sd[i], "</td>",
                    "<td>", stats_summary$mad[i], "</td>",
                    "<td>", stats_summary$iqr[i], "</td>",
                    "<td>", stats_summary$min_val[i], " - ", stats_summary$max_val[i], "</td>",
                    "<td>", stats_summary$skewness[i], "</td>",
                    "<td>", stats_summary$kurtosis[i], "</td>",
                    "</tr>"
                )
            }
            
            stats_html <- paste0(stats_html, 
                "</tbody></table>",
                "<p style='font-size: 12px; color: #6c757d; margin-top: 15px;'>",
                "<em>IQR = Interquartile Range, SD = Standard Deviation, MAD = Median Absolute Deviation. Skewness: 0 = symmetric, >0 = right-skewed, <0 = left-skewed. Kurtosis: 3 = normal-tailed (excess 0).</em>",
                "</p></div>"
            )
            
            return(stats_html)
        },

        .generate_outlier_analysis = function(data, dep_var, group_var) {
            # Detect and analyze outliers
            
            outlier_method <- tryCatch(self$options$outlier_method, error = function(...) NULL)
            if (is.null(outlier_method)) outlier_method <- "iqr"
            outliers_list <- list()
            
            for (group in levels(data[[group_var]])) {
                private$.checkpoint(flush = FALSE)  # Poll for changes without re-pushing results
                group_data <- data[data[[group_var]] == group, dep_var]
                
                if (outlier_method == "iqr") {
                    q1 <- quantile(group_data, 0.25, na.rm = TRUE)
                    q3 <- quantile(group_data, 0.75, na.rm = TRUE)
                    iqr <- q3 - q1
                    outliers <- which(group_data < (q1 - 1.5 * iqr) | group_data > (q3 + 1.5 * iqr))
                } else if (outlier_method == "zscore") {
                    # A zero SD makes every z NaN, and which(NaN > 3) is empty, so
                    # a constant group silently reported "0 outliers detected" as
                    # though it had been checked. Mark it untestable instead.
                    s_dev <- sd(group_data, na.rm = TRUE)
                    if (!is.finite(s_dev) || s_dev == 0) {
                        outliers_list[[group]] <- NA_integer_
                        next
                    }
                    z_scores <- abs((group_data - mean(group_data, na.rm = TRUE)) / s_dev)
                    outliers <- which(z_scores > 3)
                } else if (outlier_method == "modified_zscore") {
                    median_val <- median(group_data, na.rm = TRUE)
                    mad_val <- mad(group_data, constant = 1, na.rm = TRUE)
                    # Same trap: MAD is 0 whenever more than half the values are
                    # identical, which is common for rounded lab data.
                    if (!is.finite(mad_val) || mad_val == 0) {
                        outliers_list[[group]] <- NA_integer_
                        next
                    }
                    modified_z <- 0.6745 * (group_data - median_val) / mad_val
                    outliers <- which(abs(modified_z) > 3.5)
                }
                
                outliers_list[[group]] <- length(outliers)
            }
            
            outlier_html <- paste0(
                "<div style='background-color: rgba(255, 202, 33, 0.23); padding: 20px; border-radius: 8px; margin-bottom: 20px; color: inherit;'>",
                "<h3 style='color: #856404; margin-top: 0;'> Outlier Detection (", stringr::str_to_title(outlier_method), " Method)</h3>",
                "<ul>"
            )
            
            total_outliers <- 0
            for (group in names(outliers_list)) {
                count <- outliers_list[[group]]
                if (is.na(count)) {
                    outlier_html <- paste0(outlier_html,
                        "<li><strong>", htmltools::htmlEscape(group), ":</strong> ",
                        .("not testable - the spread used by this method is zero (too many identical values); try the IQR method"),
                        "</li>")
                    next
                }
                total_outliers <- total_outliers + count
                outlier_html <- paste0(outlier_html,
                    "<li><strong>", htmltools::htmlEscape(group), ":</strong> ", count, " outliers detected</li>"
                )
            }
            
            outlier_html <- paste0(outlier_html,
                "</ul>",
                "<p><strong>Total potential outliers in assessed groups:</strong> ", total_outliers, "</p>",
                "<p style='font-size: 12px; color: #856404; margin-top: 15px;'>",
                "<em>", 
                switch(outlier_method,
                    "iqr" = "IQR Method: Values beyond 1.5 \u00d7 IQR from Q1/Q3",
                    "zscore" = "Z-Score Method: |Z| > 3",
                    "modified_zscore" = "Modified Z-Score Method: |Modified Z| > 3.5"
                ),
                ". Consider investigating these points for data quality or interesting patterns.</em>",
                "</p></div>"
            )
            
            return(outlier_html)
        },

        .generate_normality_tests = function(data, dep_var, group_var) {
            # Perform normality tests for each group
            
            normality_html <- paste0(
                "<div style='background-color: rgba(33, 163, 188, 0.21); padding: 20px; border-radius: 8px; margin-bottom: 20px; color: inherit;'>",
                "<h3 style='color: #0c5460; margin-top: 0;'> Normality Tests (Shapiro-Wilk)</h3>",
                "<table style='width: 100%; border-collapse: collapse;'>",
                "<tr style='background-color: rgba(33, 33, 33, 0.14); color: inherit;'>",
                "<th style='padding: 8px; border: 1px solid #ddd;'>Group</th>",
                "<th style='padding: 8px; border: 1px solid #ddd;'>W Statistic</th>",
                "<th style='padding: 8px; border: 1px solid #ddd;'>P-value</th>",
                "<th style='padding: 8px; border: 1px solid #ddd;'>Interpretation</th>",
                "</tr>"
            )
            
            for (group in levels(data[[group_var]])) {
                private$.checkpoint(flush = FALSE)  # Poll for changes without re-pushing results
                group_data <- data[data[[group_var]] == group, dep_var]
                
                if (length(group_data) >= 3 && length(group_data) <= 5000) {
                    sw_test <- tryCatch(shapiro.test(group_data), error = function(e) NULL)
                    if (!is.null(sw_test)) {
                        w_stat <- round(sw_test$statistic, 4)
                        p_val <- private$.fmtP(sw_test$p.value)
                        # "Normal" from p > 0.05 accepts the null. Shapiro-Wilk
                        # can only fail to reject, and it is underpowered at small
                        # n - exactly where the claim matters most.
                        interpretation <- if (sw_test$p.value > 0.05)
                            .("No evidence against normality") else .("Departs from normality")
                    } else {
                        # Constant / zero-variance group: shapiro.test errors out
                        w_stat <- "N/A"
                        p_val <- "N/A"
                        interpretation <- .("Not testable (constant values)")
                    }
                } else {
                    w_stat <- "N/A"
                    p_val <- "N/A"
                    interpretation <- .("Sample size not suitable")
                }
                
                normality_html <- paste0(
                    normality_html,
                    "<tr>",
                    "<td>", htmltools::htmlEscape(group), "</td>",
                    "<td>", w_stat, "</td>",
                    "<td>", p_val, "</td>",
                    "<td>", interpretation, "</td>",
                    "</tr>"
                )
            }
            
            normality_html <- paste0(normality_html,
                "</table>",
                "<p style='font-size: 12px; color: #0c5460; margin-top: 15px;'>",
                "<em>", .("Shapiro-Wilk test, valid for sample sizes 3-5000. A p above 0.05 means the test did not detect a departure from normality - it does not establish that the data ARE normal, and the test has little power at small n. One test is run per group, with no adjustment for the number of groups."), "</em>",
                "</p></div>"
            )
            
            return(normality_html)
        },

        # A p-value is never "0.0000". The old code did round(p, 4) and then
        # sprintf("%.4f", .), so a p of 1e-16 was displayed as 0.0000 - a number
        # that cannot appear in a paper - and the copy-ready sentence printed
        # "p = 0.000".
        # Every consumer writes into an Html result item, so emit the "less than"
        # as an ENTITY. Note the honest reason: an HTML5 browser does NOT break on
        # a bare "< 0.001" - "<" followed by a space is not a tag-open, so it is
        # tokenised as literal text and renders fine. The entity is still the
        # correct output because the string is not valid HTML/XHTML without it,
        # anything parsing the panel as XML will choke, and any downstream
        # tag-stripper treats `< 0.001</td>` as one element and swallows the
        # value (which is exactly what happened to this review's own test
        # harness). Do not repeat the earlier claim that browsers render it
        # empty - that was measured in a regex stripper, not a browser.
        .fmtP = function(p) {
            if (is.null(p) || length(p) == 0 || is.na(p) || !is.finite(p)) return(.("not estimable"))
            if (p < 0.001) return("&lt; 0.001")
            formatC(p, format = "f", digits = 3)
        },

        .safe_shapiro_p = function(x) {
            # Locale/crash-safe Shapiro-Wilk p-value. Returns NA when the test is
            # not applicable (too few/many values, or a constant/zero-variance group).
            x <- x[!is.na(x)]
            if (length(x) < 3 || length(x) > 5000) return(NA_real_)
            tryCatch(shapiro.test(x)$p.value, error = function(e) NA_real_)
        },

        .generate_group_comparisons = function(data, dep_var, group_var) {
            # Perform statistical comparisons between groups

            n_groups <- length(levels(data[[group_var]]))
            comparison_method <- tryCatch(self$options$comparison_method, error = function(...) NULL)
            if (is.null(comparison_method)) comparison_method <- "auto"
            adjust_method <- tryCatch(self$options$adjust_method, error = function(...) NULL)
            if (is.null(adjust_method)) adjust_method <- "none"
            effect_size_flag <- isTRUE(tryCatch(self$options$effect_size, error = function(...) FALSE))

            if (n_groups < 2) {
                return("<div style='background-color: rgba(255, 202, 33, 0.23);padding:12px;border-radius:8px; color: inherit;'>At least two groups are required for comparisons.</div>")
            }

            # Determine an UNTRANSLATED test key so branch dispatch is
            # locale-independent (a .()-translated label no longer equals the
            # English literal under a non-English locale, which previously left
            # p_value unassigned and crashed the analysis).
            # Group sizes decide what can be run at all. t.test() throws
            # "not enough 'x' observations" on a group of 1 and the error was
            # uncaught, taking the whole analysis down with it.
            group_ns <- as.integer(table(data[[group_var]]))
            names(group_ns) <- levels(data[[group_var]])
            if (any(group_ns < 2)) {
                return(paste0(
                    "<div style='background-color: rgba(216, 33, 50, 0.18);color: inherit;padding:12px;border-radius:8px;'>",
                    .fmt(
                        .("A group comparison needs at least two observations in every group. The following groups have fewer: {groups}."),
                        groups = htmltools::htmlEscape(paste(
                            sprintf("%s (n=%d)", names(group_ns)[group_ns < 2],
                                    group_ns[group_ns < 2]), collapse = ", "))),
                    "</div>"))
            }

            # Variance homogeneity. Classic one-way ANOVA (aov) assumes equal
            # variances, and with unequal variances AND unequal group sizes it is
            # badly anti-conservative: on null data (all three group means equal)
            # with n = 6/6/60 and sd = 8/8/1, aov reported p = 0.0005 -
            # "Highly significant" - where Welch's ANOVA reported p = 0.16. Three
            # of the first four seeds tried flipped that way. So test the
            # assumption instead of hoping.
            var_p <- NA_real_
            if (n_groups >= 2) {
                var_p <- tryCatch(
                    stats::bartlett.test(
                        stats::setNames(data[[dep_var]], NULL),
                        data[[group_var]])$p.value,
                    error = function(e) NA_real_)
            }
            unequal_var <- !is.na(var_p) && var_p < 0.05

            if (comparison_method == "auto") {
                if (n_groups == 2) {
                    # Check normality for automatic test selection
                    group1_data <- data[data[[group_var]] == levels(data[[group_var]])[1], dep_var]
                    group2_data <- data[data[[group_var]] == levels(data[[group_var]])[2], dep_var]

                    sw1 <- private$.safe_shapiro_p(group1_data)
                    sw2 <- private$.safe_shapiro_p(group2_data)
                    use_parametric <- (!is.na(sw1) && !is.na(sw2) && sw1 > 0.05 && sw2 > 0.05)

                    test_key <- if (use_parametric) "ttest" else "wilcoxon"
                } else {
                    # Multiple groups. `overall_normal` starts TRUE, so if EVERY
                    # group is untestable (n < 3) it must not silently license a
                    # parametric test - require at least one group to have been
                    # testable and none to have failed.
                    overall_normal <- TRUE
                    any_testable <- FALSE
                    for (group in levels(data[[group_var]])) {
                        private$.checkpoint(flush = FALSE)
                        group_data <- data[data[[group_var]] == group, dep_var]
                        sw_p <- private$.safe_shapiro_p(group_data)
                        if (!is.na(sw_p)) {
                            any_testable <- TRUE
                            if (sw_p <= 0.05) {
                                overall_normal <- FALSE
                                break
                            }
                        }
                    }
                    # Welch's ANOVA when the variances differ - it is the correct
                    # parametric test there, and reduces to ordinary ANOVA when
                    # they do not.
                    test_key <- if (overall_normal && any_testable) {
                        if (unequal_var) "welch" else "anova"
                    } else {
                        "kruskal"
                    }
                }
            } else {
                test_key <- comparison_method  # ttest / wilcoxon / anova / kruskal
            }

            # Guard: t-test / Wilcoxon are only defined for exactly two groups.
            # Without this, forcing a 2-group test on >2 groups left p_value
            # unassigned and crashed the whole analysis. Fail soft instead.
            if (test_key %in% c("ttest", "wilcoxon") && n_groups != 2) {
                return(paste0(
                    "<div style='background-color: rgba(255, 202, 33, 0.23);padding:12px;border-radius:8px; color: inherit;'>",
                    .fmt(
                        .("The selected test (t-test or Wilcoxon) requires exactly two groups, but the grouping variable has {n} levels. Choose ANOVA or Kruskal-Wallis, or use Automatic selection."),
                        n = n_groups),
                    "</div>"
                ))
            }

            # Human-readable (possibly translated) label, for DISPLAY only.
            test_method <- switch(test_key,
                "ttest" = .("Welch's t-test"),
                "wilcoxon" = .("Wilcoxon rank-sum test"),
                "anova" = .("one-way ANOVA"),
                "welch" = .("Welch's ANOVA"),
                "kruskal" = .("Kruskal-Wallis test"),
                test_key
            )

            p_value <- NULL
            test_details <- NULL
            effect_size_html <- ""
            assumption_note <- ""

            # Every test is wrapped: a statistical routine that throws must not
            # take the rest of the output with it.
            run <- function(expr) tryCatch(expr, error = function(e) e)

            # Perform the selected test (dispatch on the untranslated key)
            if (test_key == "ttest") {
                group_levels <- levels(data[[group_var]])
                group1_data <- data[data[[group_var]] == group_levels[1], dep_var]
                group2_data <- data[data[[group_var]] == group_levels[2], dep_var]

                test_result <- run(t.test(group1_data, group2_data))
                if (!inherits(test_result, "condition")) {
                    test_stat <- round(test_result$statistic, 4)
                    p_value <- test_result$p.value
                    test_details <- paste0("t = ", test_stat, ", df = ", round(test_result$parameter, 1))
                    if (effect_size_flag) {
                        # t.test() defaults to var.equal = FALSE, so the reported t
                        # is WELCH's. Pair it with the unpooled (Welch-consistent)
                        # standardiser rather than the pooled SD, which belongs to
                        # Student's t and would be a different estimator.
                        sd_unpooled <- sqrt((stats::var(group1_data) + stats::var(group2_data)) / 2)
                        d <- if (is.finite(sd_unpooled) && sd_unpooled > 0)
                            (mean(group1_data) - mean(group2_data)) / sd_unpooled else NA_real_
                        effect_size_html <- paste0(
                            "<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>",
                            .("Cohen's d (unpooled SD, matching Welch's t):"),
                            "</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>",
                            if (is.na(d)) .("not estimable (zero variance)") else sprintf("%.3f", d),
                            "</td></tr>")
                    }
                }

            } else if (test_key == "wilcoxon") {
                group_levels <- levels(data[[group_var]])
                group1_data <- data[data[[group_var]] == group_levels[1], dep_var]
                group2_data <- data[data[[group_var]] == group_levels[2], dep_var]

                test_result <- run(wilcox.test(group1_data, group2_data))
                if (!inherits(test_result, "condition")) {
                    test_stat <- round(test_result$statistic, 4)
                    p_value <- test_result$p.value
                    test_details <- paste0("W = ", test_stat)
                    if (effect_size_flag) {
                        # This panel does not implement a rank-based effect size for the
                        # Wilcoxon test. State this rather than silently dropping the request.
                        effect_size_html <- paste0("<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Effect size:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>", .("This panel reports standardized mean differences only with the t-test. A rank-based effect size for the Wilcoxon test is not implemented."), "</td></tr>")
                    }
                }

            } else if (test_key %in% c("anova", "welch")) {
                dep_safe <- private$.escapeVar(dep_var)
                group_safe <- private$.escapeVar(group_var)
                fml <- jmvcore::asFormula(paste(dep_safe, "~", group_safe))

                if (test_key == "welch") {
                    # withBaseFormulaChar(): logistf pulls in formula.tools, whose
                    # as.character.formula returns one string where base R returns
                    # three, and stats::oneway.test rejects every formula with
                    # "a two-sided formula is required". Loading this package is
                    # enough to trigger it, so Welch's ANOVA fails for every user
                    # unless the call is shielded. See R/utils-ggstatsplot.R.
                    ow <- run(withBaseFormulaChar(
                        stats::oneway.test(fml, data = data, var.equal = FALSE)))
                    if (!inherits(ow, "condition")) {
                        p_value <- ow$p.value
                        test_details <- paste0("F(", round(ow$parameter[1], 0), ",",
                                               round(ow$parameter[2], 2), ") = ",
                                               round(ow$statistic, 4))
                    }
                } else {
                    aov_result <- run(aov(fml, data = data))
                    if (!inherits(aov_result, "condition")) {
                        summary_aov <- summary(aov_result)
                        p_value <- summary_aov[[1]]$`Pr(>F)`[1]
                        test_details <- paste0("F(", summary_aov[[1]]$Df[1], ",",
                                               summary_aov[[1]]$Df[2], ") = ",
                                               round(summary_aov[[1]]$`F value`[1], 4))
                    }
                    if (unequal_var)
                        assumption_note <- paste0(
                            "<div style='background-color: rgba(216, 33, 50, 0.18);color: inherit;padding:10px;border-radius:6px;margin-top:10px;'>",
                            sprintf(.("Equal variances are doubtful (Bartlett p = %s), and ordinary ANOVA assumes them. With unequal variances and unequal group sizes it can report a significant difference where none exists. Use Welch's ANOVA (choose Automatic) or Kruskal-Wallis."),
                                    private$.fmtP(var_p)),
                            "</div>")
                }

            } else if (test_key == "kruskal") {
                dep_safe <- private$.escapeVar(dep_var)
                group_safe <- private$.escapeVar(group_var)
                kw_result <- run(kruskal.test(jmvcore::asFormula(paste(dep_safe, "~", group_safe)), data = data))
                if (!inherits(kw_result, "condition")) {
                    test_stat <- round(kw_result$statistic, 4)
                    p_value <- kw_result$p.value
                    test_details <- paste0("\u03c7\u00b2 = ", test_stat, ", df = ", kw_result$parameter)
                }
            }

            # Safety net: if no branch produced a result, fail soft (never crash).
            if (is.null(p_value) || !is.finite(p_value)) {
                return(paste0(
                    "<div style='background-color: rgba(255, 202, 33, 0.23);padding:12px;border-radius:8px; color: inherit;'>",
                    .("The group comparison could not be computed for this data. Check that every group has at least two distinct values."),
                    "</div>"))
            }

            # Post-hoc pairwise comparisons.
            #
            # This is what the P-value Adjustment option is FOR. Previously it
            # called p.adjust() on the single omnibus p-value, which is a no-op by
            # construction - p.adjust(0.03, "bonferroni") is 0.03 - so the row
            # labelled "Adjusted (bonferroni)" always showed the unadjusted number
            # and told the user a correction had been applied when none had.
            pairwise_html <- ""
            if (n_groups > 2 && adjust_method != "none") {
                pw <- run(if (test_key == "kruskal")
                              stats::pairwise.wilcox.test(data[[dep_var]], data[[group_var]],
                                                          p.adjust.method = adjust_method, exact = FALSE)
                          else
                              stats::pairwise.t.test(data[[dep_var]], data[[group_var]],
                                                     p.adjust.method = adjust_method,
                                                     pool.sd = (test_key == "anova")))
                if (!inherits(pw, "condition") && !is.null(pw$p.value)) {
                    m <- pw$p.value
                    rows <- ""
                    for (i in seq_len(nrow(m))) for (j in seq_len(ncol(m))) {
                        if (is.na(m[i, j])) next
                        rows <- paste0(rows, "<tr><td style='padding:6px;border:1px solid #ddd;'>",
                            htmltools::htmlEscape(rownames(m)[i]), " vs ",
                            htmltools::htmlEscape(colnames(m)[j]),
                            "</td><td style='padding:6px;border:1px solid #ddd;'>",
                            private$.fmtP(m[i, j]), "</td></tr>")
                    }
                    pairwise_html <- paste0(
                        "<h4 style='color:#7b1fa2;margin-bottom:6px;'>",
                        sprintf(.("Pairwise comparisons (%s-adjusted)"), adjust_method), "</h4>",
                        "<table style='width:100%; border-collapse:collapse;'>",
                        "<tr style='background-color: rgba(33, 33, 33, 0.14); color: inherit;'><th style='padding:6px;border:1px solid #ddd;'>",
                        .("Comparison"), "</th><th style='padding:6px;border:1px solid #ddd;'>",
                        .("Adjusted p"), "</th></tr>", rows, "</table>")
                }
            } else if (adjust_method != "none") {
                pairwise_html <- paste0(
                    "<p style='font-size:12px;color:#7b1fa2;'><em>",
                    .("A p-value adjustment was requested, but only one comparison is being made, so there is nothing to adjust for. Adjustment applies to the pairwise comparisons shown when there are three or more groups."),
                    "</em></p>")
            }

            # Create results HTML.
            # The "less than" is an entity here for the same reason .fmtP()
            # documents above: valid HTML/XHTML and safe for anything that
            # strips tags. A browser would render the bare form correctly, so
            # this is correctness-of-output, not a rendering bug.
            significance <- if (p_value < 0.001) .("p &lt; 0.001") else
                          if (p_value < 0.01) .("p &lt; 0.01") else
                          if (p_value < 0.05) .("p &lt; 0.05") else .("not significant at the 0.05 level")

            comparison_html <- paste0(
                "<div style='background-color: rgba(153, 33, 170, 0.12); padding: 20px; border-radius: 8px; margin-bottom: 20px; color: inherit;'>",
                "<h3 style='color: #7b1fa2; margin-top: 0;'> Group Comparison Test</h3>",
                "<table style='width: 100%; border-collapse: collapse;'>",
                "<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Test Method:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>", test_method, "</td></tr>",
                "<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Test Statistic:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>", test_details, "</td></tr>",
                "<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>P-value:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>", private$.fmtP(p_value), "</td></tr>",
                effect_size_html,
                "<tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Result:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>", significance, "</td></tr>",
                "</table>",
                assumption_note,
                pairwise_html,
                "<p style='font-size: 12px; color: #7b1fa2; margin-top: 15px;'>",
                "<em>",
                if (comparison_method == "auto")
                    sprintf(.("%s was selected automatically from the normality and equal-variance checks."), test_method)
                else "",
                "</em></p></div>"
            )

            # Add copy-ready report sentence
            report_sentence <- private$.generate_report_sentence(test_method, p_value, levels(data[[group_var]]))
            comparison_html <- paste0(comparison_html, report_sentence)

            return(comparison_html)
        },

        .generate_interpretation_guide = function(data, dep_var, group_var) {
            # Generate interpretation guide
            
            n_groups <- length(levels(data[[group_var]]))
            n_total <- nrow(data)
            
            interpretation_html <- paste0(
                "<div style='background-color: rgba(33, 159, 33, 0.1); padding: 20px; border-radius: 8px; color: inherit;'>",
                "<h3 style='color: #2e7d32; margin-top: 0;'> Raincloud Plot Interpretation Guide</h3>",
                
                "<h4 style='color: #2e7d32;'>Plot Summary:</h4>",
                "<ul>",
                "<li><strong>Variable:</strong> ", htmltools::htmlEscape(dep_var), " (distribution analysis)</li>",
                "<li><strong>Groups:</strong> ", n_groups, " groups defined by ", htmltools::htmlEscape(group_var), "</li>",
                "<li><strong>Observations:</strong> ", n_total, " data points</li>",
                "<li><strong>Visualization:</strong> ", 
                paste(c(
                    if (self$options$show_violin) "Half-violin (density)",
                    if (self$options$show_boxplot) "Box plot (quartiles)",
                    if (self$options$show_dots) "Data points (individual values)"
                ), collapse = " + "), "</li>",
                "</ul>",
                
                "<h4 style='color: #2e7d32;'>How to Read Raincloud Plots:</h4>",
                "<ul>",
                "<li><strong>Half-Violin:</strong> Shows probability density - wider areas indicate more data points</li>",
                "<li><strong>Box Plot:</strong> Shows median (line), quartiles (box), and outliers (points)</li>",
                "<li><strong>Data Points:</strong> Individual observations reveal fine-grained patterns</li>",
                "<li><strong>Shape Patterns:</strong> Symmetric, skewed, bimodal, or multimodal distributions</li>",
                "</ul>",
                
                "<h4 style='color: #2e7d32;'>Distribution Patterns to Look For:</h4>",
                "<ul>",
                "<li><strong>Symmetry:</strong> Bell-shaped density indicates normal distribution</li>",
                "<li><strong>Skewness:</strong> Tail extending to one side (left-skewed or right-skewed)</li>",
                "<li><strong>Multimodality:</strong> Multiple peaks suggest subgroups within data</li>",
                "<li><strong>Outliers:</strong> Points far from the main distribution</li>",
                "<li><strong>Spread:</strong> Width of distribution indicates variability</li>",
                "</ul>",
                
                "<h4 style='color: #2e7d32;'>Clinical/Research Applications:</h4>",
                "<ul>",
                "<li><strong>Biomarker Analysis:</strong> Compare distributions across patient groups</li>",
                "<li><strong>Treatment Effects:</strong> Visualize before/after treatment distributions</li>",
                "<li><strong>Quality Control:</strong> Identify unusual patterns in laboratory values</li>",
                "<li><strong>Subgroup Discovery:</strong> Detect hidden subpopulations in data</li>",
                "</ul>",
                
                "<p style='font-size: 12px; color: #2e7d32; margin-top: 15px;'>",
                "<em> Raincloud plots reveal distribution nuances that traditional box plots miss, making them ideal for exploratory data analysis and publication-quality visualizations.</em>",
                "</p></div>"
            )
            
            return(interpretation_html)
        },
        
        .generate_report_sentence = function(test_method, p_value, groups) {
            # This block is explicitly offered as "ready to copy into your research
            # report", so every word in it is a claim that ends up in a paper. The
            # previous wording made three that the data cannot support:
            #   "The t-test test comparing ..."      - test_method already says "test"
            #   "showed not significant differences" - accepts the null; absence of
            #                                          evidence is not evidence of absence
            #   "differ ... in their distributions"  - a t-test compares MEANS, and
            #                                          only Kruskal-Wallis/Wilcoxon
            #                                          speak to distributions
            # and printed "p = 0.000" for any small p.

            # `groups` is `levels(data[[group_var]])` (user factor labels) at the
            # caller - escape once here since they reach HTML <p> via report_text
            # below, then concatenated into comparison_html \u2192 setContent.
            groups <- htmltools::htmlEscape(groups)

            # What the test is actually about, so the sentence claims no more.
            quantity <- if (grepl("Wilcoxon|Kruskal", test_method))
                .("distributions") else .("means")

            p_txt <- private$.fmtP(p_value)
            p_txt <- if (base::startsWith(p_txt, "&lt;")) paste0("p ", p_txt) else paste0("p = ", p_txt)

            report_text <- if (p_value < 0.05)
                sprintf(.("A %s comparing %s found a statistically significant difference in %s (%s)."),
                        test_method, paste(groups, collapse = " vs "), quantity, p_txt)
            else
                sprintf(.("A %s comparing %s did not find a statistically significant difference in %s (%s). This does not establish that the groups are equivalent; the study may simply lack the power to detect a difference of clinical interest."),
                        test_method, paste(groups, collapse = " vs "), quantity, p_txt)
            
            return(paste0(
                "<div style='background-color: rgba(33, 152, 239, 0.13); padding: 15px; border-radius: 5px; margin: 10px 0; color: inherit;'>",
                "<h4 style='margin-top: 0; color: #1976d2;'> Copy-Ready Result</h4>",
                "<p style='font-family: monospace; background: white; padding: 10px; border: 1px solid #ddd; border-radius: 3px;'>",
                report_text,
                "</p>",
                "<small style='color: #666;'> This sentence is ready to copy into your research report</small>",
                "</div>"
            ))
        }

    ), # End of private list
    public = list(
        #' @description
        #' Generate R source code for Raincloud Plot analysis
        #' @return Character string with R syntax for reproducible analysis
        asSource = function() {
            dep_var <- self$options$dep_var

            if (is.null(dep_var))
                return("")

            # Emit every option EXACTLY ONCE via the base helper, which already
            # escapes variable names. Do NOT also emit dep_var/group_var manually:
            # .asArgs() iterates all options (including those two), so manual lines
            # would duplicate them and R would reject the repeated arguments.
            args <- ""
            if (!is.null(private$.asArgs)) {
                args <- private$.asArgs(incData = FALSE)
            }

            # Get package name dynamically
            pkg_name <- utils::packageName()
            if (is.null(pkg_name)) pkg_name <- "ClinicoPath"  # fallback

            # Build complete function call
            if (args != "")
                paste0(pkg_name, "::raincloud(\n    data = data,\n    ", args, ")")
            else
                paste0(pkg_name, "::raincloud(\n    data = data)")
        }
    ) # End of public list
)
