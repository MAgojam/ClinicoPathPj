#' @title Advanced Ridge Plot
#' @description Creates advanced ridgeline plots with robust statistical analysis
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @importFrom ggplot2 aes after_stat annotate element_blank element_line
#' @importFrom ggplot2 element_rect element_text facet_wrap geom_text geom_vline
#' @importFrom ggplot2 ggplot labeller labs margin scale_fill_brewer
#' @importFrom ggplot2 scale_fill_gradient scale_fill_manual scale_fill_viridis_d
#' @importFrom ggplot2 theme theme_classic theme_minimal
#' @importFrom grid unit
#' @importFrom dplyr across all_of distinct group_by mutate n summarise
#' @importFrom magrittr %>%
#' @importFrom effectsize cohens_d hedges_g eta_squared omega_squared
#'
#' @return An \code{R6} class generator object for the \code{jjridgesClass} backend; used internally by the jamovi analysis wrapper and not called directly.

jjridgesClass <- if (requireNamespace('jmvcore')) R6::R6Class(
    "jjridgesClass",
    inherit = jjridgesBase,
    
    # Constants for validation and defaults
    private = list(
        # Fixed seed for the sampling-based paths. Bayesian output uses
        # BayesFactor's MCMC and robust/effect-size CIs use bootstrapping, so
        # without this the SAME analysis reported different numbers on every
        # re-render - a credible interval that moves when nothing changed.

        # Clinical constants
        .MIN_SAMPLE_SIZE = 10,
        .MIN_GROUP_SIZE = 3,
        .MAX_OUTLIER_PROP = 0.05,
        .VIRIDIS_FALLBACK = c("#440154", "#414487", "#2A788E", "#22A884", "#7AD151", "#FDE725"),
        .CLINICAL_CB_SAFE_COLORS = c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"),

        # Option overrides for presets
        overrides = list(),

        # Notice collection helpers. A single Preformatted (plain-text) output item:
        # avoids BOTH the jmvcore::Notice serialization error from
        # self$results$insert(999, Notice) AND any HTML in notices (project convention:
        # notice content must be plain text). ====
        .noticeList = list(),

        # Collects per-comparison assumption-violation auto-switch messages so a
        # single summarized notice is shown instead of one per pairwise comparison
        # (which floods the panel with many groups). Reset in .generateTests.
        .assumptionSwitches = character(0),
        # Variance-heterogeneity notes: reported, but they do NOT trigger a test switch
        # (Welch already covers unequal variances - see .performSingleTest).
        .assumptionNotes = character(0),
        # Per-comparison "this row could not be computed" explanations. .performSingleTest
        # used to build these strings and return them in a `warning` element that nothing
        # ever read, so a blank NA row appeared with no reason given. Collected here and
        # emitted as one summarized notice in .generateTests. Reset in .generateTests.
        .testWarnings = character(0),

        .addNotice = function(type, title, content) {
            private$.noticeList[[length(private$.noticeList) + 1]] <- list(
                type = type,
                title = title,
                content = content
            )
            # Render immediately so early-return validation aborts still display the notice
            private$.renderNotices()
        },

        .renderNotices = function() {
            if (length(private$.noticeList) == 0) {
                self$results$notices$setContent("")
                return()
            }

            # Plain text only - notices avoid HTML by project convention; the Preformatted
            # output item renders this literally (no markup, no injection surface).
            blocks <- vapply(private$.noticeList, function(notice) {
                prefix <- switch(notice$type,
                    ERROR          = "ERROR: ",
                    STRONG_WARNING = "WARNING: ",
                    WARNING        = "WARNING: ",
                    "")
                paste0(prefix, notice$title, "\n", notice$content)
            }, character(1))

            self$results$notices$setContent(paste(blocks, collapse = "\n\n"))
        },

        .option = function(option) {
            if (option %in% names(private$overrides)) {
                return(private$overrides[[option]])
            }
            opt_obj <- self$options$option(option)
            if (!is.null(opt_obj))
                return(opt_obj$value)
            return(NULL)
        },

        # Auto-enable the fill legend when a fill variable is present but the user
        # left legend_position on "none". Recorded as an override so the fill colours
        # are explained in the plot. Because .applyClinicalPreset() resets
        # private$overrides <- list(), this MUST be re-applied after every
        # .applyClinicalPreset() call (both .init and .run) or the legend is hidden.
        .applyAutoLegendOverride = function() {
            # Only rescue the DEFAULT. This used to fire on any "none", so a user who
            # deliberately chose "Legend position: none" with a fill variable had it
            # rewritten to "right" and could never turn the legend off. self$options is
            # the raw, user-visible value; if it is anything other than the shipped
            # default the choice is deliberate and is left alone.
            default_pos <- "none"
            if (!is.null(self$options$fill_var) &&
                identical(self$options$legend_position, default_pos) &&
                private$.option("legend_position") == "none" &&
                isTRUE(self$options$show_fill_legend)) {
                private$overrides$legend_position <- "right"
            }
        },

        .init = function() {
            # Apply presets first to ensure UI reflects overrides
            private$.applyClinicalPreset()

            # Auto-enable legend when fill variable is specified
            private$.applyAutoLegendOverride()

            # Check if required variables are provided
            if (is.null(self$options$x_var) || is.null(self$options$y_var)) {
                self$results$instructions$setContent(paste0(
                    "<h3>", .("Ridge Plot Instructions"), "</h3>",
                    "<p>", .("Welcome to the Advanced Ridge Plot analysis!"), "</p>",

                    "<div style='background-color: rgba(33, 152, 255, 0.07); border-left:4px solid #2196F3; padding:15px; margin:15px 0; color: inherit;'>",
                        "<h4 style='color:#2196F3; margin-top:0;'> ", .("Clinical Guidance"), "</h4>",
                        "<p><strong>", .("When to Use Ridge Plots:"), "</strong></p>",
                        "<ul style='margin-bottom:10px;'>",
                            "<li>", .("Compare biomarker distributions between patient groups"), "</li>",
                            "<li>", .("Visualize treatment response patterns across disease stages"), "</li>",
                            "<li>", .("Show how continuous measures vary by pathological categories"), "</li>",
                            "<li>", .("Display age or tumor size distributions by clinical characteristics"), "</li>",
                        "</ul>",
                        "<p><strong>", .("Key Considerations:"), "</strong></p>",
                        "<ul style='margin-bottom:10px;'>",
                            "<li>", .("Minimum 3-5 observations per group for reliable curves"), "</li>",
                            "<li>", .("Wide ridges = high variability; narrow ridges = consistent values"), "</li>",
                            "<li>", .("Multiple peaks may indicate distinct clinical subgroups"), "</li>",
                            "<li>", .("Compare ridge positions (left/right shift) for group differences"), "</li>",
                        "</ul>",
                    "</div>",

                    "<p><strong>", .("Required:"), "</strong></p>",
                    "<ul>",
                        "<li><strong>", .("X Variable:"), "</strong> ", .("Continuous variable for distributions"), "</li>",
                        "<li><strong>", .("Y Variable:"), "</strong> ", .("Grouping variable for separate ridges"), "</li>",
                    "</ul>",
                    "<p><strong>", .("Optional:"), "</strong></p>",
                    "<ul>",
                        "<li><strong>", .("Fill Variable:"), "</strong> ", .("Color-code segments within ridges"), "</li>",
                        "<li><strong>", .("Facet Variable:"), "</strong> ", .("Create separate panels"), "</li>",
                    "</ul>",
                    "<p><strong>", .("Features:"), "</strong></p>",
                    "<ul>",
                        "<li>", .("Multiple plot types (density, histogram, gradient, violin)"), "</li>",
                        "<li>", .("Statistical overlays with p-values and effect sizes"), "</li>",
                        "<li>", .("Boxplots, quantiles, and mean/median lines"), "</li>",
                        "<li>", .("Publication-ready themes and customization"), "</li>",
                    "</ul>",
                    "<p><strong>", .("Export Options:"), "</strong></p>",
                    "<ul>",
                        "<li>", .("Adjust plot width and height in Export Options"), "</li>",
                        "<li>", .("Choose the export resolution in jamovi's Save Image As dialog"), "</li>",
                        "<li>", .("Use right-click \u2192 Save Image As for quick export"), "</li>",
                    "</ul>"
                ))
                self$results$instructions$setVisible(visible = TRUE)
                self$results$plot$setVisible(visible = FALSE)
                self$results$statistics$setVisible(visible = FALSE)
                self$results$tests$setVisible(visible = FALSE)
                self$results$interpretation$setVisible(visible = FALSE)
                return()
            }

            # Set visibility based on options
            self$results$instructions$setVisible(visible = FALSE)
            self$results$plot$setVisible(visible = TRUE)
            self$results$statistics$setVisible(visible = TRUE)
            self$results$tests$setVisible(visible = private$.option("show_stats"))
            self$results$interpretation$setVisible(visible = TRUE)

            # Set plot dimensions - increase size if legends are likely to be shown
            plot_width <- self$options$width
            plot_height <- self$options$height

            # Get effective legend position (considering overrides)
            effective_legend_pos <- private$.option("legend_position")

            # Increase width if fill legend is shown and legend position is right/left
            if (!is.null(self$options$fill_var) &&
                (self$options$show_fill_legend %||% TRUE) &&
                effective_legend_pos %in% c("right", "left")) {
                plot_width <- max(plot_width, 900)  # Minimum 900px when right/left legend
            }

            # Increase height if fill legend is shown and legend position is top/bottom
            if (!is.null(self$options$fill_var) &&
                (self$options$show_fill_legend %||% TRUE) &&
                effective_legend_pos %in% c("top", "bottom")) {
                plot_height <- max(plot_height, 650)  # Minimum 650px when top/bottom legend
            }

            # Increase height if faceting is used
            if (!is.null(self$options$facet_var)) {
                plot_height <- max(plot_height, 700)  # Minimum 700px when faceting
            }

            self$results$plot$setSize(plot_width, plot_height)
        },
        
        .validateInputs = function() {
            warnings <- c()
            
            # Check variable selection
            if (is.null(self$options$x_var)) {
                jmvcore::reject(.("Please select a continuous variable for X (Distribution)"))
            }
            if (is.null(self$options$y_var)) {
                jmvcore::reject(.("Please select a grouping variable for Y (Groups)"))
            }

            # Check data availability
            if (is.null(self$data) || nrow(self$data) == 0) {
                jmvcore::reject(.("No data available for analysis"))
            }

            # Type checks
            x_col <- self$data[[self$options$x_var]]
            y_col <- self$data[[self$options$y_var]]
            if (!is.numeric(x_col)) {
                jmvcore::reject(.("X variable must be numeric for ridge plotting. Selected: {var}"), var = self$options$x_var)
            }
            if (!is.factor(y_col) && !is.character(y_col)) {
                jmvcore::reject(.("Y variable should be categorical (factor/character). Selected: {var}"), var = self$options$y_var)
            }
            
            # Check minimum sample size
            if (nrow(self$data) < private$.MIN_SAMPLE_SIZE) {
                warnings <- c(warnings, .fmt(
                    .("Sample size (n={n}) is below recommended minimum of {min} for reliable ridge plot analysis"),
                    n = nrow(self$data), min = private$.MIN_SAMPLE_SIZE))
            }

            # Check basic variability of X
            n_unique_x <- length(unique(x_col[!is.na(x_col)]))
            if (n_unique_x < 3) {
                warnings <- c(warnings, .("X variable has very few unique values; density shapes may be misleading."))
            }
            
            return(warnings)
        },
        
        .validateData = function(plot_data) {
            warnings <- c()
            
            # Check for minimum group count
            n_groups <- length(unique(plot_data$y))
            if (n_groups < 2) {
                jmvcore::reject(.("At least 2 groups required for ridge plot comparison"))
            }
            
            # Check group sizes with clinical context
            group_counts <- table(plot_data$y)
            small_groups <- group_counts[group_counts < private$.MIN_GROUP_SIZE]
            if (length(small_groups) > 0) {
                warnings <- c(warnings, .fmt(
                    .("Groups with fewer than {min} observations may show unreliable density estimates: {groups}"),
                    min = private$.MIN_GROUP_SIZE, groups = paste(names(small_groups), collapse = ", ")))
            }
            
            # Check for extreme outliers that could affect interpretation
            if (length(plot_data$x) > 0) {
                z_scores <- abs(scale(plot_data$x))
                outlier_prop <- sum(z_scores > 3, na.rm = TRUE) / length(z_scores)
                if (outlier_prop > private$.MAX_OUTLIER_PROP) {
                    warnings <- c(warnings, .fmt(
                        .("High proportion of extreme outliers detected ({pct}%). Consider reviewing data quality or using robust statistical options."),
                        pct = round(outlier_prop * 100, 1)))
                }
            }
            
            # Check for highly skewed distributions
            if (length(plot_data$x) > 10) {
                if (requireNamespace("moments", quietly = TRUE)) {
                    skewness <- moments::skewness(plot_data$x, na.rm = TRUE)
                } else {
                    # Fallback calculation for skewness when moments package is not available
                    x <- plot_data$x[!is.na(plot_data$x)]
                    if (length(x) > 0) {
                        m <- mean(x)
                        s <- sd(x)
                        if (s > 0) {
                            skewness <- sum(((x - m) / s)^3) / length(x)
                        } else {
                            skewness <- 0
                        }
                    } else {
                        skewness <- 0
                    }
                }
                # is.finite(): a NaN/NA skewness (constant or non-finite x) would make the
                # `if` throw "missing value where TRUE/FALSE needed" and kill the analysis.
                if (is.finite(skewness) && abs(skewness) > 2) {
                    warnings <- c(warnings, .("Data shows high skewness. Consider log transformation if appropriate for your clinical context."))
                }
            }
            
            return(warnings)
        },
        
        .validateQuantiles = function(quantile_string) {
            tryCatch({
                # suppressWarnings: the NA test below is the real check, and the raw
                # "NAs introduced by coercion" warning otherwise reached the Analysis
                # Notes panel duplicating the notice raised in the handler.
                vals <- suppressWarnings(
                    as.numeric(trimws(strsplit(quantile_string, ",")[[1]])))
                
                # Check for parsing errors
                if (any(is.na(vals))) {
                    stop(.("Non-numeric values detected in quantiles"))
                }
                
                # Check valid range
                if (any(vals < 0 | vals > 1)) {
                    stop(.("Quantile values must be between 0 and 1"))
                }
                
                # Check not empty
                if (length(vals) == 0) {
                    stop(.("No quantile values provided"))
                }
                
                # Sort quantiles
                vals <- sort(vals)
                return(vals)
                
            }, error = function(e) {
                # The plot is built inside .run(), so the silent substitution of the
                # default quantiles can be disclosed in the notices output (jamovi never
                # shows base warning() output to the user).
                private$.addNotice(
                    "WARNING",
                    .("Invalid quantiles"),
                    .fmt(
                        .("{error}. The default quantiles (0.25, 0.5, 0.75) were drawn instead."),
                        error = conditionMessage(e)))
                c(0.25, 0.5, 0.75)
            })
        },
        
        .generateClinicalSummary = function(data, has_stats = FALSE) {
            n_groups <- length(unique(data$y))
            n_total <- nrow(data)
            x_var_safe <- htmltools::htmlEscape(self$options$x_var)
            y_var_safe <- htmltools::htmlEscape(self$options$y_var)

            # Basic summary
            summary <- paste0(
                "<div class='clinical-summary' style='background-color: rgba(138, 155, 172, 0.06); border-left:4px solid #007bff; padding:15px; margin:10px 0; color: inherit;'>",
                "<h4 style='color:#007bff; margin-top:0;'>", .("Clinical Summary"), "</h4>",
                "<p><strong>", .("Analysis:"), "</strong> ", .("Ridge plot comparing the distribution of"), " <strong>",
                x_var_safe, "</strong> ", .("across"), " <strong>", n_groups, " ", .("groups"), "</strong> ", .("defined by"), " <strong>",
                y_var_safe, "</strong>.</p>",
                "<p><strong>", .("Sample:"), "</strong> n = ", n_total, " ", .("total observations across all groups"), ".</p>"
            )
            
            # Add interpretation guidance
            summary <- paste0(summary,
                "<p><strong>", .("Interpretation Guide:"), "</strong></p>",
                "<ul style='margin-bottom:10px;'>",
                "<li><strong>", .("Ridge Shape:"), "</strong> ", .("Wider ridges = more variability; Narrow ridges = consistent values"), "</li>",
                "<li><strong>", .("Ridge Position:"), "</strong> ", .("Left/right shift indicates lower/higher average values"), "</li>",
                "<li><strong>", .("Multiple Peaks:"), "</strong> ", .("May indicate subgroups or distinct clinical phenotypes"), "</li>",
                "<li><strong>", .("Overlap:"), "</strong> ", .("Similar distributions between groups; Separation = distinct patterns"), "</li>",
                "</ul></div>"
            )
            
            return(summary)
        },

        .generateReportSummary = function(data, has_stats = FALSE) {
            # Generate copy-ready plain text summary for pathology reports
            x_var <- htmltools::htmlEscape(self$options$x_var)
            y_var <- htmltools::htmlEscape(self$options$y_var)
            n_groups <- length(unique(data$y))
            n_total <- nrow(data)

            # Calculate basic descriptive statistics per group
            stats_by_group <- data %>%
                group_by(y) %>%
                summarise(
                    n = n(),
                    mean = mean(x, na.rm = TRUE),
                    sd = sd(x, na.rm = TRUE),
                    median = median(x, na.rm = TRUE),
                    q1 = quantile(x, 0.25, na.rm = TRUE),
                    q3 = quantile(x, 0.75, na.rm = TRUE),
                    .groups = 'drop'
                )

            # Build plain text summary
            text_summary <- paste0(
                "<div style='background-color: rgba(255, 203, 33, 0.14); border:1px solid #ffc107; padding:15px; margin:10px 0; font-family:monospace; color: inherit;'>",
                "<h4 style='color:#f57c00; margin-top:0;'> Copy-Ready Report Summary</h4>",
                "<p style='font-size:11px; opacity:0.75; margin-bottom:10px;'>",
                "Select and copy the text below for inclusion in reports or presentations.",
                "</p>",
                "<div style='background-color: rgba(127, 127, 127, 0.08); color: inherit; padding:12px; border:1px solid rgba(127, 127, 127, 0.35);'>"
            )

            # Add header
            text_summary <- paste0(text_summary,
                "<p><strong>RIDGE PLOT ANALYSIS</strong></p>",
                "<p>Variable: ", x_var, " by ", y_var, "</p>",
                "<p>Total N = ", n_total, " across ", n_groups, " groups</p>",
                "<p></p>"
            )

            # Add group-specific summaries
            text_summary <- paste0(text_summary, "<p><strong>DESCRIPTIVE STATISTICS BY GROUP:</strong></p>")
            for (i in seq_len(nrow(stats_by_group))) {
                row <- stats_by_group[i, ]
                text_summary <- paste0(text_summary,
                    "<p>", htmltools::htmlEscape(as.character(row$y)), " (n=", row$n, "): ",
                    "Mean=", sprintf("%.2f", row$mean), " (SD=", sprintf("%.2f", row$sd), "), ",
                    "Median=", sprintf("%.2f", row$median), " (IQR: ",
                    sprintf("%.2f", row$q1), "-", sprintf("%.2f", row$q3), ")",
                    "</p>"
                )
            }

            # Add statistical test results if available
            if (has_stats && !is.null(self$results$tests) && self$results$tests$rowCount > 0) {
                text_summary <- paste0(text_summary, "<p></p><p><strong>STATISTICAL COMPARISONS:</strong></p>")
                test_type <- private$.option("test_type")
                test_name <- switch(test_type,
                    parametric = "parametric test",
                    nonparametric = "non-parametric test",
                    robust = "robust test",
                    bayes = "Bayesian test",
                    "statistical test"
                )

                # Report the tests that were actually RUN, not the one that was requested.
                # When parametric assumptions fail, .performSingleTest silently switches that
                # comparison to Wilcoxon, so the table can hold a mix. This block used to print
                # the requested test_type regardless: on five groups drawn from one N(10, 2),
                # a single chance Shapiro result (p = 0.031) switched 4 of 10 comparisons to
                # Wilcoxon while this text still read "Method: Parametric". That paragraph is
                # explicitly offered as copy-ready text for manuscripts, so it must not
                # misdescribe the analysis.
                if (self$results$tests$rowCount > 0) {
                    methods_used <- tryCatch(self$results$tests$asDF$method,
                                             error = function(e) character(0))
                    methods_used <- methods_used[!is.na(methods_used) & nzchar(methods_used)]
                    method_line <- if (length(methods_used) == 0) {
                        tools::toTitleCase(gsub("_", " ", test_type))
                    } else {
                        tab <- sort(table(methods_used), decreasing = TRUE)
                        if (length(tab) == 1) names(tab)[1]
                        else paste0("mixed - ",
                                    paste0(names(tab), " (", as.integer(tab), ")", collapse = ", "),
                                    "; requested ", tools::toTitleCase(gsub("_", " ", test_type)))
                    }
                    text_summary <- paste0(text_summary,
                        "<p>Method: ", method_line, "</p>",
                        if (length(unique(methods_used)) > 1)
                            paste0("<p>Note: not every comparison used the same test. Some ",
                                   "comparisons fell back to a different method or could not ",
                                   "be computed; the Method column of the statistical table ",
                                   "records what each row actually used.</p>")
                        else "",
                        "<p>See full statistical table for p-values, effect sizes, and confidence intervals.</p>"
                    )
                }
            }

            text_summary <- paste0(text_summary,
                "</div>",
                "<p style='font-size:10px; opacity:0.6; margin-top:10px;'>",
                "Generated by ClinicoPath Advanced Ridge Plot Analysis",
                "</p>",
                "</div>"
            )

            return(text_summary)
        },

        .generateAboutPanel = function() {
            # Comprehensive educational guide about ridge plots
            html <- paste0(
                "<div style='background-color: rgba(33, 159, 43, 0.1); border-left:4px solid #4caf50; padding:15px; margin:10px 0; color: inherit;'>",
                "<h3 style='color:#2e7d32; margin-top:0;'> About Ridge Plots</h3>",

                "<h4 style='color:#2e7d32;'>What are Ridge Plots?</h4>",
                "<p>Ridge plots (also called ridgeline plots or joyplots) display the distribution of a ",
                "continuous variable across multiple groups as partially overlapping density curves. ",
                "Each 'ridge' shows how values are distributed within one group, making it easy to ",
                "compare distribution shapes, central tendencies, and variability across groups.</p>",

                "<h4 style='color:#2e7d32;'>Clinical Applications</h4>",
                "<ul>",
                "<li><strong>Biomarker Analysis:</strong> Compare Ki-67 index, CD3+ counts, or receptor expression across tumor grades</li>",
                "<li><strong>Treatment Response:</strong> Visualize tumor size reduction across different treatment arms</li>",
                "<li><strong>Disease Staging:</strong> Show age or biomarker distributions across TNM stages</li>",
                "<li><strong>Temporal Patterns:</strong> Display lab values over time periods or disease progression stages</li>",
                "<li><strong>Pathology Scoring:</strong> Compare continuous measurements (mitotic counts, vessel density) by diagnosis</li>",
                "</ul>",

                "<h4 style='color:#2e7d32;'>How to Interpret Ridge Plots</h4>",
                "<ul>",
                "<li><strong>Ridge Width:</strong> Wide = high variability; Narrow = consistent values within group</li>",
                "<li><strong>Ridge Position:</strong> Left-shifted = lower values; Right-shifted = higher values</li>",
                "<li><strong>Ridge Height:</strong> Indicates probability density (taller = more observations in that range)</li>",
                "<li><strong>Multiple Peaks:</strong> May indicate distinct subpopulations or bimodal distributions</li>",
                "<li><strong>Overlap:</strong> Substantial overlap = similar distributions; Separation = distinct patterns</li>",
                "<li><strong>Skewness:</strong> Asymmetric ridges indicate skewed data (common in pathology measurements)</li>",
                "</ul>",

                "<h4 style='color:#2e7d32;'>When to Use Ridge Plots vs. Alternatives</h4>",
                "<p><strong>Use Ridge Plots When:</strong></p>",
                "<ul>",
                "<li>You have 3+ groups to compare (works well up to ~10 groups)</li>",
                "<li>Understanding distribution shape is important (not just mean differences)</li>",
                "<li>You want to detect bimodality or subgroups within categories</li>",
                "<li>Data is continuous and you have sufficient observations per group (n\u226520 recommended)</li>",
                "</ul>",

                "<p><strong>Consider Alternatives When:</strong></p>",
                "<ul>",
                "<li>Only 2 groups \u2192 Use violin plots or density plots side-by-side</li>",
                "<li>Focus on summary statistics only \u2192 Use box plots or error bars</li>",
                "<li>Categorical data \u2192 Use bar charts or mosaic plots</li>",
                "<li>Very few observations per group (n<10) \u2192 Individual data points may be better</li>",
                "</ul>",

                "<h4 style='color:#2e7d32;'>Plot Type Options</h4>",
                "<ul>",
                "<li><strong>Density Ridges:</strong> Smooth curves showing probability density (default, best for most cases)</li>",
                "<li><strong>Density with Gradient:</strong> Color intensity shows density within each ridge</li>",
                "<li><strong>Histogram Ridges:</strong> Discrete bins instead of smooth curves (good for small samples)</li>",
                "<li><strong>Violin Ridges:</strong> Symmetric mirrored densities (emphasizes shape comparison)</li>",
                "</ul>",

                "<h4 style='color:#2e7d32;'>Statistical Considerations</h4>",
                "<ul>",
                "<li><strong>Independence:</strong> Statistical tests assume independent observations (one per subject)</li>",
                "<li><strong>Sample Size:</strong> Minimum 3-5 observations per group for meaningful curves; 20+ recommended</li>",
                "<li><strong>Effect Size:</strong> Use nonparametric effect sizes (Cliff's Delta, Hodges-Lehmann) for skewed pathology data</li>",
                "<li><strong>Multiple Testing:</strong> Apply p-value correction (Bonferroni, FDR) when comparing many groups</li>",
                "</ul>",

                "<h4 style='color:#2e7d32;'>Publication Tips</h4>",
                "<ul>",
                "<li>Export at high resolution with right-click \u2192 Save image as (jamovi sets the resolution there)</li>",
                "<li>Use colorblind-safe palettes (Clinical or Viridis)</li>",
                "<li>Add boxplots inside ridges to show quartiles and outliers</li>",
                "<li>Label axes clearly with units (e.g., 'Ki-67 Index (%)', 'Tumor Size (mm)')</li>",
                "<li>Report statistical test choice and justification in figure legend</li>",
                "</ul>",

                "</div>"
            )

            return(html)
        },

        .generateAssumptionsPanel = function() {
            # Statistical assumptions and caveats for selected test type
            test_type <- private$.option("test_type")
            has_stats <- private$.option("show_stats")

            if (!has_stats) {
                html <- paste0(
                    "<div style='background-color: rgba(255, 202, 33, 0.23); border-left:4px solid #ffc107; padding:15px; margin:10px 0; color: inherit;'>",
                    "<h4 style='color:#856404; margin-top:0;'> Statistical Testing Disabled</h4>",
                    "<p>Enable 'Show Statistics' to view statistical assumptions and methodological notes.</p>",
                    "</div>"
                )
                return(html)
            }

            # Build assumptions based on test type
            html <- paste0(
                "<div style='background-color: rgba(255, 202, 33, 0.23); border-left:4px solid #ffc107; padding:15px; margin:10px 0; color: inherit;'>",
                "<h3 style='color:#856404; margin-top:0;'> Statistical Assumptions &amp; Caveats</h3>",
                "<p><strong>Selected Test Type:</strong> ", tools::toTitleCase(gsub("_", " ", test_type)), "</p>"
            )

            if (test_type == "parametric") {
                html <- paste0(html,
                    "<h4 style='color:#856404;'>Parametric Test Assumptions</h4>",
                    "<ul>",
                    "<li><strong>Normality:</strong> Data within each group should be approximately normally distributed. ",
                    "Ridge plots showing symmetric, bell-shaped curves suggest normality. Skewed or multimodal ridges violate this assumption.</li>",
                    "<li><strong>Independence:</strong> Each observation must be independent (one measurement per subject). ",
                    "Repeated measures, matched pairs, or clustered data violate independence.</li>",
                    "<li><strong>Homogeneity of Variance:</strong> Groups should have similar spread (variance). ",
                    "Ridge widths should be comparable across groups.</li>",
                    "</ul>",
                    "<p><strong>Tests Used:</strong> Independent t-test on every pair of groups. With 3 or more groups this analysis reports PAIRWISE comparisons, not an omnibus one-way ANOVA; the p-values are adjusted for multiplicity by the selected method.</p>",
                    "<p><strong>When Violated:</strong> Consider nonparametric tests if distributions are skewed, or robust tests if variances differ.</p>"
                )
            } else if (test_type == "nonparametric") {
                html <- paste0(html,
                    "<h4 style='color:#856404;'>Non-parametric Test Assumptions</h4>",
                    "<ul>",
                    "<li><strong>Independence:</strong> Each observation must be independent. This is still required for non-parametric tests.</li>",
                    "<li><strong>Ordinal or Continuous Data:</strong> Variables should be at least ordinal scale.</li>",
                    "<li><strong>Similar Distributions:</strong> For Mann-Whitney/Kruskal-Wallis, groups should have similar distribution shapes ",
                    "(ridges with similar shapes but different positions). If shapes differ, tests compare distributions rather than medians.</li>",
                    "</ul>",
                    "<p><strong>Tests Used:</strong> Mann-Whitney U (Wilcoxon rank-sum) test on every pair of groups. With 3 or more groups this analysis reports PAIRWISE comparisons, not an omnibus Kruskal-Wallis test; the p-values are adjusted for multiplicity by the selected method.</p>",
                    "<p><strong>Advantages:</strong> Robust to outliers and skewed distributions common in pathology data (e.g., mitotic counts, lymph node involvement).</p>",
                    "<p><strong>Effect Sizes:</strong> Cliff's Delta shows probability one group has higher values; Hodges-Lehmann estimates typical difference.</p>"
                )
            } else if (test_type == "robust") {
                html <- paste0(html,
                    "<h4 style='color:#856404;'>Robust Test Assumptions</h4>",
                    "<ul>",
                    "<li><strong>Independence:</strong> Each observation must be independent.</li>",
                    "<li><strong>Outlier Resistance:</strong> Robust tests use trimmed means (default 20% trimming), reducing outlier influence.</li>",
                    "<li><strong>Heterogeneity Tolerance:</strong> Does not assume equal variances across groups.</li>",
                    "</ul>",
                    "<p><strong>Tests Used:</strong> Yuen's trimmed-means test (a Welch-type robust alternative to the t-test) on every pair of groups; no omnibus test is computed.</p>",
                    "<p><strong>Best For:</strong> Data with unequal variances, mild outliers, or slight departures from normality.</p>",
                    "<p><strong>Clinical Scenarios:</strong> Laboratory values with occasional extreme results, tumor measurements with outliers.</p>"
                )
            } else if (test_type == "bayes") {
                html <- paste0(html,
                    "<h4 style='color:#856404;'>Bayesian Test Notes</h4>",
                    "<ul>",
                    "<li><strong>Bayes Factor Interpretation:</strong> BF10 > 3 = moderate evidence for difference; BF10 > 10 = strong evidence; ",
                    "BF10 < 1/3 = evidence for no difference.</li>",
                    "<li><strong>Prior Assumptions:</strong> Uses default Cauchy prior (scale=0.707). Results sensitive to prior choice.</li>",
                    "<li><strong>Computational Requirements:</strong> Requires BayesFactor package. May be slow for large datasets.</li>",
                    "</ul>",
                    "<p><strong>Advantages:</strong> Provides evidence for null hypothesis (no difference), not just failure to reject null.</p>",
                    "<p><strong>Limitations:</strong> Requires understanding of Bayesian inference; less familiar to many clinical reviewers.</p>"
                )
            }

            # Universal caveats
            html <- paste0(html,
                "<h4 style='color:#856404;'>Universal Considerations</h4>",
                "<ul>",
                "<li><strong>Sample Size:</strong> Small samples (n<20 per group) have low statistical power. Non-significant results may reflect insufficient data.</li>",
                "<li><strong>Multiple Testing:</strong> Comparing many groups increases false positive risk. ",
                "Apply p-value correction (Bonferroni, Holm, or FDR) when making multiple comparisons.</li>",
                "<li><strong>Clinical vs. Statistical Significance:</strong> Statistically significant differences may not be clinically meaningful. ",
                "Always report effect sizes and consider biological relevance.</li>",
                "<li><strong>Data Quality:</strong> Measurement error, missing data patterns, and selection bias affect all statistical tests.</li>",
                "<li><strong>Repeated Measures:</strong> Multiple observations per subject (biopsies, timepoints) violate independence. ",
                "Aggregate to subject-level summaries or use specialized models.</li>",
                "</ul>",

                "<h4 style='color:#856404;'>Recommendations for Pathology Data</h4>",
                "<ul>",
                "<li>Biomarker percentages (Ki-67, CD3+): Often skewed \u2192 Use nonparametric tests</li>",
                "<li>Cell counts (mitotic index, lymphocytes): Count data with overdispersion \u2192 Consider nonparametric or robust methods</li>",
                "<li>Tumor size measurements: May have outliers \u2192 Robust tests or nonparametric</li>",
                "<li>Age distributions: Often normal \u2192 Parametric tests appropriate</li>",
                "<li>Survival times: Always right-skewed \u2192 Use specialized survival analysis methods (not ridge plots)</li>",
                "</ul>",

                "</div>"
            )

            return(html)
        },

        # Single source of truth for the clinical presets: (option, value, label).
        # jamovi/js/jjridges.events.js holds the SAME table so the GUI controls show the
        # values that actually run; tests/testthat/test-jjridges-residual.R parses both
        # files and fails if they ever drift apart.
        .PRESETS = list(
            biomarker_distribution = list(
                list("plot_type",       "density_ridges",      "Plot type set to density_ridges"),
                list("add_boxplot",     TRUE,                  "Boxplots enabled"),
                list("add_quantiles",   TRUE,                  "Quantile lines enabled"),
                list("quantiles",       "0.25, 0.5, 0.75",     "Quantiles 0.25, 0.5, 0.75"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "clinical_colorblind", "Clinical palette"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "nonparametric",       "Nonparametric tests"),
                list("effsize_type",    "cliff_delta",         "Cliff's delta effect size"),
                list("p_adjust_method", "fdr",                 "FDR correction")),

            treatment_response = list(
                list("plot_type",       "violin_ridges",       "Plot type set to violin_ridges"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "nonparametric",       "Nonparametric tests"),
                list("effsize_type",    "cliff_delta",         "Cliff's delta effect size"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "clinical_colorblind", "Clinical palette"),
                list("add_boxplot",     TRUE,                  "Boxplots enabled"),
                list("p_adjust_method", "bonferroni",          "Bonferroni correction")),

            age_by_stage = list(
                list("plot_type",       "density_ridges",      "Plot type set to density_ridges"),
                list("add_mean",        TRUE,                  "Mean lines enabled"),
                list("add_median",      TRUE,                  "Median lines enabled"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "viridis",             "Viridis palette"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "parametric",          "Parametric tests"),
                list("effsize_type",    "d",                   "Cohen's d effect size")),

            tumor_size_comparison = list(
                list("plot_type",       "density_ridges",      "Plot type set to density_ridges"),
                list("add_boxplot",     TRUE,                  "Boxplots enabled"),
                list("add_quantiles",   TRUE,                  "Quantile lines enabled"),
                list("quantiles",       "0.25, 0.5, 0.75",     "Quantiles 0.25, 0.5, 0.75"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "clinical_colorblind", "Clinical palette"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "nonparametric",       "Nonparametric tests"),
                list("effsize_type",    "hodges_lehmann",      "Hodges-Lehmann shift"),
                list("p_adjust_method", "holm",                "Holm correction")),

            lab_values_by_group = list(
                list("plot_type",       "density_ridges",      "Plot type set to density_ridges"),
                list("add_boxplot",     TRUE,                  "Boxplots enabled"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "clinical_colorblind", "Clinical palette"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "robust",              "Robust tests"),
                list("effsize_type",    "g",                   "Hedges' g effect size"),
                list("p_adjust_method", "fdr",                 "FDR correction")),

            survival_time_distribution = list(
                list("plot_type",       "density_ridges",      "Plot type set to density_ridges"),
                list("add_median",      TRUE,                  "Median lines enabled"),
                list("add_quantiles",   TRUE,                  "Quantile lines enabled"),
                list("quantiles",       "0.25, 0.5, 0.75",     "Quantiles 0.25, 0.5, 0.75"),
                list("theme_style",     "theme_pubr",          "Publication theme"),
                list("color_palette",   "Set2",                "Set2 palette"),
                list("show_stats",      TRUE,                  "Statistics enabled"),
                list("test_type",       "nonparametric",       "Nonparametric tests"),
                list("effsize_type",    "hodges_lehmann",      "Hodges-Lehmann shift"),
                list("p_adjust_method", "holm",                "Holm correction"))
        ),

        .applyClinicalPreset = function() {
            preset <- self$options$clinicalPreset
            private$overrides <- list()

            spec <- private$.PRESETS[[preset]]
            if (identical(preset, "custom") || is.null(spec))
                return()

            labels <- character(0)
            for (entry in spec) {
                name  <- entry[[1]]
                value <- entry[[2]]
                labels <- c(labels, entry[[3]])

                opt <- self$options$option(name)
                if (is.null(opt))
                    next

                # In the jamovi GUI, jjridges.events.js has already written this value
                # into the option, so the control the user sees agrees with what runs and
                # nothing is recorded here. Callers from R get no JavaScript, so the value
                # is recorded as an override and read back through private$.option().
                #
                # Do NOT write `opt$value <- value`: jamovi option objects are read-only at
                # runtime and the assignment is a crash risk on strict builds.
                if (!identical(opt$value, value))
                    private$overrides[[name]] <- value
            }

            preset_label <- tools::toTitleCase(gsub("_", " ", preset))
            msg <- paste0("Clinical preset \u2014 ", preset_label, ": ",
                          paste(labels, collapse = "; "), ".")

            # The banner is built from the preset TABLE, not from private$overrides. It used
            # to be built from the overrides, so once the UI already carried the preset's
            # values there was nothing to record and the banner vanished - exactly the case
            # the events JS now creates for every GUI user.
            if (length(private$overrides) > 0) {
                msg <- paste0(msg, " These values were applied by the analysis and may not ",
                              "be reflected in the options panel.")
            } else {
                msg <- paste0(msg, " Change any of them individually in the options panel.")
            }

            # Overwrite (do NOT prepend): this block is the only writer of the warnings
            # panel and runs in both .init and .run, so prepending would duplicate the
            # banner on every run. No background element here, so a fixed dark-brown
            # foreground would be unreadable on jamovi's dark theme; carry the amber cue in
            # a translucent tint and let the text colour come from the theme.
            self$results$warnings$setContent(paste0(
                "<p style='background-color: rgba(255, 193, 7, 0.16); ",
                "border-left:4px solid #ffc107; padding:8px 12px; margin:10px 0; ",
                "color: inherit;'>", msg, "</p>"))
            self$results$warnings$setVisible(TRUE)
        },

        .run = function() {
            # Check requirements
            if (is.null(self$options$x_var) || is.null(self$options$y_var))
                return()

            # Reset notice list so prior-run notices don't persist across re-runs
            # (jamovi may reuse the same R6 instance when options change)
            private$.noticeList <- list()

            # Reset the preset-override banner so it cannot accumulate across runs
            self$results$warnings$setContent("")

            # Apply clinical preset if selected (must be done before other processing)
            private$.applyClinicalPreset()
            # Re-apply the fill-legend override wiped by .applyClinicalPreset()
            private$.applyAutoLegendOverride()

            # Validate inputs. jmvcore::reject() throws; the handler converts it to an
            # ERROR notice and flags validation_failed so .run() actually halts. A bare
            # return() in the handler would only exit the handler, letting .run continue
            # with invalid data (coerced NA X, or a plotted non-categorical Y).
            validation_failed <- FALSE
            input_warnings <- tryCatch({
                private$.validateInputs()
            }, error = function(e) {
                private$.addNotice(
                    type = "ERROR",
                    title = "Input Validation Error",
                    content = e$message
                )
                validation_failed <<- TRUE
                NULL
            })
            if (validation_failed)
                return()

            # Prepare data
            private$.checkpoint()
            plot_data <- private$.prepareData()

            if (nrow(plot_data) == 0) {
                private$.addNotice(
                    type = "ERROR",
                    title = "No Valid Data",
                    content = "No valid data available for analysis. Check your variable selections and data."
                )
                return()
            }

            # Validate data and collect additional warnings
            data_warnings <- tryCatch({
                private$.validateData(plot_data)
            }, error = function(e) {
                private$.addNotice(
                    type = "ERROR",
                    title = "Data Validation Error",
                    content = e$message
                )
                validation_failed <<- TRUE
                NULL
            })
            if (validation_failed)
                return()
            
            # Display individual warnings as separate Notices
            all_warnings <- c(input_warnings, data_warnings)
            if (length(all_warnings) > 0) {
                for (i in seq_along(all_warnings)) {
                    private$.addNotice('WARNING', 'Data Quality Warning', all_warnings[i])
                }
            }
            
            # Generate statistics
            private$.checkpoint()
            private$.generateStatistics(plot_data)
            
            # Generate statistical tests if requested
            if (private$.option("show_stats")) {
                private$.checkpoint()

                # CRITICAL FIX: Check for potential repeated measures before running tests
                repeated_measures_warning <- private$.checkRepeatedMeasures(plot_data)
                if (!is.null(repeated_measures_warning)) {
                    # Create STRONG_WARNING Notice about independence assumption violation
                    notice_msg <- paste0(
                        "INDEPENDENCE ASSUMPTION: ", repeated_measures_warning, " \u2022 ",
                        "Statistical tests assume independent observations. Repeated measures, matched samples, or clustered data may produce invalid results. \u2022 ",
                        "Recommendations: Aggregate to one value per subject, use specialized repeated measures models, or treat statistics as exploratory only."
                    )
                    private$.addNotice(
                        type = "STRONG_WARNING",
                        title = "Independence Assumption Violation",
                        content = notice_msg
                    )
                }

                # The plot is built AFTER this call, so any exception raised while computing
                # the statistics used to destroy the figure as well as the table. A failed
                # table is a bad outcome; a failed table that also removes the ridge plot the
                # user actually asked for is a worse one.
                tryCatch(
                    private$.generateTests(plot_data),
                    error = function(e) {
                        private$.addNotice(
                            'ERROR', 'Statistical tests could not be computed',
                            paste0(conditionMessage(e),
                                   ". The ridge plot below is unaffected; switch off ",
                                   "'Show statistics' to remove this message.")
                        )
                    }
                )
            }
            
            # Create plot
            private$.checkpoint()
            plot <- private$.createPlot(plot_data)
            
            # Save plot state
            self$results$plot$setState(plot)
            
            # Generate interpretation
            private$.generateInterpretation(plot_data)
            
            # Set clinical summary
            clinical_summary <- private$.generateClinicalSummary(plot_data, private$.option("show_stats"))
            self$results$clinicalSummary$setContent(clinical_summary)
            self$results$clinicalSummary$setVisible(TRUE)

            # Generate and set report summary (always visible for clinicians)
            report_summary <- private$.generateReportSummary(plot_data, private$.option("show_stats"))
            self$results$reportSummary$setContent(report_summary)
            self$results$reportSummary$setVisible(TRUE)

            # Generate and set about panel (if requested)
            if (self$options$showAboutPanel) {
                about_panel <- private$.generateAboutPanel()
                self$results$aboutPanel$setContent(about_panel)
                self$results$aboutPanel$setVisible(TRUE)
            } else {
                self$results$aboutPanel$setVisible(FALSE)
            }

            # Generate and set assumptions panel (if requested)
            if (self$options$showAssumptions) {
                assumptions_panel <- private$.generateAssumptionsPanel()
                self$results$assumptionsPanel$setContent(assumptions_panel)
                self$results$assumptionsPanel$setVisible(TRUE)
            } else {
                self$results$assumptionsPanel$setVisible(FALSE)
            }

            # Add completion INFO notice
            n_obs <- nrow(plot_data)
            n_groups <- length(unique(plot_data$y))
            notice_msg <- paste0(
                "Ridge plot analysis completed successfully \u2022 ",
                n_obs, " observations across ", n_groups, " groups \u2022 ",
                "Plot type: ", private$.option("plot_type"),
                # Name the requested test, and flag when the analysis did not actually use it
                # throughout -- .performSingleTest switches a comparison to Wilcoxon whenever
                # its normality/variance check fails, so "parametric" alone can be untrue.
                if (private$.option("show_stats"))
                    paste0(" \u2022 Statistical tests: ", private$.option("test_type"),
                           if (length(private$.assumptionSwitches) > 0)
                               paste0(" (", length(private$.assumptionSwitches),
                                      " comparison",
                                      if (length(private$.assumptionSwitches) == 1) "" else "s",
                                      " flagged by normality diagnostics; Welch retained)")
                           else "")
                else ""
            )
            private$.addNotice(
                type = "INFO",
                title = "Analysis Complete",
                content = notice_msg
            )

            # Render all collected notices as HTML
            private$.renderNotices()
        },
        
        .prepareData = function() {
            # Get data
            data <- self$data
            
            # Extract variables
            x_var <- self$options$x_var
            y_var <- self$options$y_var
            
            # Create base data frame
            plot_data <- data.frame(
                x = jmvcore::toNumeric(data[[x_var]]),
                y = as.factor(data[[y_var]]),
                stringsAsFactors = FALSE
            )
            
            # Add optional variables
            if (!is.null(self$options$fill_var)) {
                plot_data$fill <- as.factor(data[[self$options$fill_var]])
            }
            
            if (!is.null(self$options$facet_var)) {
                plot_data$facet <- as.factor(data[[self$options$facet_var]])
            }
            
            # Remove missing values (jmvcore::naOmit preserves jamovi column attributes)
            plot_data <- jmvcore::naOmit(plot_data)

            # naOmit keeps Inf/-Inf (is.na(Inf) is FALSE). A single Inf then poisons every
            # downstream number: mean/sd become Inf/NaN in the statistics table and in the
            # copy-ready report, and the skewness guard in .validateData evaluates NA, which
            # aborts the whole analysis with "missing value where TRUE/FALSE needed".
            n_nonfinite <- sum(!is.finite(plot_data$x))
            if (n_nonfinite > 0) {
                plot_data <- plot_data[is.finite(plot_data$x), , drop = FALSE]
                private$.addNotice(
                    'WARNING', 'Non-finite values removed',
                    paste0(n_nonfinite, " row", if (n_nonfinite == 1) "" else "s",
                           " with an infinite value in '", x_var,
                           "' ", if (n_nonfinite == 1) "was" else "were",
                           " excluded. ", nrow(plot_data),
                           " observations remain.")
                )
            }

            # Levels with no surviving rows (filtered out upstream, or never present)
            # stay in the factor, and table() then counts them at 0. .validateData read
            # that as "a group with fewer than 3 observations" and named a group the user
            # cannot see anywhere in the output.
            plot_data$y <- droplevels(plot_data$y)
            if ("fill" %in% names(plot_data)) plot_data$fill <- droplevels(plot_data$fill)
            if ("facet" %in% names(plot_data)) plot_data$facet <- droplevels(plot_data$facet)

            # Reverse order if requested
            if (self$options$reverse_order) {
                plot_data$y <- factor(plot_data$y, levels = rev(levels(plot_data$y)))
            }
            
            return(plot_data)
        },
        
        .createPlot = function(data) {
            # Base plot setup
            plot_type <- private$.option("plot_type")
            
            # Create base plot based on type
            if (plot_type == "ridgeline" || plot_type == "density_ridges") {
                p <- private$.createDensityPlot(data)
            } else if (plot_type == "density_ridges_gradient") {
                p <- private$.createGradientPlot(data)
            } else if (plot_type == "histogram_ridges") {
                p <- private$.createHistogramPlot(data)
            } else if (plot_type == "violin_ridges") {
                p <- private$.createViolinPlot(data)
            } else {
                p <- private$.createDensityPlot(data)  # Default
            }
            
            # Add advanced features
            if (private$.option("add_boxplot")) {
                # Add boxplot elements using ggplot2 geoms
                p <- p + ggplot2::geom_boxplot(
                    width = 0.1,
                    position = ggplot2::position_nudge(y = 0.15),
                    outlier.shape = NA,
                    alpha = 0.7,
                    color = "black"
                )
            }
            
            if (self$options$add_points) {
                # Add jittered points using ggplot2
                p <- p + ggplot2::geom_point(
                    alpha = self$options$point_alpha,
                    position = ggplot2::position_jitter(height = 0.1, width = 0),
                    size = 0.5
                )
            }
            
            # Quantile lines are NOT added as a second layer here. Doing so appended an
            # unstyled ggridges::stat_density_ridges() on top of the real one - default
            # grey70 fill, default scale - which painted over the palette and hid the
            # boxplots entirely. The quantile arguments are handed to the layer that
            # already exists instead (see .createDensityPlot/.createGradientPlot/
            # .createViolinPlot). stat = "binline" has no quantile support, so histogram
            # ridges say so rather than silently ignoring the option.
            if (private$.option("add_quantiles") && plot_type == "histogram_ridges") {
                private$.addNotice(
                    'WARNING', 'Quantile lines not available',
                    paste0("Quantile lines are not drawn on histogram ridges (the binned ",
                           "histogram statistic does not compute quantiles). Choose a ",
                           "density-based plot type to show them.")
                )
            }
            
            if (private$.option("add_mean")) {
                mean_data <- data %>%
                    group_by(y) %>%
                    summarise(mean_x = mean(x, na.rm = TRUE))
                
                p <- p + geom_vline(
                    data = mean_data,
                    aes(xintercept = mean_x),
                    color = "red",
                    linetype = "dashed",
                    alpha = 0.7
                )
            }
            
            if (private$.option("add_median")) {
                median_data <- data %>%
                    group_by(y) %>%
                    summarise(median_x = median(x, na.rm = TRUE))
                
                p <- p + geom_vline(
                    data = median_data,
                    aes(xintercept = median_x),
                    color = "blue",
                    linetype = "dashed",
                    alpha = 0.7
                )
            }
            
            # Apply faceting if requested
            if (!is.null(self$options$facet_var)) {
                show_facet_legend <- self$options$show_facet_legend %||% TRUE

                # Create custom labeller to show variable name and value
                facet_var_name <- self$options$facet_var
                custom_labeller <- function(labels) {
                    lapply(labels, function(x) paste0(facet_var_name, ": ", x))
                }

                if (show_facet_legend) {
                    p <- p + facet_wrap(~ facet, scales = "free_x",
                                       labeller = labeller(facet = custom_labeller))
                } else {
                    p <- p + facet_wrap(~ facet, scales = "free_x") +
                        theme(strip.text = element_blank())
                }
            }
            
            # Apply theme
            p <- private$.applyTheme(p)
            
            # Apply labels
            p <- private$.applyLabels(p)
            
            # Add sample sizes if requested
            if (self$options$add_sample_size) {
                # Calculate appropriate x position (90% of x range)
                x_max <- max(data$x, na.rm = TRUE)
                x_min <- min(data$x, na.rm = TRUE)
                x_pos <- x_min + 0.9 * (x_max - x_min)
                
                sample_sizes <- data %>%
                    group_by(y) %>%
                    summarise(n = n(), .groups = 'drop') %>%
                    mutate(
                        label = paste0("n=", n),
                        x_pos = x_pos
                    )
                
                p <- p + geom_text(
                    data = sample_sizes,
                    aes(x = x_pos, y = y, label = label),
                    hjust = 0.5,
                    vjust = -0.3,
                    size = 3,
                    fontface = "bold",
                    color = "black",
                    alpha = 0.8
                )
            }
            
            # Add density peak values if requested
            if (self$options$add_density_values) {
                # Calculate density peaks for each group
                if (!is.null(self$options$fill_var)) {
                    # When fill variable exists, calculate peaks by both y and fill
                    peak_data <- data %>%
                        group_by(y, fill) %>%
                        summarise(
                            peak_x = {
                                if(length(x) > 2) {
                                    dens <- density(x, na.rm = TRUE)
                                    dens$x[which.max(dens$y)]
                                } else {
                                    mean(x, na.rm = TRUE)
                                }
                            },
                            .groups = 'drop'
                        )
                } else {
                    # When no fill variable, calculate peaks by y only
                    peak_data <- data %>%
                        group_by(y) %>%
                        summarise(
                            peak_x = {
                                if(length(x) > 2) {
                                    dens <- density(x, na.rm = TRUE)
                                    dens$x[which.max(dens$y)]
                                } else {
                                    mean(x, na.rm = TRUE)
                                }
                            },
                            .groups = 'drop'
                        )
                }
                
                p <- p + geom_text(
                    data = peak_data,
                    aes(x = peak_x, y = y, label = round(peak_x, 1)),
                    vjust = 1.2,
                    hjust = 0.5,
                    size = 2.5,
                    color = "darkred",
                    fontface = "bold",
                    alpha = 0.8
                )
            }
            
            # Add custom annotations if provided
            if (!is.null(self$options$custom_annotations) && self$options$custom_annotations != "") {
                # Parse custom annotations: format "x,y,text;x2,y2,text2"
                annotations <- strsplit(self$options$custom_annotations, ";")[[1]]
                for (ann in annotations) {
                    parts <- trimws(strsplit(ann, ",")[[1]])
                    if (length(parts) == 3) {
                        # Try to parse x and y as numeric
                        x_val <- suppressWarnings(as.numeric(parts[1]))
                        y_val <- suppressWarnings(as.numeric(parts[2]))
                        
                        if (!is.na(x_val) && !is.na(y_val)) {
                            p <- p + annotate("text", 
                                x = x_val, 
                                y = y_val, 
                                label = parts[3],
                                size = 3.5,
                                color = "blue")
                        }
                    }
                }
            }
            
            return(p)
        },
        
        # Quantile probabilities for the primary ridge layer. Always safe to pass:
        # stat_density_ridges only draws them when quantile_lines is TRUE.
        .quantileValues = function() {
            private$.validateQuantiles(private$.option("quantiles"))
        },

        .createDensityPlot = function(data) {
            p <- ggplot(data, aes(x = x, y = y))

            # "Basic Ridgeline" and "Density Ridges" used to render byte-identical figures
            # because both routed here. geom_density_ridges2 draws a CLOSED ridgeline
            # (outline carried along the baseline), which is the classic ridgeline look and
            # is visibly distinct from the open-topped geom_density_ridges.
            ridge_geom <- if (identical(private$.option("plot_type"), "ridgeline"))
                ggridges::geom_density_ridges2
            else
                ggridges::geom_density_ridges

            draw_quantiles <- isTRUE(private$.option("add_quantiles"))
            quantile_probs <- private$.quantileValues()

            # Handle fill_ridges option
            if (self$options$fill_ridges) {
                if (!is.null(self$options$fill_var)) {
                    # Show legend based on user preference when fill variable is used
                    show_fill_legend <- self$options$show_fill_legend %||% TRUE
                    p <- p + ridge_geom(
                        aes(fill = fill),
                        scale = self$options$scale,
                        alpha = self$options$alpha,
                        bandwidth = private$.calculateBandwidth(data$x),
                        quantile_lines = draw_quantiles,
                        quantiles = quantile_probs,
                        color = "black",
                        linewidth = 0.5,
                        show.legend = show_fill_legend
                    )
                } else {
                    # Hide legend for y-variable coloring (redundant with y-axis)
                    p <- p + ridge_geom(
                        aes(fill = y),
                        scale = self$options$scale,
                        alpha = self$options$alpha,
                        bandwidth = private$.calculateBandwidth(data$x),
                        quantile_lines = draw_quantiles,
                        quantiles = quantile_probs,
                        color = "black",
                        linewidth = 0.5,
                        show.legend = FALSE
                    )
                }
                # Apply color palette for filled ridges
                p <- private$.applyColorPalette(p)
            } else {
                # Outline only - no fill
                p <- p + ridge_geom(
                    scale = self$options$scale,
                    fill = NA,
                    color = "black",
                    linewidth = 0.75,
                    bandwidth = private$.calculateBandwidth(data$x),
                    quantile_lines = draw_quantiles,
                    quantiles = quantile_probs
                )
            }

            return(p)
        },

        .createGradientPlot = function(data) {
            p <- ggplot(data, aes(x = x, y = y))

            p <- p + ggridges::geom_density_ridges_gradient(
                aes(fill = after_stat(x)),
                scale = self$options$scale,
                gradient_lwd = 1.0,
                bandwidth = private$.calculateBandwidth(data$x),
                quantile_lines = isTRUE(private$.option("add_quantiles")),
                quantiles = private$.quantileValues()
            )
            
            # Apply gradient colors
            p <- p + scale_fill_gradient(
                low = self$options$gradient_low,
                high = self$options$gradient_high,
                name = self$options$x_var
            )
            
            return(p)
        },
        
        .createHistogramPlot = function(data) {
            p <- ggplot(data, aes(x = x, y = y))
            
            if (self$options$fill_ridges) {
                if (!is.null(self$options$fill_var)) {
                    # Show legend based on user preference when fill variable is used
                    show_fill_legend <- self$options$show_fill_legend %||% TRUE
                    p <- p + ggridges::geom_density_ridges(
                        aes(fill = fill),
                        stat = "binline",
                        binwidth = self$options$binwidth,
                        scale = self$options$scale,
                        alpha = self$options$alpha,
                        color = "black",
                        linewidth = 0.5,
                        show.legend = show_fill_legend
                    )
                } else {
                    p <- p + ggridges::geom_density_ridges(
                        aes(fill = y),
                        stat = "binline",
                        binwidth = self$options$binwidth,
                        scale = self$options$scale,
                        alpha = self$options$alpha,
                        color = "black",
                        linewidth = 0.5,
                        show.legend = FALSE
                    )
                }
                # Apply color palette
                p <- private$.applyColorPalette(p)
            } else {
                # Outline only
                p <- p + ggridges::geom_density_ridges(
                    stat = "binline",
                    binwidth = self$options$binwidth,
                    scale = self$options$scale,
                    fill = NA,
                    color = "black",
                    linewidth = 0.75
                )
            }
            
            return(p)
        },
        
        .createViolinPlot = function(data) {
            # This used to be geom_density_ridges(aes(height = stat(density))), which is
            # exactly what StatDensityRidges already maps - a no-op that made "Violin
            # Ridges" render byte-identically to "Density Ridges" (and emitted the ggplot2
            # stat() deprecation warning). A violin is a MIRRORED density, so draw a real
            # one: geom_violin(orientation = "y") along the same discrete y axis.
            has_fill <- !is.null(self$options$fill_var)

            args <- list(
                mapping = if (has_fill) aes(fill = fill) else aes(fill = y),
                orientation = "y",
                # `scale` is the Ridge Height Scale control. geom_density_ridges
                # consumed it; geom_violin takes the equivalent as `width`, and
                # omitting it made the option inert for this plot type.
                width = self$options$scale,
                alpha = self$options$alpha,
                colour = "black",
                linewidth = 0.5,
                show.legend = if (has_fill) (self$options$show_fill_legend %||% TRUE) else FALSE
            )

            # .calculateBandwidth returns NULL for "nrd0" (meaning: use the geom default);
            # geom_violin has no NULL default, so only pass bw when we have a number.
            bw <- private$.calculateBandwidth(data$x)
            if (!is.null(bw))
                args$bw <- bw

            if (isTRUE(private$.option("add_quantiles"))) {
                args$quantiles <- private$.quantileValues()
                # geom_violin defaults quantile.linetype to 0 ("do not draw"), so passing
                # `quantiles` alone computes them and shows nothing. Measured: identical
                # PNG md5 with and without `quantiles` until linetype is set.
                args$quantile.linetype <- 1
            }

            p <- ggplot(data, aes(x = x, y = y)) +
                do.call(ggplot2::geom_violin, args)

            # Apply color palette
            p <- private$.applyColorPalette(p)

            return(p)
        },
        
        .calculateBandwidth = function(x = NULL) {
            method <- self$options$bandwidth
            if (method == "custom") {
                return(self$options$bandwidth_value)
            }

            # ggridges evaluates `3 * bandwidth` internally, so bandwidth must be
            # NUMERIC. Returning the literal string "nrd"/"SJ" crashes the plot with
            # "non-numeric argument to binary operator". Convert the named method to a
            # pooled numeric bandwidth here (bw.SJ can fail on ties/few unique values,
            # so fall back to bw.nrd). "nrd0" -> NULL lets geom_density_ridges use its
            # own per-group default.
            xv <- if (!is.null(x)) x[is.finite(x)] else numeric(0)
            if (method == "nrd") {
                if (length(xv) > 1) return(stats::bw.nrd(xv))
                return(NULL)
            } else if (method == "SJ") {
                if (length(xv) > 1)
                    return(tryCatch(stats::bw.SJ(xv), error = function(e) stats::bw.nrd(xv)))
                return(NULL)
            }
            return(NULL)  # nrd0 -> use ggridges default
        },
        
        .applyColorPalette = function(p) {
            palette <- private$.option("color_palette")
            
            # Determine legend title
            legend_title <- if (!is.null(self$options$fill_var)) {
                self$options$fill_var
            } else {
                self$options$y_var
            }
            
            # scale_fill_manual() is a HARD ERROR when the palette is shorter than the number
            # of levels -- "Insufficient values in manual scale. 7 needed but only 6 provided"
            # -- and it takes the whole figure with it, not just the colours. The built-in
            # colourblind-safe palette holds 6 and the shipped custom_colors default holds 4,
            # so a 7-group comparison (or a 5-group one on the custom palette) produced no plot
            # at all, while the About panel advertises support for about ten groups.
            # Interpolating keeps every palette usable at any number of levels.
            n_levels <- tryCatch({
                fv <- if (!is.null(self$options$fill_var)) self$options$fill_var else self$options$y_var
                length(unique(stats::na.omit(self$data[[fv]])))
            }, error = function(e) 0L)
            stretch <- function(cols) {
                cols <- cols[nzchar(cols)]
                if (length(cols) == 0) return(private$.CLINICAL_CB_SAFE_COLORS)
                if (n_levels > length(cols))
                    grDevices::colorRampPalette(cols)(n_levels)
                else cols
            }

            if (palette == "custom") {
                colors <- strsplit(self$options$custom_colors, ",")[[1]]
                colors <- trimws(colors)
                p <- p + scale_fill_manual(values = stretch(colors), name = legend_title)
            } else if (palette == "clinical_colorblind") {
                # Clinical colorblind-safe palette
                p <- p + scale_fill_manual(values = stretch(private$.CLINICAL_CB_SAFE_COLORS), name = legend_title)
            } else if (palette %in% c("viridis", "plasma", "inferno", "magma")) {
                if (requireNamespace("viridis", quietly = TRUE)) {
                    p <- p + scale_fill_viridis_d(option = tolower(palette), name = legend_title)
                } else {
                    # Use constant instead of hardcoded values
                    p <- p + scale_fill_manual(values = stretch(private$.VIRIDIS_FALLBACK), name = legend_title)
                }
            } else if (palette %in% c("Set1", "Set2", "Dark2", "Paired")) {
                # Use RColorBrewer palettes
                if (requireNamespace("RColorBrewer", quietly = TRUE)) {
                    p <- p + scale_fill_brewer(palette = palette, name = legend_title)
                } else {
                    # Fallback to clinical colors
                    p <- p + scale_fill_manual(values = stretch(private$.CLINICAL_CB_SAFE_COLORS), name = legend_title)
                }
            } else {
                # Default to clinical colorblind-safe palette
                p <- p + scale_fill_manual(values = stretch(private$.CLINICAL_CB_SAFE_COLORS), name = legend_title)
            }
            
            return(p)
        },
        
        .applyTheme = function(p) {
            theme_style <- private$.option("theme_style")
            
            if (theme_style == "theme_ridges") {
                p <- p + ggridges::theme_ridges(grid = self$options$grid_lines)
            } else if (theme_style == "theme_minimal") {
                p <- p + theme_minimal()
            } else if (theme_style == "theme_classic") {
                p <- p + theme_classic()
            } else if (theme_style == "theme_dark") {
                # Create a dark theme
                p <- p + theme_minimal() +
                    theme(
                        plot.background = element_rect(fill = "#2E2E2E", color = NA),
                        panel.background = element_rect(fill = "#2E2E2E", color = NA),
                        panel.grid.major = element_line(color = "#555555", linewidth = 0.3),
                        panel.grid.minor = element_line(color = "#444444", linewidth = 0.2),
                        text = element_text(color = "#E0E0E0"),
                        axis.text = element_text(color = "#E0E0E0"),
                        axis.title = element_text(color = "#E0E0E0"),
                        legend.background = element_rect(fill = "#2E2E2E", color = NA),
                        legend.text = element_text(color = "#E0E0E0"),
                        legend.title = element_text(color = "#E0E0E0")
                    )
            } else if (theme_style == "theme_pubr") {
                p <- p + theme_minimal() +
                    theme(
                        panel.border = element_rect(fill = NA, color = "black"),
                        axis.line = element_line(color = "black")
                    )
            }
            
            # Apply additional theme modifications
            if (self$options$expand_panels) {
                p <- p + theme(
                    plot.margin = margin(0, 0, 0, 0),
                    panel.spacing = unit(0, "lines")
                )
            }

            # Set legend position (use .option to respect overrides)
            p <- p + theme(legend.position = private$.option("legend_position"))

            return(p)
        },
        
        .applyLabels = function(p) {
            x_label <- if (self$options$x_label != "") self$options$x_label else self$options$x_var
            y_label <- if (self$options$y_label != "") self$options$y_label else self$options$y_var
            
            p <- p + labs(
                x = x_label,
                y = y_label,
                title = if (self$options$plot_title != "") self$options$plot_title else NULL,
                subtitle = if (self$options$plot_subtitle != "") self$options$plot_subtitle else NULL,
                caption = if (self$options$plot_caption != "") self$options$plot_caption else NULL
            )
            
            return(p)
        },
        
        .generateStatistics = function(data) {
            stats_table <- self$results$statistics

            # jamovi reuses this R6 instance across option changes, and addRow() does not
            # reject a rowKey it already holds. Without this the table grew by a full set of
            # rows on every re-run (3 groups -> 3, 6, 9 rows) and asDF then threw
            # "duplicate 'row.names' are not allowed", which .generateReportSummary catches
            # and silently degrades. clearWith only covers the variable options, so any
            # visual change (scale, alpha, theme) re-ran this with the old rows still there.
            stats_table$deleteRows()

            # Build grouping variables: always include y, optionally add fill and facet
            grouping_vars <- "y"
            if (!is.null(self$options$fill_var) && "fill" %in% names(data)) {
                grouping_vars <- c(grouping_vars, "fill")
            }
            if (!is.null(self$options$facet_var) && "facet" %in% names(data)) {
                grouping_vars <- c(grouping_vars, "facet")
            }

            # Calculate statistics for each combination of grouping variables
            stats <- data %>%
                group_by(across(all_of(grouping_vars))) %>%
                summarise(
                    n = n(),
                    mean = mean(x, na.rm = TRUE),
                    sd = sd(x, na.rm = TRUE),
                    median = median(x, na.rm = TRUE),
                    q1 = quantile(x, 0.25, na.rm = TRUE),
                    q3 = quantile(x, 0.75, na.rm = TRUE),
                    min = min(x, na.rm = TRUE),
                    max = max(x, na.rm = TRUE),
                    .groups = "drop"
                )

            # Populate table
            for (i in seq_len(nrow(stats))) {
                private$.checkpoint()

                # Build group label from all grouping variables
                group_label <- as.character(stats$y[i])
                if ("fill" %in% names(stats)) {
                    group_label <- paste0(group_label, " [", stats$fill[i], "]")
                }
                if ("facet" %in% names(stats)) {
                    group_label <- paste0(group_label, " (", stats$facet[i], ")")
                }

                stats_table$addRow(
                    rowKey = i,
                    values = list(
                        group = group_label,
                        n = stats$n[i],
                        mean = stats$mean[i],
                        sd = stats$sd[i],
                        median = stats$median[i],
                        q1 = stats$q1[i],
                        q3 = stats$q3[i],
                        min = stats$min[i],
                        max = stats$max[i]
                    )
                )
            }
        },

        # Helper method: Perform a single statistical test with proper warnings
        .performSingleTest = function(data1, data2, group1, group2, stratum_label = "") {
            test_type <- private$.option("test_type")
            statistic <- NA
            p_value <- NA
            ci_lower <- NA
            ci_upper <- NA
            test_method <- ""
            warning_msg <- NULL

            # Guard for insufficient observations
            if (length(data1) < 2 || length(data2) < 2) {
                warning_msg <- paste0(
                    "Insufficient observations for comparison ",
                    group1, " vs ", group2,
                    if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                    ". Need at least 2 observations per group."
                )
                private$.testWarnings <- c(private$.testWarnings, warning_msg)
                return(list(
                    comparison = paste(group1, "vs", group2),
                    statistic = NA,
                    p_value = NA,
                    ci_lower = NA,
                    ci_upper = NA,
                    effect_size = NA,
                    effect_ci_lower = NA,
                    effect_ci_upper = NA,
                    # NOT test_type: that is the option VALUE ("parametric"), which read as a
                    # test name in the Method column of a row where no test was run.
                    test_method = "not testable (n < 2)",
                    warning = warning_msg
                ))
            }

            # A pair where BOTH groups are constant kills t.test() with "data are essentially
            # constant". shapiro.test() also errors (swallowed by the tryCatch below) and
            # Levene returns NaN, so nothing upstream catches it and the bare t.test() at the
            # end of the parametric branch throws. .generateTests() is called from .run()
            # before the plot is built, so the exception cost the ridge plot as well as the
            # table. Return an explicit NA row instead.
            if (stats::var(data1) == 0 && stats::var(data2) == 0 &&
                (test_type != "nonparametric" || length(unique(c(data1, data2))) == 1)) {
                private$.testWarnings <- c(private$.testWarnings, paste0(
                    "Comparison ", group1, " vs ", group2,
                    if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                    ": every value is identical within both groups, so there is ",
                    "no variability to test."))
                return(list(
                    comparison = paste(group1, "vs", group2),
                    statistic = NA, p_value = NA, ci_lower = NA, ci_upper = NA,
                    effect_size = NA, effect_ci_lower = NA, effect_ci_upper = NA,
                    test_method = "not testable (no variability)",
                    warning = paste0("Comparison ", group1, " vs ", group2,
                                     if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                                     ": every value is identical within both groups, so there is ",
                                     "no variability to test.")
                ))
            }

            if (test_type == "parametric") {
                assumption_violations <- c()

                # Normality checks
                if (length(data1) >= 3 && length(data1) <= 500) {
                    sw1 <- tryCatch(shapiro.test(data1), error = function(e) NULL)
                    if (!is.null(sw1) && !is.na(sw1$p.value) && sw1$p.value < 0.05) {
                        assumption_violations <- c(assumption_violations, paste0(group1, " non-normal (Shapiro p=", round(sw1$p.value, 3), ")"))
                    }
                }
                if (length(data2) >= 3 && length(data2) <= 500) {
                    sw2 <- tryCatch(shapiro.test(data2), error = function(e) NULL)
                    if (!is.null(sw2) && !is.na(sw2$p.value) && sw2$p.value < 0.05) {
                        assumption_violations <- c(assumption_violations, paste0(group2, " non-normal (Shapiro p=", round(sw2$p.value, 3), ")"))
                    }
                }

                # Variance check
                if (requireNamespace("car", quietly = TRUE)) {
                    df_lv <- data.frame(
                        val = c(data1, data2),
                        grp = factor(rep(c("g1", "g2"), c(length(data1), length(data2))))
                    )
                    lv <- tryCatch(car::leveneTest(val ~ grp, data = df_lv, center = median), error = function(e) NULL)
                    if (!is.null(lv) && !is.na(lv$`Pr(>F)`[1]) && lv$`Pr(>F)`[1] < 0.05) {
                        # Recorded for the user, but deliberately NOT a reason to switch tests.
                        # t.test() is called below without var.equal, so it is already Welch,
                        # which is valid under unequal variances - that is the entire point of
                        # Welch. Switching to Wilcoxon instead makes matters worse, because
                        # Wilcoxon assumes equal shape/spread to test locations: simulated under
                        # a true null with n = 40 (sd 1) vs n = 10 (sd 4), 3000 replicates,
                        # Wilcoxon rejects at 0.146 against a nominal 0.05 while Welch holds at
                        # 0.0487. Only non-normality is grounds for the rank-based switch.
                        variance_note <- paste0("Variance heterogeneity (Levene p=",
                                                round(lv$`Pr(>F)`[1], 3),
                                                "); handled by Welch's t-test")
                    }
                }

                if (exists("variance_note", inherits = FALSE) && !is.null(variance_note)) {
                    private$.assumptionNotes <- unique(c(private$.assumptionNotes,
                        paste0(group1, " vs ", group2,
                               if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                               ": ", variance_note)))
                }

                # A failed normality check is REPORTED, not acted on: selecting the test
                # from a diagnostic p-value inflates the type-I error of the test finally
                # reported. Welch's t-test is run either way; .generateTests summarises the
                # flagged comparisons in one notice (one per comparison floods the panel).
                if (length(assumption_violations) > 0) {
                    private$.assumptionSwitches <- c(
                        private$.assumptionSwitches,
                        paste0(
                            group1, " vs ", group2,
                            if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                            ": ", paste(assumption_violations, collapse = "; ")
                        )
                    )
                }

                test_result <- t.test(data1, data2)
                statistic <- test_result$statistic
                p_value <- test_result$p.value
                ci_lower <- test_result$conf.int[1]
                ci_upper <- test_result$conf.int[2]
                test_method <- "t-test"

            } else if (test_type == "nonparametric") {
                test_result <- wilcox.test(data1, data2, conf.int = TRUE)
                statistic <- test_result$statistic
                p_value <- test_result$p.value
                ci_lower <- if(!is.null(test_result$conf.int)) test_result$conf.int[1] else NA
                ci_upper <- if(!is.null(test_result$conf.int)) test_result$conf.int[2] else NA
                test_method <- "Wilcoxon"

            } else if (test_type == "robust") {
                # CRITICAL FIX: Warn if WRS2 unavailable instead of silent fallback
                if (requireNamespace("WRS2", quietly = TRUE)) {
                    # WRS2::yuen requires formula interface
                    df_robust <- data.frame(
                        val = c(data1, data2),
                        grp = factor(rep(c("g1", "g2"), c(length(data1), length(data2))))
                    )
                    test_result <- WRS2::yuen(val ~ grp, data = df_robust)
                    statistic <- test_result$test
                    p_value <- test_result$p.value
                    ci_lower <- test_result$conf.int[1]
                    ci_upper <- test_result$conf.int[2]
                    test_method <- "Yuen (robust)"
                } else {
                    # Fallback with warning
                    test_result <- t.test(data1, data2)
                    statistic <- test_result$statistic
                    p_value <- test_result$p.value
                    ci_lower <- test_result$conf.int[1]
                    ci_upper <- test_result$conf.int[2]
                    test_method <- "t-test (WRS2 unavailable)"

                    private$.addNotice('WARNING', 'WRS2 Package Unavailable', paste0(
                        "WRS2 package not available for robust test. Falling back to standard t-test for comparison: ",
                        group1, " vs ", group2,
                        if(stratum_label != "") paste0(" (", stratum_label, ")") else ""
                    ))
                }

            } else if (test_type == "bayes") {
                # CRITICAL FIX: Implement Bayesian test or warn
                if (requireNamespace("BayesFactor", quietly = TRUE)) {
                    # Use BayesFactor for Bayesian t-test
                    bf_result <- tryCatch({
                        BayesFactor::ttestBF(x = data1, y = data2)
                    }, error = function(e) NULL)

                    if (!is.null(bf_result)) {
                        statistic <- exp(bf_result@bayesFactor$bf)  # Bayes Factor
                        p_value <- NA  # Bayesian inference doesn't use p-values
                        ci_lower <- NA
                        ci_upper <- NA
                        test_method <- "Bayesian t-test"
                    } else {
                        statistic <- NA
                        p_value <- NA
                        ci_lower <- NA
                        ci_upper <- NA
                        test_method <- "Bayesian (failed)"

                        private$.addNotice('WARNING', 'Bayesian Test Failed', paste0("Bayesian test failed for: ", group1, " vs ", group2))
                    }
                } else {
                    statistic <- NA
                    p_value <- NA
                    ci_lower <- NA
                    ci_upper <- NA
                    test_method <- "Bayesian (unavailable)"

                    private$.addNotice('WARNING', 'BayesFactor Package Unavailable', paste0(
                        "BayesFactor package not available. Cannot perform Bayesian test for: ",
                        group1, " vs ", group2
                    ))
                }

            } else {
                private$.addNotice('WARNING', 'Unknown Test Type', paste0("Unknown test type '", test_type, "' for: ", group1, " vs ", group2))
            }

            # Calculate effect size with proper CIs
            effect_result <- private$.calculateEffectSizeWithCI(data1, data2)
            if (!is.null(effect_result$warning)) {
                private$.testWarnings <- c(private$.testWarnings, paste0(
                    group1, " vs ", group2,
                    if (stratum_label != "") paste0(" (", stratum_label, ")") else "",
                    ": ", effect_result$warning))
            }

            # Build comparison label
            comparison_label <- paste(group1, "vs", group2)
            if (stratum_label != "") {
                comparison_label <- paste0(comparison_label, " (", stratum_label, ")")
            }

            return(list(
                comparison = comparison_label,
                statistic = statistic,
                p_value = p_value,
                ci_lower = ci_lower,
                ci_upper = ci_upper,
                effect_size = effect_result$effect_size,
                effect_ci_lower = effect_result$ci_lower,
                effect_ci_upper = effect_result$ci_upper,
                test_method = test_method
            ))
        },

        # Helper method: Calculate effect size using effectsize package (robust and validated)
        .calculateEffectSizeWithCI = function(data1, data2) {
            effsize_type <- private$.option("effsize_type")
            effect_size <- NA
            ci_lower <- NA
            ci_upper <- NA
            warning_msg <- NULL

            n1 <- length(data1)
            n2 <- length(data2)

            # Check minimum sample sizes
            if (n1 < 3 || n2 < 3) {
                return(list(
                    effect_size = NA,
                    ci_lower = NA,
                    ci_upper = NA,
                    warning = paste0("Insufficient sample size for effect size (n1=", n1, ", n2=", n2, "). ",
                                   "Minimum 3 observations per group required.")
                ))
            }

            # Use effectsize package for robust, validated calculations
            tryCatch({
                if (effsize_type == "d") {
                    # Cohen's d using effectsize package
                    if (requireNamespace("effectsize", quietly = TRUE)) {
                        result <- effectsize::cohens_d(data1, data2, pooled_sd = TRUE, ci = 0.95)
                        effect_size <- as.numeric(result$Cohens_d)
                        ci_lower <- result$CI_low
                        ci_upper <- result$CI_high
                    } else {
                        warning_msg <- "effectsize package not available for Cohen's d"
                    }

                } else if (effsize_type == "g") {
                    # Hedges' g using effectsize package
                    if (requireNamespace("effectsize", quietly = TRUE)) {
                        result <- effectsize::hedges_g(data1, data2, pooled_sd = TRUE, ci = 0.95)
                        effect_size <- as.numeric(result$Hedges_g)
                        ci_lower <- result$CI_low
                        ci_upper <- result$CI_high
                    } else {
                        warning_msg <- "effectsize package not available for Hedges' g"
                    }

                } else if (effsize_type == "eta") {
                    # Eta squared using effectsize package
                    if (requireNamespace("effectsize", quietly = TRUE)) {
                        # Create a simple data frame for eta_squared
                        df <- data.frame(
                            value = c(data1, data2),
                            group = factor(rep(c("g1", "g2"), c(n1, n2)))
                        )
                        model <- aov(value ~ group, data = df)
                        # alternative = "two.sided" is essential here. effectsize defaults to
                        # "greater" for variance-explained measures, which returns a ONE-SIDED
                        # interval whose upper bound is always exactly 1. The table prints that
                        # under columns headed "Effect CI Lower/Upper" alongside Cohen's d,
                        # Hedges' g, Cliff's delta and Hodges-Lehmann, all of which ARE
                        # two-sided -- so the same two columns silently mixed conventions.
                        # Measured: eta2 = 0.137 was reported as [0.038, 1.000]; the two-sided
                        # interval is [0.025, 0.288], which is a reportable result rather than
                        # an apparently useless one.
                        # effectsize emits an informational message for one-way designs
                        # ("partial eta squared is equivalent to eta squared"); jamovi surfaces it in
                        # Analysis Notes, where it reads as a problem rather than a note.
                        result <- suppressMessages(
                            effectsize::eta_squared(model, ci = 0.95, alternative = "two.sided"))
                        effect_size <- as.numeric(result$Eta2)
                        ci_lower <- result$CI_low
                        ci_upper <- result$CI_high
                    } else {
                        warning_msg <- "effectsize package not available for Eta squared"
                    }

                } else if (effsize_type == "omega") {
                    # Omega squared using effectsize package
                    if (requireNamespace("effectsize", quietly = TRUE)) {
                        df <- data.frame(
                            value = c(data1, data2),
                            group = factor(rep(c("g1", "g2"), c(n1, n2)))
                        )
                        model <- aov(value ~ group, data = df)
                        # See the eta-squared branch above: two.sided, so this column means the
                        # same thing whichever effect size the user picked.
                        # effectsize emits an informational message for one-way designs
                        # ("partial omega squared is equivalent to omega squared"); jamovi surfaces it in
                        # Analysis Notes, where it reads as a problem rather than a note.
                        result <- suppressMessages(
                            effectsize::omega_squared(model, ci = 0.95, alternative = "two.sided"))
                        effect_size <- as.numeric(result$Omega2)
                        ci_lower <- result$CI_low
                        ci_upper <- result$CI_high
                    } else {
                        warning_msg <- "effectsize package not available for Omega squared"
                    }

                } else if (effsize_type == "cliff_delta") {
                    # Cliff's Delta - keep custom implementation (not in effectsize core)
                    effect_size <- private$.calculateCliffsDelta(data1, data2)

                    # Bootstrap CI for Cliff's Delta
                    if (requireNamespace("boot", quietly = TRUE)) {
                        boot_fn <- function(data, indices) {
                            d1 <- data[indices[indices <= n1]]
                            d2 <- data[indices[indices > n1]]
                            private$.calculateCliffsDelta(d1, d2)
                        }
                        # strata= resamples WITHIN each group so per-replicate group
                        # sizes stay fixed at (n1, n2). Without it boot draws a random
                        # group split (possibly empty -> NA), giving an invalid CI.
                        boot_result <- tryCatch({
                            # Seeded: an unseeded bootstrap moved the Cliff's
                            # delta confidence interval between identical runs.
                            withr::local_seed(self$options$seed)
                            boot::boot(c(data1, data2), boot_fn, R = 1000,
                                       strata = factor(rep(1:2, c(n1, n2))))
                        }, error = function(e) NULL)

                        if (!is.null(boot_result)) {
                            ci_result <- boot::boot.ci(boot_result, type = "perc")
                            if (!is.null(ci_result$percent)) {
                                ci_lower <- ci_result$percent[4]
                                ci_upper <- ci_result$percent[5]
                            }
                        }
                    }

                } else if (effsize_type == "hodges_lehmann") {
                    # Hodges-Lehmann shift (median of pairwise differences)
                    effect_size <- private$.calculateHodgesLehmann(data1, data2)

                    # CI from Wilcoxon test
                    wilcox_result <- wilcox.test(data1, data2, conf.int = TRUE)
                    if (!is.null(wilcox_result$conf.int)) {
                        ci_lower <- wilcox_result$conf.int[1]
                        ci_upper <- wilcox_result$conf.int[2]
                    }
                }

            }, error = function(e) {
                private$.addNotice('WARNING', 'Effect Size Calculation Error', paste0("Error calculating effect size: ", e$message))
            })

            return(list(
                effect_size = effect_size,
                ci_lower = ci_lower,
                ci_upper = ci_upper,
                warning = warning_msg
            ))
        },

        # Helper method: Check for potential repeated measures
        .checkRepeatedMeasures = function(data) {
            # CRITICAL FIX: Detect data patterns suggesting repeated measures/clustering
            # This helps warn users when independence assumption is likely violated

            # Calculate observations per group level
            group_counts <- table(data$y)
            total_obs <- nrow(data)
            n_groups <- length(group_counts)

            # Heuristic: If average observations per group is much higher than expected
            # for independent samples, warn about possible repeated measures
            avg_obs_per_group <- mean(group_counts)

            # Check 1 REMOVED. It fired when avg_obs_per_group > 30 && n_groups <= 5, which
            # describes an ordinary well-powered cross-sectional study, not clustering.
            # Verified: 200 independent rows in 4 groups of 50 raised
            # "Independence Assumption Violation ... treat statistics as exploratory only".
            # A STRONG_WARNING that fires on clean data trains users to ignore all warnings,
            # including the ones that matter. Group size carries no information about whether
            # rows are independent.

            # Check 2: Look for integer-valued X variable with repeated values
            # Common pattern: time points, visit numbers, days post-treatment
            x_values <- data$x
            if (all(x_values == floor(x_values), na.rm = TRUE)) {
                # Count unique X values
                n_unique_x <- length(unique(x_values))
                # If we have many observations but few unique X values, likely repeated measures
                if (total_obs > 50 && n_unique_x < 15) {
                    return(paste0(
                        "Data contains ", n_unique_x, " unique X values with ",
                        total_obs, " total observations. This pattern suggests time series ",
                        "or repeated measurements (e.g., Day 1, Day 7, Day 14)."
                    ))
                }
            }

            # Check 3: Look for variables with "patient", "subject", "id" in the data
            # (checked in parent data, not just plot_data)
            # Word-boundary anchors avoid substring false positives: a bare
            # "patient|subject|id|case" matched inside "candidate", "android",
            # "lowercase". \\b(...)\\b requires the token to stand alone.
            # NOTE: by the time this runs, jmvcore has already reduced the frame to the
            # analysis's own variables, so an ID column that exists in the user's spreadsheet
            # is usually not visible here. This check therefore misses most genuinely
            # clustered data; it is kept because a true hit is still informative.
            if (!is.null(self$data)) {
                col_names <- tolower(names(self$data))
                has_id_vars <- any(grepl("\\b(patient|subject|id|case)\\b", col_names))

                if (has_id_vars && total_obs > 50) {
                    return(paste0(
                        "Dataset contains identifier variables (patient/subject ID columns). ",
                        "If analyzing multiple observations per patient, results assume independence ",
                        "which may not be appropriate."
                    ))
                }
            }

            # No obvious repeated measures pattern detected
            return(NULL)
        },

        # Helper method: Adjust p-values handling NA correctly
        .adjustPValues = function(p_values) {
            p_adjust_method <- private$.option("p_adjust_method")
            if (p_adjust_method == "none") {
                return(p_values)
            }

            # CRITICAL FIX: Handle NA values correctly
            # Apply adjustment only to non-NA values, preserve NA positions
            non_na_indices <- which(!is.na(p_values))

            if (length(non_na_indices) == 0) {
                # All NA, return as is
                return(p_values)
            }

            # Adjust only non-NA p-values
            adjusted <- p_values
            adjusted[non_na_indices] <- p.adjust(p_values[non_na_indices],
                                                 method = p_adjust_method)

            return(adjusted)
        },

        # Helper method: Add test row to table
        .addTestRow = function(tests_table, test_result, adjusted_p, row_key) {
            # Warnings are now handled via jmvcore::Notice API directly where they occur
            # No need to accumulate warnings in HTML

            tests_table$addRow(
                rowKey = row_key,
                values = list(
                    comparison = test_result$comparison,
                    # Method label disambiguates the shared Statistic column: a Bayesian
                    # BF10, a Yuen statistic, an auto-switched Wilcoxon and a t all land
                    # in the same numeric column, so name the test that produced it.
                    method = test_result$test_method,
                    statistic = test_result$statistic,
                    p_value = test_result$p_value,
                    p_adjusted = adjusted_p,
                    effect_size = test_result$effect_size,
                    ci_lower = test_result$effect_ci_lower,  # Effect size CI, not test CI
                    ci_upper = test_result$effect_ci_upper   # Effect size CI, not test CI
                )
            )
        },

        .generateTests = function(data) {
            tests_table <- self$results$tests

            # See .generateStatistics: addRow() accepts duplicate rowKeys, so the table has
            # to be emptied before it is refilled or it accumulates across re-runs.
            tests_table$deleteRows()
            # Cliff's delta has a bootstrap confidence interval
            tests_table$setNote("seed", if (identical(private$.option("effsize_type"), "cliff_delta"))
                jmvcore::format(.("Random seed: {seed}"), seed = self$options$seed))

            # Reset the assumption-switch accumulator for this run
            private$.assumptionSwitches <- character(0)
            private$.assumptionNotes <- character(0)
            private$.testWarnings <- character(0)

            # Build stratification variables (facet and fill if present).
            #
            # A stratifier that IS the Y variable makes every stratum contain exactly one
            # Y group, so `length(groups) > 1` is never TRUE and the visible Statistical
            # Tests table stays empty while the completion notice still claims tests ran.
            # Ignore such a stratifier (the unstratified pairwise comparison is what the
            # user meant) and say so.
            y_var <- self$options$y_var
            strata_vars <- c()
            redundant_strata <- character(0)
            if (!is.null(self$options$facet_var) && "facet" %in% names(data)) {
                if (identical(self$options$facet_var, y_var))
                    redundant_strata <- c(redundant_strata, "Facet")
                else
                    strata_vars <- c(strata_vars, "facet")
            }
            if (!is.null(self$options$fill_var) && "fill" %in% names(data)) {
                if (identical(self$options$fill_var, y_var))
                    redundant_strata <- c(redundant_strata, "Fill")
                else
                    strata_vars <- c(strata_vars, "fill")
            }
            if (length(redundant_strata) > 0) {
                private$.addNotice(
                    'WARNING', 'Grouping variable reused',
                    paste0(
                        paste(redundant_strata, collapse = " and "),
                        " is the same variable as the Y (grouping) variable '", y_var,
                        "', so there is no within-stratum comparison to make. The pairwise ",
                        "comparisons below ignore it and compare the Y groups directly."
                    )
                )
            }

            # If there are strata, perform comparisons within each stratum
            if (length(strata_vars) > 0) {
                # Get all unique combinations of strata
                strata_combinations <- data %>%
                    dplyr::select(all_of(strata_vars)) %>%
                    distinct()

                all_test_results <- list()
                all_p_values <- numeric()

                # TODO (security forward-looking): `stratum_label` below interpolates
                # `stratum_val` which is a factor-level VALUE from user fill_var/facet_var
                # columns. Today it flows into Notice content (plain-text, safe) and
                # tests-table `comparison` cells (auto-escaped, safe). If this label
                # ever flows to a Html$setContent sink, wrap with `htmltools::htmlEscape`
                # at the assignment below.
                for (s in seq_len(nrow(strata_combinations))) {
                    # Filter data for this stratum
                    stratum_data <- data
                    stratum_label <- ""
                    for (sv in strata_vars) {
                        stratum_val <- strata_combinations[[sv]][s]
                        stratum_data <- stratum_data[stratum_data[[sv]] == stratum_val, ]
                        stratum_label <- paste0(stratum_label, if(stratum_label != "") " / " else "", sv, "=", stratum_val)
                    }

                    # Perform pairwise comparisons within this stratum
                    groups <- unique(stratum_data$y)
                    if (length(groups) > 1) {
                        comparisons <- combn(groups, 2, simplify = FALSE)

                        for (i in seq_along(comparisons)) {
                            private$.checkpoint(flush = FALSE)
                            group1 <- comparisons[[i]][1]
                            group2 <- comparisons[[i]][2]

                            data1 <- stratum_data$x[stratum_data$y == group1]
                            data2 <- stratum_data$x[stratum_data$y == group2]

                            # Perform test and store results with stratum label
                            test_result <- private$.performSingleTest(data1, data2, group1, group2, stratum_label)
                            all_test_results <- c(all_test_results, list(test_result))
                            all_p_values <- c(all_p_values, test_result$p_value)
                        }
                    }
                }

                # Apply p-value adjustment across all tests
                adjusted_p <- private$.adjustPValues(all_p_values)

                # Add rows to table
                for (i in seq_along(all_test_results)) {
                    private$.addTestRow(tests_table, all_test_results[[i]], adjusted_p[i], i)
                }

            } else {
                # No strata: perform simple pairwise comparisons as before
                groups <- unique(data$y)
                if (length(groups) > 1) {
                    comparisons <- combn(groups, 2, simplify = FALSE)
                    p_values <- numeric(length(comparisons))
                    test_results <- list()

                    for (i in seq_along(comparisons)) {
                        private$.checkpoint(flush = FALSE)
                        group1 <- comparisons[[i]][1]
                        group2 <- comparisons[[i]][2]

                        data1 <- data$x[data$y == group1]
                        data2 <- data$x[data$y == group2]

                        # Use helper method for single test
                        test_result <- private$.performSingleTest(data1, data2, group1, group2, "")
                        test_results[[i]] <- test_result
                        p_values[i] <- test_result$p_value
                    }

                    # Apply p-value adjustment using helper method
                    adjusted_p <- private$.adjustPValues(p_values)

                    # Add rows to table using helper method
                    for (i in seq_along(test_results)) {
                        private$.addTestRow(tests_table, test_results[[i]], adjusted_p[i], i)
                    }
                }
            }

            # Explain every row that came back blank. These messages were previously built
            # and thrown away, leaving NA statistic/p-value cells with no reason given.
            if (length(private$.testWarnings) > 0) {
                private$.addNotice(
                    'WARNING', 'Some comparisons could not be computed',
                    paste(unique(private$.testWarnings), collapse = " | ")
                )
            }

            # A visible but empty Statistical Tests table with a cheerful completion notice
            # is worse than no table. Say why it is empty.
            if (self$results$tests$rowCount == 0) {
                private$.addNotice(
                    'WARNING', 'No comparisons available',
                    paste0("No pairwise comparison could be made: at least two groups of '",
                           self$options$y_var, "' are needed within each stratum.")
                )
            }

            # Emit a SINGLE summarized notice for all assumption-based auto-switches
            # (rather than one notice per pairwise comparison).
            if (length(private$.assumptionSwitches) > 0) {
                n_switch <- length(private$.assumptionSwitches)
                private$.addNotice(
                    'WARNING',
                    'Assumption Check Failed',
                    paste0(
                        n_switch,
                        if (n_switch == 1) " comparison was" else " comparisons were",
                        " flagged by normality diagnostics. The selected Welch t-test was retained; assess its assumptions and prespecify the estimand rather than selecting tests from diagnostic p-values: ",
                        paste(private$.assumptionSwitches, collapse = " | ")
                    )
                )
            }

            # Report variance heterogeneity where it was found. It no longer switches the test
            # (Welch already handles it), but the user should still know.
            if (length(private$.assumptionNotes) > 0) {
                private$.addNotice(
                    'INFO', 'Unequal variances (handled by Welch)',
                    paste0(
                        "Levene's test indicated unequal variances for ",
                        length(private$.assumptionNotes),
                        if (length(private$.assumptionNotes) == 1) " comparison" else " comparisons",
                        ". These still used Welch's t-test, which does not assume equal ",
                        "variances, so no change of method was needed: ",
                        paste(private$.assumptionNotes, collapse = " | ")
                    )
                )
            }

            # Multiplicity. With k groups the table holds k(k-1)/2 pairwise tests, and
            # p_adjust_method defaults to "none". The only existing mention of correction sits
            # in the Statistical Assumptions panel, which is `showAssumptions: false` by
            # default -- so a user comparing five stages saw ten unadjusted p-values with
            # nothing on screen about it. Say it where it cannot be missed, and only when it
            # actually applies.
            n_comparisons <- self$results$tests$rowCount
            if (n_comparisons > 1 &&
                identical(private$.option("p_adjust_method"), "none")) {
                private$.addNotice(
                    'WARNING',
                    'Unadjusted p-values',
                    paste0(
                        n_comparisons, " pairwise comparisons are reported and no correction ",
                        "for multiple testing has been applied, so the P-adj column repeats the ",
                        "unadjusted p-value. Across ", n_comparisons,
                        " independent tests at the 0.05 level the chance of at least one false ",
                        "positive is about ",
                        round(100 * (1 - 0.95^n_comparisons)), "% when every null is true. ",
                        "Choose Bonferroni, Holm or FDR under 'P-value adjustment' if these ",
                        "comparisons are being screened rather than pre-specified."
                    )
                )
            }
        },

        .generateInterpretation = function(data) {
            # Generate clinical summary first
            clinical_summary <- private$.generateClinicalSummary(data, private$.option("show_stats"))

            # Traditional interpretation
            n_groups <- length(unique(data$y))
            n_total <- nrow(data)
            x_var_safe <- htmltools::htmlEscape(self$options$x_var)
            y_var_safe <- htmltools::htmlEscape(self$options$y_var)

            interpretation <- paste0(
                clinical_summary,
                "<h4>", .("Technical Interpretation"), "</h4>",
                "<p>", .("The ridge plot displays the distribution of"), " <strong>", x_var_safe, "</strong> ",
                .("across"), " <strong>", n_groups, " ", .("groups"), "</strong> ", .("defined by"), " <strong>", y_var_safe, "</strong>.</p>",
                "<ul>",
                "<li><strong>", .("Each ridge:"), "</strong> ", .("Shows the probability density or frequency distribution for a group"), "</li>",
                "<li><strong>", .("Overlapping areas:"), "</strong> ", .("Indicate similar value ranges between groups"), "</li>",
                "<li><strong>", .("Ridge height and spread:"), "</strong> ", .("Indicate the concentration and variability of values"), "</li>",
                "<li><strong>", .("Peaks:"), "</strong> ", .("Show the most common values (modes) within each group"), "</li>",
                "</ul>"
            )
            
            # Add plot-specific interpretations
            if (private$.option("plot_type") == "density_ridges_gradient") {
                interpretation <- paste0(
                    interpretation,
                    "<div style='background-color: rgba(33, 152, 239, 0.13); padding:10px; margin:10px 0; border-radius:4px; color: inherit;'>",
                    "<strong> ", .("Gradient Coloring:"), "</strong> ", .("Colors represent the value of"), " ",
                    x_var_safe, " ", .("along each ridge, helping visualize how values are distributed within groups."), "</div>"
                )
            }
            
            if (private$.option("add_boxplot")) {
                interpretation <- paste0(
                    interpretation,
                    "<div style='background-color: rgba(33, 159, 33, 0.1); padding:10px; margin:10px 0; border-radius:4px; color: inherit;'>",
                    "<strong> ", .("Boxplots:"), "</strong> ", .("Show median (center line), quartiles (box boundaries), and outliers for each group."), " ",
                    .("Compare medians and quartile ranges descriptively; clinical importance requires an appropriate clinical threshold."), "</div>"
                )
            }
            
            # Add statistical context if tests were run
            if (private$.option("show_stats")) {
                interpretation <- paste0(
                    interpretation,
                    "<div style='background-color: rgba(255, 169, 33, 0.14); padding:10px; margin:10px 0; border-radius:4px; color: inherit;'>",
                    "<strong> ", .("Statistical Tests:"), "</strong> ", .("Pairwise comparisons test whether group differences are statistically significant."), " ",
                    .("Consider effect sizes alongside p-values for clinical importance. Adjust for multiple comparisons when appropriate."), "</div>"
                )
            }
            
            self$results$interpretation$setContent(interpretation)
        },
        
        .plot = function(image, ggtheme, theme, ...) {
            if (is.null(self$options$x_var) || is.null(self$options$y_var))
                return()

            plot <- image$state
            if (is.null(plot))
                return(FALSE)

            # There is no per-analysis DPI knob to set here. The former code assigned
            # options(device.dpi = <n>) inside this renderer, which jamovi has already
            # read by the time it calls us - the device is open. Measured: the rendered
            # PNG was byte-identical and the same file size at 72 and at 600, while the
            # About panel told users to set 300 for journal submission. The option was
            # removed rather than left as a control that does nothing; resolution comes
            # from jamovi's own right-click "Save image as" dialog.
            #
            # ggridges emits "Picking joint bandwidth of <x>" from print(); jamovi routes
            # it to the Analysis Notes panel on EVERY render, where it reads as a problem.
            withCallingHandlers(
                print(plot),
                message = function(m) {
                    if (grepl("Picking joint bandwidth", conditionMessage(m), fixed = TRUE))
                        invokeRestart("muffleMessage")
                }
            )
            return(TRUE)
        },
        
        .calculateCliffsDelta = function(x, y) {
            # Manual computation of Cliff's Delta: proportion of pairs where x > y
            # minus proportion where x < y. (effectsize has no `cliff_delta` export -
            # the actual name is `cliffs_delta` with a different result API - so the
            # former effectsize call always threw and fell through to NA. This
            # dependency-free definition is exact and used directly.)
            x <- x[!is.na(x)]
            y <- y[!is.na(y)]
            n1 <- length(x)
            n2 <- length(y)
            if (n1 == 0 || n2 == 0) return(NA_real_)

            greater <- 0
            less <- 0

            for (xi in x) {
                for (yj in y) {
                    if (xi > yj) greater <- greater + 1
                    else if (xi < yj) less <- less + 1
                }
            }

            delta <- (greater - less) / (n1 * n2)
            return(delta)
        },
        
        .calculateHodgesLehmann = function(x, y) {
            # Hodges-Lehmann shift: median of all pairwise differences (x - y)
            # Shows typical difference in lymph node counts between techniques
            x <- x[!is.na(x)]
            y <- y[!is.na(y)]
            if (length(x) == 0 || length(y) == 0) return(NA_real_)

            # Use vectorised outer for efficiency
            differences <- as.vector(outer(x, y, "-"))
            return(median(differences))
        }
    ), # End of private list
    public = list(
        #' @description
        #' Generate R source code for Ridge Plot analysis
        #' @return Character string with R syntax for reproducible analysis
        asSource = function() {
            x_var <- self$options$x_var
            y_var <- self$options$y_var

            if (is.null(x_var) || is.null(y_var))
                return('')

            # Build the argument list in option-declaration order.
            #
            # Every variable-name option (single OptionVariable or multi-variable
            # OptionVariables) is emitted as a deparse()'d string literal. deparse()
            # produces valid, fully-escaped R for names containing spaces, quotes or
            # backslashes (e.g. `Tumor Grade`); jmvcore's default sourcify would emit
            # some of these as bare, unquoted symbols and yield invalid syntax.
            # Detecting the option by CLASS (not by name) means any variable option
            # added later is escaped automatically.
            #
            # Variables are NOT re-emitted through private$.asArgs() - doing so
            # previously duplicated them in the generated syntax (the "double
            # variables" bug). All non-variable options keep jmvcore's per-option
            # sourcify so formatting stays consistent with jamovi.
            args <- character(0)
            for (option in private$.options$options) {
                if (option$name == 'data')
                    next
                if (inherits(option, 'OptionVariable') || inherits(option, 'OptionVariables')) {
                    val <- option$value
                    if (!is.null(val) && length(val) > 0)
                        args <- c(args, paste0(option$name, ' = ',
                                               paste0(deparse(val), collapse = '')))
                } else {
                    as <- private$.sourcifyOption(option)
                    if (!identical(as, ''))
                        args <- c(args, as)
                }
            }

            # Get package name dynamically
            pkg_name <- utils::packageName()
            if (is.null(pkg_name)) pkg_name <- "ClinicoPath"  # fallback

            # Build complete function call
            paste0(pkg_name, '::jjridges(\n    data = data,\n    ',
                   paste(args, collapse = ',\n    '), ')')
        }
    ) # End of public list
)
