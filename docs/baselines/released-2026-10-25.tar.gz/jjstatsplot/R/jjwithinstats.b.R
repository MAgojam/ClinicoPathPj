#' @title Box-Violin Plots to Compare Within Groups
#'
#' @description
#' Creates violin plots for within-subjects (repeated measures) analysis using
#' ggstatsplot::ggwithinstats. Compares 2-4 measurements from the same subjects
#' with statistical testing and pairwise comparisons. Ideal for biomarker tracking,
#' treatment response monitoring, and longitudinal clinical studies.
#'
#' @param data Data frame in wide format (one row per subject, columns for time points)
#' @param dep1 First measurement variable (required, numeric)
#' @param dep2 Second measurement variable (required, numeric)
#' @param dep3 Third measurement variable (optional, numeric)
#' @param dep4 Fourth measurement variable (optional, numeric)
#' @param typestatistics Type of statistical test: "parametric" (repeated measures ANOVA),
#'   "nonparametric" (Friedman test), "robust" (trimmed means), or "bayes" (Bayesian)
#' @param pairwisecomparisons Logical, whether to display pairwise comparisons between
#'   time points (default: FALSE)
#' @param pairwisedisplay Which pairwise comparisons to show: "significant",
#'   "non-significant", or "everything" (default: "significant")
#' @param padjustmethod P-value adjustment method for multiple comparisons:
#'   "holm" (default), "hochberg", "bonferroni", "BH", "fdr", etc.
#' @param effsizetype Effect size type for parametric tests: "biased" (Cohen's d),
#'   "unbiased" (Hedge's g), "eta", or "omega"
#' @param centralityplotting Logical, whether to display mean/median trend lines
#' @param centralitytype Type of centrality measure: "parametric" (mean),
#'   "nonparametric" (median), "robust" (trimmed mean), or "bayes"
#' @param pointpath Logical, whether to show individual subject trajectories
#' @param centralitypath Logical, whether to connect centrality points across measurements
#' @param violin Logical, display violin plot layer
#' @param boxplot Logical, display box plot layer
#' @param point Logical, display individual data points
#' @param mytitle Plot title (default: "Within Group Comparison")
#' @param xtitle X-axis label (default: auto from measurement names)
#' @param ytitle Y-axis label (default: auto from value variable)
#' @param originaltheme Logical, use ggstatsplot theme (TRUE) or jamovi theme (FALSE)
#' @param resultssubtitle Logical, display statistical results as subtitle
#' @param bfmessage Logical, display Bayes Factor message for Bayesian analysis
#' @param conflevel Confidence level for intervals (default: 0.95)
#' @param k Number of decimal places for statistics (default: 2)
#' @param plotwidth Plot width in pixels (default: 650)
#' @param plotheight Plot height in pixels (default: 450)
#' @param clinicalpreset Clinical analysis preset: "custom", "biomarker",
#'   "treatment", or "laboratory"
#' @param addGGPubrPlot Logical, add publication-ready ggpubr variant plot
#' @param ggpubrPlotType Type of ggpubr plot: "boxplot", "violin", "paired", or "line"
#' @param ggpubrPalette Color palette for ggpubr: "jco", "npg", "aaas", "lancet", etc.
#' @param ggpubrAddStats Logical, add statistical comparisons to ggpubr plot
#' @param ggpubrShowLines Logical, show connecting lines in paired plot
#' @param ggpubrAddPoints Logical, overlay individual points on ggpubr plot
#' @param showExplanations Logical, display explanations of statistical methods
#'
#' @return A jamovi analysis object with violin plots, statistical tests, and
#'   clinical interpretation
#'
#' @details
#' **Data Requirements:**
#' - Wide format required (one row per subject)
#' - Each column represents a different time point or condition
#' - Complete data required for paired analysis (listwise deletion)
#' - Minimum 3 subjects with complete data across all measurements
#'
#' **Statistical Tests:**
#' - Parametric: Repeated measures ANOVA (assumes normality)
#' - Nonparametric: Friedman test (no distribution assumptions)
#' - Robust: Uses trimmed means (resistant to outliers)
#' - Bayesian: Provides evidence strength via Bayes Factors
#'
#' **Clinical Presets:**
#' - Biomarker: Optimized for laboratory biomarker tracking (nonparametric)
#' - Treatment: Optimized for treatment response monitoring (parametric with pairwise)
#' - Laboratory: Optimized for clinical lab values (robust)
#'
#' @section Performance Optimization:
#' The function implements sophisticated caching:
#' - Data preparation cached based on variable selection and data content
#' - Options cached separately to minimize reprocessing
#' - Plot state management prevents unnecessary regeneration
#' - Checkpoint calls before expensive operations for responsiveness
#'
#' @section Clinical Validation:
#' The function performs comprehensive data quality checks:
#' - Validates paired design requirements (complete cases)
#' - Detects small sample sizes (< 10 subjects)
#' - Identifies potential outliers (> 10% outliers)
#' - Warns about skewed data for parametric tests
#' - Alerts to high missing data rates (> 50%)
#'
#' @examples
#' \dontrun{
#' # Basic within-subjects analysis
#' data(iris)
#' iris_wide <- data.frame(
#'     Subject = 1:50,
#'     Baseline = iris$Sepal.Length[1:50],
#'     Month3 = iris$Sepal.Width[1:50] * 2.5,
#'     Month6 = iris$Petal.Length[1:50] * 1.8
#' )
#'
#' jjwithinstats(
#'     data = iris_wide,
#'     dep1 = "Baseline",
#'     dep2 = "Month3",
#'     dep3 = "Month6",
#'     typestatistics = "parametric",
#'     pairwisecomparisons = TRUE,
#'     centralityplotting = TRUE,
#'     pointpath = TRUE
#' )
#'
#' # Clinical biomarker tracking (nonparametric)
#' jjwithinstats(
#'     data = clinical_data,
#'     dep1 = "CRP_baseline",
#'     dep2 = "CRP_week4",
#'     dep3 = "CRP_week12",
#'     clinicalpreset = "biomarker",
#'     typestatistics = "nonparametric",
#'     pairwisecomparisons = TRUE,
#'     mytitle = "C-Reactive Protein Levels During Treatment"
#' )
#'
#' # Robust analysis with publication plot
#' jjwithinstats(
#'     data = lab_data,
#'     dep1 = "ALT_pre",
#'     dep2 = "ALT_post",
#'     typestatistics = "robust",
#'     centralityplotting = TRUE,
#'     centralitytype = "robust",
#'     addGGPubrPlot = TRUE,
#'     ggpubrPlotType = "paired",
#'     ggpubrAddStats = TRUE
#' )
#' }
#'
#' @references
#' Patil, I. (2021). Visualizations with statistical details: The 'ggstatsplot' approach.
#'   Journal of Open Source Software, 6(61), 3167. \doi{10.21105/joss.03167}
#'
#' @seealso
#' \code{\link[ggstatsplot]{ggwithinstats}} for the underlying plotting function
#'
#' @family JJStatsPlot functions
#' @keywords hplot htest
#'
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @importFrom rlang sym
#' @importFrom digest digest
#' @importFrom ggstatsplot ggwithinstats theme_ggstatsplot
#' @importFrom ggpubr ggpaired ggboxplot ggviolin ggline stat_compare_means theme_pubr
jjwithinstatsClass <- if (requireNamespace('jmvcore')) R6::R6Class(
    "jjwithinstatsClass",
    inherit = jjwithinstatsBase,
    private = list(
        # Set by .subtitleExpr when the takeover was attempted and failed.
        .subtitleFallback = NULL,

        # Fixed seed for the sampling-based paths (Bayesian MCMC, robust
        # bootstrap), so the same analysis reports the same numbers on every
        # render rather than drifting between refreshes.

        .prepared_data = NULL,
        .prepared_options = NULL,
        .data_hash = NULL,
        .options_hash = NULL,
        .messages = NULL,
        .info_messages = NULL,
        .data_messages = NULL,
        .data_info_messages = NULL,
        .subtitle_cache = NULL,
        .subtitle_cache_key = NULL,

        # Shared welcome / getting-started message (used by .init and .run) ----
        .welcomeMessage = function() {
            paste0(
                "<br><strong>Welcome to ClinicoPath</strong><br><br>",
                "This tool generates Violin Plots for repeated measurements (e.g., biomarker levels over time, treatment responses).<br><br>",
                "<strong>Data Format:</strong> Wide format required - each row = one subject, columns = separate time points/measurements.<br><br>",
                "<strong>Requirements:</strong><br>",
                "\u2022 Select at least 2 measurements (First and Second Measurement fields)<br>",
                "\u2022 No missing values allowed<br>",
                "\u2022 Use for comparing 2-4 measurements from the same subjects<br><br>",
                "See documentation: <a href='https://www.indrapatil.com/ggstatsplot/reference/ggwithinstats.html' target='_blank'>ggwithinstats</a><br>",
                "Please cite jamovi and packages as instructed.<br><hr>"
            )
        },

        # init ----

        .init = function() {
            # Use configurable plot dimensions with smart scaling
            plotwidth <- if (!is.null(self$options$plotwidth)) self$options$plotwidth else 650
            plotheight <- if (!is.null(self$options$plotheight)) self$options$plotheight else 450
            
            # Only setup plot if variables are selected
            if (!is.null(self$options$dep1) && !is.null(self$options$dep2)) {
                # Calculate proportional scaling based on number of measurements
                num_measurements <- sum(!is.null(self$options$dep1), !is.null(self$options$dep2),
                                      !is.null(self$options$dep3), !is.null(self$options$dep4))
                
                if (num_measurements > 2) {
                    # Proportional scaling instead of magic numbers
                    scale_factor_width <- 1 + (num_measurements - 2) * 0.15  # 15% per additional measurement
                    scale_factor_height <- 1 + (num_measurements - 2) * 0.1   # 10% per additional measurement
                    plotwidth <- plotwidth * scale_factor_width
                    plotheight <- plotheight * scale_factor_height
                }
                
                self$results$plot$setSize(plotwidth, plotheight)
                
                # Apply clinical presets if selected
                private$.applyClinicalPresets()
                
                # Pre-prepare data and options for performance
                private$.prepareData(emit_messages = FALSE)
                private$.prepareOptions()
                
                # Clear any welcome message when variables are selected
                self$results$todo$setContent("")
            } else {
                # Hide plot when insufficient variables selected
                self$results$plot$setVisible(visible = FALSE)
                
                # Show welcome message when insufficient variables
                welcome_msg <- private$.welcomeMessage()

                self$results$todo$setVisible(visible = TRUE)
                self$results$todo$setContent(welcome_msg)
            }

        },
        
        # WARNING-grade messages only. These are the ones a user has to act on,
        # so the "Messages" panel is reserved for them; procedural progress notes
        # go to .accumulateInfoMessage() and are rendered under the summary
        # instead. When every run filled this panel with "Processing 3
        # measurements..." there was no visual difference between a healthy run
        # and one reporting 60% missing data.
        .accumulateMessage = function(message) {
            if (is.null(private$.messages)) {
                private$.messages <- character()
            }
            private$.messages <- append(private$.messages, message)

            # Render accumulated messages into the HTML warnings output
            if (!is.null(self$results$warnings)) {
                self$results$warnings$setContent(paste(private$.messages, collapse = ""))
                self$results$warnings$setVisible(TRUE)
            }
        },

        # INFO-grade progress notes (how many measurements, how many subjects
        # retained). Collected here and appended to the Analysis Summary by
        # .run(); never routed to the warning panel.
        .accumulateInfoMessage = function(message) {
            if (is.null(private$.info_messages)) {
                private$.info_messages <- character()
            }
            private$.info_messages <- append(private$.info_messages, message)
        },

        # Muted block appended to the Analysis Summary panel.
        .renderInfoBlock = function() {
            if (length(private$.info_messages) == 0) return("")
            paste0(
                "<div style='background-color: rgba(138, 155, 172, 0.06); padding:8px; ",
                "margin-top:8px; color: inherit; font-size: 0.95em;'>",
                paste(private$.info_messages, collapse = ""),
                "</div>")
        },

        # Reset messages for new analysis run
        .resetMessages = function() {
            private$.messages <- character()
            private$.info_messages <- character()
            # Don't clear TODO here, as it might hold "Welcome" or "Ready"
            # warning content is cleared
            if (!is.null(self$results$warnings)) {
                self$results$warnings$setContent("")
                # Don't hide yet, wait until run to decide visibility or let specific checks set it
            }
        },

        # HTML sanitization for security
        .safeHtmlOutput = function(text) {
            if (is.null(text) || length(text) == 0) return("")
            text <- as.character(text)
            # Sanitize potentially dangerous characters
            text <- gsub("&", "&amp;", text, fixed = TRUE)
            text <- gsub("<", "&lt;", text, fixed = TRUE)
            text <- gsub(">", "&gt;", text, fixed = TRUE)
            text <- gsub("\"", "&quot;", text, fixed = TRUE)
            text <- gsub("'", "&#x27;", text, fixed = TRUE)
            text <- gsub("/", "&#x2F;", text, fixed = TRUE)
            return(text)
        },

        # Helper to cache data-specific messages
        .accumulateDataMessage = function(message) {
            private$.data_messages <- append(private$.data_messages, message)
            private$.accumulateMessage(message)
        },

        # Same, for INFO-grade progress notes (cached separately so a cache hit
        # replays each message at its own severity).
        .accumulateDataInfoMessage = function(message) {
            private$.data_info_messages <- append(private$.data_info_messages, message)
            private$.accumulateInfoMessage(message)
        },
        
        # Name of the test that is ACTUALLY run. With TWO measurements the
        # analysis is a paired t-test / Wilcoxon signed-rank, not an ANOVA; the
        # summary panel called every configuration a "Repeated measures ANOVA",
        # so a two-timepoint comparison was described as an ANOVA in text offered
        # for a methods section.
        .testLabel = function(typestatistics, num_measurements) {
            two <- !is.na(num_measurements) && num_measurements <= 2
            switch(typestatistics,
                "parametric"    = if (two) .("Paired samples t-test") else .("Repeated measures ANOVA"),
                "nonparametric" = if (two) .("Wilcoxon signed-rank test") else .("Friedman test"),
                "robust"        = if (two) .("Robust paired test (Yuen's trimmed means)") else .("Robust repeated measures test"),
                "bayes"         = if (two) .("Bayesian paired samples t-test") else .("Bayesian repeated measures analysis"),
                .("Within-subjects comparison"))
        },

        # ggstatsplot 1.0.0 removed `pairwise.comparisons`; "none" is how the
        # significance brackets are switched off now. Without this, unticking the
        # box left the brackets on the plot.
        .pairwiseDisplay = function(opts) {
            if (isTRUE(opts$pairwisecomparisons)) opts$pairwisedisplay else "none"
        },

        # Build the plot subtitle ourselves.
        #
        # ggstatsplot 1.0.0 also removed `effsize.type` from ggwithinstats, so
        # the effect-size selector had no effect: all four choices produced
        # Hedges' g. statsExpressions - which ggstatsplot calls internally - still
        # honours it, and crucially still applies the Greenhouse-Geisser
        # sphericity correction for 3+ measurements (verified: the takeover
        # reproduces F_Fisher(1.79, 69.71) = 94.54, p = 1.54e-19 exactly, the
        # same fractional degrees of freedom the untouched plot shows).
        #
        # Returns NULL when we should not take over, in which case the caller
        # leaves ggstatsplot to build its own subtitle.
        # Memoised wrapper. .run() probes the takeover to decide whether to warn
        # the user, and .plot() needs the expression itself; without this the
        # robust bootstrap and the Bayesian sampler ran twice per cycle.
        .subtitleExpr = function(long_data, opts, num_measurements) {
            key <- paste(private$.data_hash, private$.options_hash,
                         num_measurements, sep = "|")
            if (identical(private$.subtitle_cache_key, key)) {
                private$.subtitleFallback <- private$.subtitle_cache$fallback
                return(private$.subtitle_cache$expr)
            }
            private$.subtitleFallback <- NULL
            expr <- private$.computeSubtitleExpr(long_data, opts, num_measurements)
            private$.subtitle_cache <- list(expr = expr,
                                            fallback = private$.subtitleFallback)
            private$.subtitle_cache_key <- key
            expr
        },

        .computeSubtitleExpr = function(long_data, opts, num_measurements) {
            if (!isTRUE(opts$resultssubtitle)) return(NULL)
            if (is.na(num_measurements) || num_measurements < 2) return(NULL)
            # Leave the Bayesian path to ggstatsplot: taking the subtitle over
            # sets results.subtitle = FALSE, which also suppresses the
            # bf.message caption, silently disabling the 'Bayes factor message'
            # checkbox.
            if (identical(opts$typestatistics, "bayes")) return(NULL)
            # Taking the subtitle over sets results.subtitle = FALSE, which also
            # removes ggstatsplot's Bayes-factor caption. If the user asked for
            # that caption, leave the whole subtitle to ggstatsplot rather than
            # silently dropping it.
            if (isTRUE(opts$bfmessage)) {
                private$.subtitleFallback <-
                    .("the Bayes factor message is switched on, which ggstatsplot renders alongside its own subtitle")
                return(NULL)
            }

            # two_sample_test accepts only g/d/unbiased/biased; the ANOVA-only
            # names error, so map them onto the equivalent two-group family.
            eff <- opts$effsizetype
            if (num_measurements <= 2) {
                if (identical(eff, "eta"))   eff <- "biased"
                if (identical(eff, "omega")) eff <- "unbiased"
            }

            fn <- if (num_measurements <= 2) statsExpressions::two_sample_test
                  else                       statsExpressions::oneway_anova

            # Seed HERE rather than at the call site. The Bayesian sampler and
            # the robust bootstrap are stochastic, and this is reached from two
            # places: .run()'s takeover probe and .plot(). Only .plot() used to
            # set the seed, so once the result became memoised the cached value
            # came from whichever caller ran first - the unseeded probe - and
            # the "same analysis reports the same numbers" guarantee was lost.
            if (opts$typestatistics %in% c("bayes", "robust"))
                withr::local_seed(self$options$seed)

            res <- tryCatch(
                rlang::inject(fn(
                    data         = long_data,
                    x            = !!rlang::sym("measurement"),
                    y            = !!rlang::sym("value"),
                    subject.id   = !!rlang::sym("rowid"),
                    paired       = TRUE,
                    type         = opts$typestatistics,
                    effsize.type = eff,
                    digits       = opts$digits,
                    conf.level   = opts$conflevel)),
                error = function(e) e)

            if (inherits(res, "condition")) {
                private$.subtitleFallback <- conditionMessage(res)
                return(NULL)
            }
            if (is.null(res$expression) || length(res$expression) == 0) return(NULL)
            res$expression[[1]]
        },

        # Apply clinical presets for common scenarios
        .applyClinicalPresets = function() {
            if (is.null(self$options$clinicalpreset) || self$options$clinicalpreset == "custom") {
                return()  # No preset to apply
            }
            
            # Apply preset configurations based on clinical scenario
            switch(self$options$clinicalpreset,
                "biomarker" = {
                    # Biomarker tracking: nonparametric, show individual trajectories
                    if (self$options$typestatistics == "parametric") {  # Only change if default
                        # Would need to update options through proper channels
                        private$.accumulateMessage(.("Biomarker preset: Consider using Nonparametric test for skewed biomarker data<br>"))
                    }
                    private$.accumulateMessage(.("<strong>Biomarker tracking (guidance only):</strong> Optimized for laboratory values. Please manually ensure 'Nonparametric' is selected if data is skewed.<br>"))
                },
                "treatment" = {
                    # Treatment response: parametric with pairwise comparisons
                    if (!self$options$pairwisecomparisons) {
                        private$.accumulateMessage(.("Treatment preset: Enable pairwise comparisons to identify when treatment effects occur<br>"))
                    }
                    private$.accumulateMessage(.("<strong>Treatment response:</strong> Optimized for clinical treatment monitoring<br>"))
                },
                "laboratory" = {
                    # Laboratory values: robust with centrality plotting
                    if (self$options$typestatistics == "parametric") {
                        private$.accumulateMessage(.("Laboratory preset: Consider Robust test to handle outliers common in lab values<br>"))
                    }
                    if (!self$options$centralityplotting) {
                        private$.accumulateMessage(.("Laboratory preset: Enable centrality plotting to see overall trends<br>"))
                    }
                    private$.accumulateMessage(.("<strong>Laboratory values:</strong> Optimized for clinical lab value monitoring<br>"))
                }
            )
        },
        
        # Enhanced input validation with comprehensive checks
        .validateInputs = function() {
            # Basic requirement check
            if (is.null(self$options$dep1) || is.null(self$options$dep2))
                return(FALSE)
            
            # Comprehensive data structure validation
            private$.validateDataStructure()
            
            # Variable-specific validation
            vars <- c(self$options$dep1, self$options$dep2, 
                      self$options$dep3, self$options$dep4)
            vars <- vars[!sapply(vars, is.null)]
            
            private$.validateVariableTypes(vars)
            
            return(TRUE)
        },
        
        # Comprehensive data structure validation
        .validateDataStructure = function() {
            if (!is.data.frame(self$data))
                jmvcore::reject(.("Data must be a data frame"))
            if (nrow(self$data) == 0)
                jmvcore::reject(.("Data contains no (complete) rows"))
            if (ncol(self$data) < 2)
                jmvcore::reject(.("Data must contain at least 2 columns"))
            if (!is.finite(nrow(self$data)) || !is.finite(ncol(self$data)))
                jmvcore::reject(.("Data dimensions are invalid"))
        },

        # Variable type and existence validation
        .validateVariableTypes = function(vars) {
            for (var in vars) {
                if (!(var %in% names(self$data)))
                    jmvcore::reject(.("Variable '{name}' not found in data"), name = var)

                # Check if variable can be converted to numeric
                test_vals <- self$data[[var]]
                if (!is.numeric(test_vals)) {
                    converted_vals <- suppressWarnings(as.numeric(as.character(test_vals)))
                    if (all(is.na(converted_vals)) && !all(is.na(test_vals)))
                        jmvcore::reject(.("Variable '{name}' cannot be converted to numeric values"), name = var)
                }
            }
        },
        
        # Data quality validation helper
        .validateDataQuality = function(mydata, vars) {
            # Checkpoint before expensive validation loop
            private$.checkpoint()
            
            for (var in vars) {
                num_vals <- jmvcore::toNumeric(mydata[[var]])
                num_vals <- num_vals[!is.na(num_vals)]
                # htmlEscape user column name before flowing into legacy warnings$setContent
                var_safe <- private$.safeHtmlOutput(var)

                if (length(num_vals) < 3) {
                    private$.accumulateDataMessage(
                        glue::glue(.("<br> <strong>Warning:</strong> {var_safe} has less than 3 valid observations<br>"))
                    )
                }
                if (length(unique(num_vals)) < 2) {
                    private$.accumulateDataMessage(
                        glue::glue(.("<br> <strong>Warning:</strong> {var_safe} has no variation (all values identical)<br>"))
                    )
                }
            }
            
            # Additional clinical misuse detection
            private$.detectClinicalMisuse(mydata, vars)
        },
        
        # Clinical misuse detection and guidance
        .detectClinicalMisuse = function(mydata, vars) {
            total_subjects <- nrow(mydata)
            
            # Small sample size warning
            if (total_subjects < 10) {
                private$.accumulateDataMessage(
                    .("<br> <strong>Small Sample Size:</strong> With fewer than 10 subjects, results may be unreliable. Consider larger sample or descriptive analysis.<br>")
                )
            }
            
            # Check for potential outliers across all variables
            for (var in vars) {
                num_vals <- jmvcore::toNumeric(mydata[[var]])
                num_vals <- num_vals[!is.na(num_vals)]
                
                if (length(num_vals) > 4) {  # Need enough data points to detect outliers
                    q75 <- quantile(num_vals, 0.75, na.rm = TRUE)
                    q25 <- quantile(num_vals, 0.25, na.rm = TRUE)
                    iqr <- q75 - q25
                    outliers <- sum(num_vals > (q75 + 1.5 * iqr) | num_vals < (q25 - 1.5 * iqr))
                    
                    if (outliers > length(num_vals) * 0.1) {  # More than 10% outliers
                        private$.accumulateDataMessage(
                            .("<br> <strong>Many Outliers Detected:</strong> Consider Robust test type to reduce outlier influence<br>")
                        )
                        break  # Only show this message once
                    }
                }
            }
            
            # Check for extremely skewed data that might benefit from nonparametric tests
            if (self$options$typestatistics == "parametric") {
                for (var in vars) {
                    num_vals <- jmvcore::toNumeric(mydata[[var]])
                    # is.finite(), not !is.na(): is.na() is TRUE for NaN but
                    # FALSE for Inf, so an infinite value survived into sd(),
                    # which returned NaN. `NaN > 0` is NA, and the `if (NA)`
                    # below aborted the entire analysis with the unactionable
                    # "missing value where TRUE/FALSE needed".
                    num_vals <- num_vals[is.finite(num_vals)]

                    if (length(num_vals) > 5) {
                        # Moment coefficient of skewness (g1). |skewness| > 1
                        # flags a substantially skewed distribution, a far more
                        # reliable criterion than |mean - median| > sd.
                        n_v <- length(num_vals)
                        mean_val <- mean(num_vals)
                        sd_val <- sd(num_vals)
                        skewness <- if (is.finite(sd_val) && sd_val > 0)
                            (sum((num_vals - mean_val)^3) / n_v) / (sd_val^3)
                        else
                            0

                        if (is.finite(skewness) && abs(skewness) > 1) {  # Substantially skewed
                            private$.accumulateDataMessage(
                                .("<br> <strong>Skewed Data Detected:</strong> Consider Nonparametric test for skewed biomarker or clinical data<br>")
                            )
                            break  # Only show this message once
                        }
                    }
                }
            }
        },

        # Optimized data preparation with robust caching
        .prepareData = function(force_refresh = FALSE, emit_messages = TRUE) {
            # IMMEDIATE CHECK: Return NULL if minimum variables not selected
            if (is.null(self$options$dep1) || is.null(self$options$dep2)) {
                return(NULL)
            }
            
            # Checkpoint before expensive hash computation for large datasets
            private$.checkpoint(flush = FALSE)

            # CRITICAL FIX: Create robust hash including ACTUAL DATA VALUES
            # Bug: Old code only hashed variable names and dimensions
            # Result: Editing data values didn't invalidate cache, showing outdated results
            vars <- Filter(Negate(is.null), c(self$options$dep1, self$options$dep2,
                                             self$options$dep3, self$options$dep4))

            # Extract actual data for selected variables using the RAW variable
            # names. data.frame column access requires the raw name; a
            # composeTerm()/backtick-quoted name (e.g. `CRP baseline`) yields an
            # "undefined columns selected" error for names with spaces/symbols.
            data_subset <- self$data[, vars, drop = FALSE]

            current_hash <- digest::digest(list(
                dep1 = self$options$dep1, dep2 = self$options$dep2,
                dep3 = self$options$dep3, dep4 = self$options$dep4,
                data_dim = dim(self$data), col_names = names(self$data),
                # CRITICAL FIX: Include actual data content in hash
                data_content = data_subset
            ), algo = "md5")
            
            # Only reprocess if data has changed or forced refresh
            if (!is.null(private$.prepared_data) &&
                private$.data_hash == current_hash &&
                !force_refresh) {
                # Re-emit cached data messages only when the caller wants them
                # (i.e. .run(), which calls .resetMessages() first). Render calls
                # (.plot()/.init()) pass emit_messages = FALSE so warnings are
                # not appended a second time and duplicated in the output.
                if (emit_messages) {
                    for (msg in private$.data_messages) {
                        private$.accumulateMessage(msg)
                    }
                    for (msg in private$.data_info_messages) {
                        private$.accumulateInfoMessage(msg)
                    }
                }
                return(private$.prepared_data)
            }
            
            # Reset data messages for new processing
            private$.data_messages <- character()
            private$.data_info_messages <- character()
            
            # Add processing feedback
            private$.accumulateDataInfoMessage(
                glue::glue(.("<br>Processing {length(vars)} measurements for within-subjects analysis.<br>"))
            )
            
            # Variables already validated above, proceed with data preparation
            mydata <- self$data[, vars, drop = FALSE]
            
            # Check for empty dataset
            if (nrow(mydata) == 0) {
                private$.accumulateDataMessage(
                    .("<br> Dataset is empty (0 rows). Please load data first.<br>")
                )
                private$.prepared_data <- NULL
                return(NULL)
            }
            
            # Two slots holding the same variable produce duplicate column names
            # and a raw "factor level [2] is duplicated" crash out of
            # pivot_longer(), reached uncaught from .init(). Reject it with a
            # message that says what to do about it.
            if (anyDuplicated(vars)) {
                dup <- unique(vars[duplicated(vars)])
                jmvcore::reject(
                    .("Each measurement must be a different variable ('{var}' is selected more than once)."),
                    var = paste(dup, collapse = ", "))
            }

            subject_ids <- seq_len(nrow(mydata))

            # Check if required variables exist in dataset (raw names)
            missing_vars <- vars[!vars %in% names(mydata)]
            if (length(missing_vars) > 0) {
                private$.accumulateDataMessage(
                    paste0(
                        "<br>",
                        .fmt(
                            .("Variables not found in the dataset: {vars}."),
                            vars = private$.safeHtmlOutput(paste(missing_vars, collapse = ", "))),
                        "<br>")
                )
                private$.prepared_data <- NULL
                return(NULL)
            }
            
            # Checkpoint before expensive data conversion loop
            private$.checkpoint()

            # Convert variables to numeric with labelled awareness
            non_numeric <- character()
            for (var in vars) {
                col <- mydata[[var]]

                # jmvcore::toNumeric() extracts the underlying numeric values,
                # including for haven_labelled columns (SPSS/Stata imports).
                # Do NOT route haven_labelled through haven::as_factor(levels =
                # "both") first: that replaces the real measurement values with
                # factor position codes (e.g. 10, 20, 30 -> 1, 2, 3), silently
                # corrupting the within-subjects analysis.
                num <- jmvcore::toNumeric(col)

                # toNumeric() is a NO-OP on a plain character or factor column:
                # it only unwraps a jamovi `values` attribute and otherwise
                # returns its argument untouched. So a text measurement passed
                # straight through this loop and died two calls later inside
                # quantile() with "non-numeric argument to binary operator".
                # jamovi's `permitted: [ numeric ]` keeps text out of the GUI
                # picker, but an R-API caller reaches here.
                if (!is.numeric(num))
                    num <- suppressWarnings(as.numeric(as.character(num)))
                if (all(is.na(num)) && !all(is.na(col)))
                    non_numeric <- c(non_numeric, var)

                mydata[[var]] <- num
            }
            if (length(non_numeric)) {
                jmvcore::reject(
                    .("Each measurement must be a numeric variable ('{var}' contains no usable numbers)."),
                    var = paste(non_numeric, collapse = ", "))
            }
            
            # Enhanced validation for optional parameters
            if (!is.null(self$options$dep3) && is.null(self$options$dep2)) {
                jmvcore::reject(.('Second measurement required when third is specified'))
            }
            if (!is.null(self$options$dep4) && is.null(self$options$dep3)) {
                jmvcore::reject(.('Third measurement required when fourth is specified'))
            }

            # CRITICAL FIX: Validate paired design structure
            # Within-subjects analysis requires complete data for all subjects across measurements
            # Check for excessive missing data that would break paired tests
            n_rows <- nrow(mydata)
            complete_cases <- sum(Reduce(`&`, lapply(mydata[, vars, drop = FALSE], is.finite)))
            missing_pct <- (1 - complete_cases/n_rows) * 100

            if (complete_cases < 3) {
                warning_msg <- paste0(
                    "<div style='background-color: rgba(255, 202, 33, 0.23); border-left:4px solid #ff9800; padding:15px; margin:10px 0; color: inherit;'>",
                    "<h4 style='color:#ff6f00; margin-top:0;'> Insufficient Complete Cases for Paired Analysis</h4>",
                    "<p><strong>Within-subjects analysis requires complete data across all measurements.</strong></p>",
                    "<p>Current status:</p>",
                    "<ul>",
                    "<li>Total subjects: ", n_rows, "</li>",
                    "<li>Complete cases (all measurements present): ", complete_cases, "</li>",
                    "<li>Missing data: ", round(missing_pct, 1), "%</li>",
                    "</ul>",
                    "<p><strong>Minimum required:</strong> At least 3 subjects with complete data across all measurements.</p>",
                    "</div>"
                )
                private$.accumulateDataMessage(warning_msg)
                private$.prepared_data <- NULL
                return(NULL)
            }

            if (missing_pct > 50) {
                warning_msg <- paste0(
                    "<div style='background-color: rgba(255, 202, 33, 0.23); border-left:4px solid #ffc107; padding:15px; margin:10px 0; color: inherit;'>",
                    "<h4 style='color:#ff9800; margin-top:0;'> High Missing Data Rate</h4>",
                    "<p><strong>Warning:</strong> ", round(missing_pct, 1), "% of subjects have incomplete measurements.</p>",
                    "<p>Paired analysis will only use the ", complete_cases, " subjects with complete data.</p>",
                    "<p>Consider investigating why so much data is missing.</p>",
                    "</div>"
                )
                # Route it through the accumulator like every other message.
                # The direct setContent() here was overwritten moments later by
                # .accumulateMessage(), which rebuilds the panel from
                # private$.messages - so this warning never reached the user.
                private$.accumulateDataMessage(warning_msg)
            }

            # Validate data quality before processing
            # Note: .validateDataQuality calls .accumulateMessage directly, maybe update it too?
            # For now, data quality messages are less critical to cache strictly or should be cached too.
            # Ideally .validateDataQuality should use .accumulateDataMessage logic if passed.
            private$.validateDataQuality(mydata, vars)
            
            # Remove NA values once. naOmit() drops NA and NaN but NOT Inf, so
            # an infinite measurement used to survive into the test: the plot
            # rendered "t(77) = NA, p = NA" while the panel reassured the user
            # that all 78 subjects had been retained. Count non-finite values
            # separately - they signal a data-entry or divide-by-zero problem
            # rather than an ordinary missing observation.
            n_nonfinite <- sum(vapply(vars, function(v) {
                x <- jmvcore::toNumeric(mydata[[v]])
                sum(!is.na(x) & !is.finite(x))
            }, numeric(1)))
            finite_rows <- Reduce(`&`, lapply(vars, function(v) {
                x <- jmvcore::toNumeric(mydata[[v]])
                is.finite(x)
            }))
            subject_ids <- subject_ids[finite_rows]
            mydata <- mydata[finite_rows, , drop = FALSE]

            # Report N retained
            final_n <- nrow(mydata)
            dropped_n <- n_rows - final_n

            if (dropped_n > 0) {
                 private$.accumulateDataInfoMessage(
                    glue::glue(.("<br><strong>Data Processing:</strong> {final_n} subjects retained. {dropped_n} incomplete cases removed.<br>"))
                )
                 if (n_nonfinite > 0)
                     private$.accumulateDataMessage(
                        glue::glue(.("<br> <strong>Non-finite values:</strong> {n_nonfinite} infinite or undefined measurement(s) were treated as missing. Check the source data for division by zero or out-of-range entries.<br>"))
                    )
            } else {
                 private$.accumulateDataInfoMessage(
                    glue::glue(.("<br><strong>Data Processing:</strong> All {final_n} subjects retained (complete data).<br>"))
                )
            }
            
            if (nrow(mydata) == 0) {
                private$.accumulateDataMessage(
                    .("<br> No complete observations after removing missing values<br>")
                )
                private$.prepared_data <- NULL
                return(NULL)
            }
            
            # Checkpoint before expensive data transformation
            private$.checkpoint()

            # Perform pivot_longer transformation once using the RAW variable
            # names. Passing raw column names (via unname() to avoid the
            # "Can't rename variables" error from a named vector) keeps
            # data access correct for names with spaces/special characters.
            long_data <- tidyr::pivot_longer(
                mydata,
                cols = unname(vars),
                names_to = "measurement",
                values_to = "value"
            )

            # Preserve measurement ordering for display
            long_data$rowid <- rep(subject_ids, each = length(vars))
            long_data$measurement <- factor(long_data$measurement, levels = vars)
            
            private$.prepared_data <- long_data
            private$.data_hash <- current_hash
            
            return(private$.prepared_data)
        },
        
        .prepareOptions = function(force_refresh = FALSE) {
            # Checkpoint before options processing
            private$.checkpoint(flush = FALSE)
            
            # Create robust hash of current options to detect changes
            current_options_hash <- digest::digest(list(
                typestatistics = self$options$typestatistics,
                pairwisecomparisons = self$options$pairwisecomparisons,
                pairwisedisplay = self$options$pairwisedisplay,
                padjustmethod = self$options$padjustmethod,
                effsizetype = self$options$effsizetype,
                centralityplotting = self$options$centralityplotting,
                centralitytype = self$options$centralitytype,
                pointpath = self$options$pointpath,
                centralitypath = self$options$centralitypath,
                violin = self$options$violin,
                boxplot = self$options$boxplot,
                point = self$options$point,
                titles = list(self$options$mytitle, self$options$xtitle, self$options$ytitle),
                display = list(self$options$resultssubtitle, self$options$originaltheme),
                advanced = list(self$options$bfmessage, self$options$conflevel, self$options$k, self$options$seed)
            ), algo = "md5")
            
            # Only reprocess if options have changed or forced refresh
            if (!is.null(private$.prepared_options) && 
                private$.options_hash == current_options_hash && 
                !force_refresh) {
                return(private$.prepared_options)
            }
            
            # Process options directly (no formula construction needed for simple strings)
            typestatistics <- self$options$typestatistics
            pairwisedisplay <- self$options$pairwisedisplay
            padjustmethod <- self$options$padjustmethod
            
            # Process titles once
            mytitle <- self$options$mytitle
            xtitle <- if (self$options$xtitle == '') NULL else self$options$xtitle
            ytitle <- if (self$options$ytitle == '') NULL else self$options$ytitle
            
            # Process plot component arguments once
            violinargs <- if (self$options$violin) {
                list(width = 0.5, alpha = 0.2, na.rm = TRUE)
            } else {
                list(width = 0)
            }
            
            # Updated API parameter names for current ggstatsplot
            boxplotargs <- if (self$options$boxplot) {
                list(width = 0.2, alpha = 0.5, na.rm = TRUE)
            } else {
                list(width = 0)
            }
            
            pointargs <- if (self$options$point) {
                list(size = 3, alpha = 0.5, na.rm = TRUE)
            } else {
                list(alpha = 0)
            }
            
            pointpathargs <- if (self$options$pointpath) {
                list(alpha = 0.5, linetype = "dashed")
            } else {
                list(alpha = 0)
            }
            
            centralitypointargs <- if (self$options$centralityplotting) {
                list(size = 5, color = "darkred")
            } else {
                list(size = 0)
            }
            
            centralitypathargs <- if (self$options$centralitypath && self$options$centralityplotting) {
                list(linewidth = 1, color = "red", alpha = 0.5)
            } else {
                list(linewidth = 0)
            }
            
            private$.prepared_options <- list(
                typestatistics = typestatistics,
                pairwisecomparisons = self$options$pairwisecomparisons,
                pairwisedisplay = pairwisedisplay,
                padjustmethod = padjustmethod,
                pointpath = self$options$pointpath,
                mytitle = mytitle,
                xtitle = xtitle,
                ytitle = ytitle,
                effsizetype = self$options$effsizetype,
                centralityplotting = self$options$centralityplotting,
                centralitytype = self$options$centralitytype,
                centralitypath = self$options$centralitypath,
                violinargs = violinargs,
                boxplotargs = boxplotargs,
                pointargs = pointargs,
                pointpathargs = pointpathargs,
                centralitypointargs = centralitypointargs,
                centralitypathargs = centralitypathargs,
                originaltheme = self$options$originaltheme,
                resultssubtitle = self$options$resultssubtitle,
                # Add missing parameters with current API names
                bfmessage = if (!is.null(self$options$bfmessage)) self$options$bfmessage else TRUE,
                conflevel = if (!is.null(self$options$conflevel)) self$options$conflevel else 0.95,
                digits = if (!is.null(self$options$k)) self$options$k else 2
            )
            
            private$.options_hash <- current_options_hash
            
            return(private$.prepared_options)
        },
        
        # Clinical interpretation helper
        .generateClinicalInterpretation = function(num_measurements, test_type) {
            interpretation_parts <- list()
            
            # Test explanation
            test_explanation <- switch(test_type,
                "parametric" = if (num_measurements == 2) .("The paired t-test compares the mean within-subject difference with zero; normality concerns the differences.") else .("Repeated-measures ANOVA compares means across conditions, accounting for subjects and the sphericity correction."),
                "nonparametric" = if (num_measurements == 2) .("The Wilcoxon signed-rank test assesses paired differences and assumes a symmetric difference distribution for a location-shift interpretation.") else .("The Friedman test compares within-subject ranks across conditions. A median-shift interpretation requires comparable distribution shapes."),
                "robust" = .("Robust test uses trimmed means, reducing influence of outliers common in clinical measurements."),
                "bayes" = .("Bayesian analysis provides evidence for/against differences, useful when traditional p-values are inconclusive."),
                .("Statistical test compares measurements across time points.")
            )
            
            # Sample interpretation
            clinical_context <- sprintf(
                .("This analysis compares %d measurements from the same subjects. Useful for: biomarker tracking, treatment response monitoring, disease progression assessment."),
                num_measurements
            )
            
            # What to look for
            guidance <- .("<strong>What to look for:</strong><br>\u2022 A small p-value is evidence against the null under the model assumptions; it does not prove a treatment effect<br>\u2022 Compare effect estimates and uncertainty with a prespecified clinically important difference<br>\u2022 Individual trajectories reveal response patterns<br>\u2022 Outliers may indicate treatment non-responders or measurement errors")
            
            interpretation_parts <- list(
                paste0("<div style='background-color: rgba(138, 155, 172, 0.06);padding:15px;margin:10px 0;border-left:4px solid #007bff; color: inherit;'>"),
                paste0("<h4 style='margin-top:0;color:#007bff;'>", .("Clinical Context"), "</h4>"),
                paste0("<p>", clinical_context, "</p>"),
                paste0("<p><strong>", .("Test Used:"), "</strong> ", test_explanation, "</p>"),
                guidance,
                "</div>"
            )
            
            return(paste(interpretation_parts, collapse = ""))
        },
        
        # Generate analysis summary
        .generateAnalysisSummary = function(opts, num_measurements) {
            summary_parts <- list()
            
            # Analysis overview
            analysis_type <- private$.testLabel(opts$typestatistics, num_measurements)
            
            summary_header <- sprintf(
                .("<strong>Analysis:</strong> %s with %d measurements per subject"),
                analysis_type, num_measurements
            )
            
            # Configuration summary
            config_items <- character()
            if (opts$pairwisecomparisons) {
                config_items <- c(config_items, .("Pairwise comparisons enabled"))
            }
            if (opts$centralityplotting) {
                config_items <- c(config_items, .("Central tendency displayed"))
            }
            if (opts$pointpath) {
                config_items <- c(config_items, .("Individual trajectories shown"))
            }
            
            if (length(config_items) > 0) {
                config_summary <- paste0("<br><strong>", .("Configuration:"), "</strong><br>", 
                                       paste(config_items, collapse = "<br>"))
            } else {
                config_summary <- ""
            }
            
            summary_parts <- list(
                paste0("<div style='background-color: rgba(33, 152, 33, 0.07);padding:10px;border:1px solid #28a745; color: inherit;'>"),
                summary_header,
                config_summary,
                "</div>"
            )
            
            return(paste(summary_parts, collapse = ""))
        },

        # Generate explanations ----
        .generateExplanations = function() {
            # One complete sentence per .() call - a translator needs the whole
            # sentence, and .() must not contain newlines.
            self$results$explanations$setContent(paste0(
                "<h3>", .("Explanations"), "</h3>",
                "<p>", .("This analysis compares repeated measurements taken from the same subjects (a within-subjects design)."),
                " ", .("It tests whether the measurements differ across time points or conditions."), "</p>",
                "<p><strong>", .("Violin plots:"), "</strong> ",
                .("These show the distribution of the data; wider sections contain more observations."),
                "<br><strong>", .("Box plots:"), "</strong> ",
                .("These show the median (middle line) and the quartiles (box edges)."), "</p>",
                "<p><strong>", .("Statistical tests:"), "</strong></p>",
                "<ul>",
                "<li><strong>", .("Parametric:"), "</strong> ",
                .("A paired t-test for two measurements, or a repeated-measures ANOVA with a Greenhouse-Geisser sphericity correction for three or more. This assumes the within-subject differences are approximately normal."), "</li>",
                "<li><strong>", .("Nonparametric:"), "</strong> ",
                .("A Wilcoxon signed-rank test for two measurements, or a Friedman test for three or more. These make no distributional assumption."), "</li>",
                "<li><strong>", .("Robust:"), "</strong> ",
                .("A trimmed-means test that resists outliers, which are common in laboratory values."), "</li>",
                "<li><strong>", .("Bayesian:"), "</strong> ",
                .("This reports a Bayes factor, quantifying the evidence for and against the null hypothesis."), "</li>",
                "</ul>",
                "<p><strong>", .("Missing data:"), "</strong> ",
                .("Only subjects with a value for every selected measurement are analyzed, because a paired comparison needs complete records."), "</p>",
                "<p><strong>", .("Note on the Wilcoxon p-value:"), "</strong> ",
                .("The signed-rank p-value is computed from the normal approximation with a continuity correction, not from the exact permutation distribution that stats::wilcox.test uses by default, so it may differ from base R for small samples without ties."), "</p>"
            ))
        },

        # run ----
        .run = function() {
            # The explanations panel holds STATIC method text and its visibility
            # is governed declaratively by `visible: (showExplanations)` in
            # .r.yaml. Populate it unconditionally - when it was filled only in
            # the variables-selected branch, the welcome screen showed an
            # "Explanations" heading with an empty body (showExplanations
            # defaults to true).
            private$.generateExplanations()

            ## Initial Message ----
            if ( is.null(self$options$dep1) || is.null(self$options$dep2)) {

                ### todo ----

                # Welcome / getting-started message
                todo <- private$.welcomeMessage()

                # Ensure todo is visible and set content
                self$results$todo$setVisible(visible = TRUE)
                self$results$todo$setContent(todo)
                
                # Hide plot output when no variables selected
                self$results$plot$setVisible(visible = FALSE)
                
                # Hide other outputs as well
                self$results$interpretation$setVisible(visible = FALSE)
                if (!is.null(self$results$summary)) {
                    self$results$summary$setVisible(visible = FALSE)
                }
                if (!is.null(self$results$warnings)) {
                    self$results$warnings$setVisible(visible = FALSE)
                }

                return()

            } else {
                # Clear messages for actual analysis
                private$.resetMessages()
                
                # Check messages from presets and data quality each run
                private$.applyClinicalPresets()
                # Ensure data is prepared (and N messages generated).
                # NULL means a blocking condition was hit (fewer than 3 complete
                # cases, no rows left after cleaning, missing columns); the
                # reason has been written to the Messages panel.
                prepared <- private$.prepareData()

                # Probe the subtitle takeover HERE, not in .plot(): .run() is the
                # only place that composes the warnings HTML, so a flag set later
                # by .plot() would never be rendered. When the takeover stands
                # down, 'Effect size type' and 'Decimal places' do not reach the
                # reported statistic, which the user should be told rather than
                # left to discover.
                private$.subtitleFallback <- NULL
                local({
                    ld <- private$.prepareData(emit_messages = FALSE)
                    if (!is.null(ld)) {
                        opts_now <- private$.prepareOptions()
                        invisible(private$.subtitleExpr(
                            ld, opts_now, length(unique(ld$measurement))))
                    }
                })
                if (!is.null(private$.subtitleFallback))
                    private$.accumulateMessage(sprintf(
                        .("<br> <strong>Note:</strong> the plot subtitle uses the package default (%s), so 'Effect size type' and 'Decimal places' do not affect the reported statistic.<br>"),
                        private$.safeHtmlOutput(private$.subtitleFallback)))
                
                # Make all outputs visible when variables are selected
                self$results$todo$setVisible(visible = TRUE)
                self$results$plot$setVisible(visible = TRUE)
                self$results$interpretation$setVisible(visible = TRUE)
                if (!is.null(self$results$summary)) {
                    self$results$summary$setVisible(visible = TRUE)
                }
                # Visibility is decided at the end of .run(), once we know
                # whether any warning-grade message was actually raised.
                
                # Generate clinical guidance for active analysis
                vars <- c(self$options$dep1, self$options$dep2, 
                         self$options$dep3, self$options$dep4)
                num_measurements <- sum(!sapply(vars, is.null))

                # The effect-size selector offers four choices, but eta and omega
                # are ANOVA-only quantities that statsExpressions' two-group test
                # does not accept, so with TWO measurements they are coerced onto
                # biased/unbiased (see .computeSubtitleExpr). Verified: at n = 40,
                # 'eta' and 'omega' return values identical to 'biased' (Cohen's
                # d_z = 1.27052) and 'unbiased' (Hedges' g_z = 1.24591). Say so,
                # rather than letting the user believe they selected partial
                # eta-squared and silently receive Cohen's d.
                if (isTRUE(self$options$resultssubtitle) &&
                    num_measurements <= 2 &&
                    self$options$effsizetype %in% c("eta", "omega")) {
                    private$.accumulateMessage(sprintf(
                        .("<br><strong>Note:</strong> with two measurements the comparison is a paired t-test, for which partial eta-squared and omega-squared are not defined; '%s' has been reported as %s instead.<br>"),
                        private$.safeHtmlOutput(self$options$effsizetype),
                        if (identical(self$options$effsizetype, "eta"))
                            .("Cohen's d") else .("Hedges' g")))
                }

                
                # Generate clinical interpretation with error protection
                tryCatch({
                    clinical_interp <- private$.generateClinicalInterpretation(
                        num_measurements, self$options$typestatistics
                    )
                    self$results$interpretation$setContent(clinical_interp)
                }, error = function(e) {
                    self$results$interpretation$setContent(.("<br>Clinical interpretation temporarily unavailable<br>"))
                })
                
                # Generate analysis summary with error protection
                tryCatch({
                    opts <- private$.prepareOptions()
                    analysis_summary <- private$.generateAnalysisSummary(opts, num_measurements)
                    # Procedural progress notes ride along under the summary
                    # rather than filling the warning panel.
                    self$results$summary$setContent(
                        paste0(analysis_summary, private$.renderInfoBlock()))
                }, error = function(e) {
                    self$results$summary$setContent(.("<br>Analysis summary temporarily unavailable<br>"))
                })

                ### todo ----
                # Do not announce readiness when the data never made it through
                # preparation - the plot stays blank and the only explanation
                # sits in the Messages panel, so "Ready for analysis" read as a
                # contradiction of the warning directly above it.
                todo <- if (is.null(prepared))
                    .("<br>Analysis cannot proceed with the current data. See the Messages panel for the reason.<br><hr>")
                else
                    sprintf(.("<br> Ready for analysis: Violin Plot comparing %d repeated measurements.<br><hr>"),
                            num_measurements)

                self$results$todo$setContent(todo)

                if (nrow(self$data) == 0)
                    jmvcore::reject(.("Data contains no (complete) rows"))

                # Show the Messages panel only when something needs acting on.
                if (!is.null(self$results$warnings))
                    self$results$warnings$setVisible(
                        visible = length(private$.messages) > 0)

            }
        }


        # the plot function ----
        ,
        .plot = function(image, ggtheme, theme, ...) {
            # Use shared validation helper ----
            if (!private$.validateInputs())
                return()

            # Use prepared data and options ----
            long_data <- private$.prepareData(emit_messages = FALSE)
            opts <- private$.prepareOptions()
            
            if (is.null(long_data)) {
                return()
            }

            # Additional validation
            if (nrow(long_data) == 0) {
                warning_msg <- .("<br>No complete data rows available after removing missing values.<br>Please check your data for missing values in the selected variables.<br><hr>")
                self$results$todo$setContent(warning_msg)
                return()
            }


            # Checkpoint before expensive plot creation
            private$.checkpoint()

            # Create plot using optimized data and options ----
            # Honour the effect-size selector (see .subtitleExpr): ggstatsplot
            # 1.0.0 no longer accepts effsize.type, so compute the subtitle here.
            # The Bayesian (BayesFactor MCMC) and robust (bootstrap) paths in
            # ggstatsplot sample, so the same analysis rendered twice reported
            # different numbers. Seed them; withr restores the caller's stream.
            if (opts$typestatistics %in% c("bayes", "robust"))
                withr::local_seed(self$options$seed)

            n_meas <- length(unique(long_data$measurement))
            sub_expr <- private$.subtitleExpr(long_data, opts, n_meas)

            tryCatch({
                plot <- ggstatsplot::ggwithinstats(
                    data = long_data,
                    x = measurement,
                    y = value,
                    # ggwithinstats is always within-subjects; there is no
                    # `paired` formal. Pass the subject identifier explicitly
                    # via subject.id so pairing does not rely on incidental
                    # row order (the previous `id = "rowid"` was silently
                    # dropped into ...).
                    subject.id = "rowid",
                    title = opts$mytitle,
                    xlab = opts$xtitle,
                    ylab = opts$ytitle,
                    type = opts$typestatistics,
                    # `pairwise.comparisons` was removed in ggstatsplot 1.0.0
                    # and silently swallowed by `...`, so unticking the box left
                    # the brackets on the plot. "none" is the surviving control.
                    pairwise.display = private$.pairwiseDisplay(opts),
                    p.adjust.method = opts$padjustmethod,
                    # effsize.type was likewise removed; the selector is
                    # honoured through the subtitle we attach below instead.
                    centrality.plotting = opts$centralityplotting,
                    centrality.type = opts$centralitytype,
                    point.path = opts$pointpath,
                    centrality.path = opts$centralitypath,
                    violin.args = opts$violinargs,
                    boxplot.args = opts$boxplotargs,
                    point.args = opts$pointargs,
                    point.path.args = opts$pointpathargs,
                    centrality.point.args = opts$centralitypointargs,
                    centrality.path.args = opts$centralitypathargs,
                    # When we supply our own subtitle (below) ggstatsplot must
                    # not also compute one.
                    results.subtitle = if (is.null(sub_expr)) opts$resultssubtitle else FALSE,
                    # Updated parameter names for current API
                    bf.message = opts$bfmessage,
                    conf.level = opts$conflevel,
                    digits = opts$digits
                )

                # Attach the subtitle to the FINISHED plot. It is a plotmath
                # language object: passing it through the call would make R try
                # to evaluate italic()/widehat() as ordinary functions.
                if (!is.null(sub_expr))
                    plot <- plot + ggplot2::labs(subtitle = sub_expr)

                # ggwithinstats draws point.path only for two measurements, so
                # the "Show individual trajectories" checkbox silently did
                # nothing with 3 or 4 - exactly the case where following a
                # subject across time matters most. Draw the paths ourselves.
                if (isTRUE(opts$pointpath) && n_meas > 2)
                    plot <- plot + ggplot2::geom_path(
                        ggplot2::aes(group = .data[["rowid"]]),
                        alpha = 0.4, linewidth = 0.3, colour = "grey40")

                # Checkpoint before theme application
                private$.checkpoint()
                
                # Apply theme
                if (!opts$originaltheme) {
                    plot <- plot + ggtheme
                } else {
                    plot <- plot + ggstatsplot::theme_ggstatsplot()
                }

                if ((isTRUE(opts$resultssubtitle) && statsSeedMatters(opts$typestatistics, "within", n_meas)) ||
                    captionSeedMatters(opts$typestatistics, "within", n_meas, opts$bfmessage))
                    plot <- addSeedCaption(plot, self, self$options$seed)

                # Print Plot ----
                print(plot)
                TRUE
                
            }, error = function(e) {
                # htmlEscape e$message - ggwithinstats errors may include user column-name fragments
                error_msg <- paste0(
                    "<br>",
                    .fmt(
                        .("The within-subjects plot could not be created: {error}"),
                        error = private$.safeHtmlOutput(e$message)),
                    .("<br><br>Please check that:"),
                    .("<br>\u2022 All measurement variables contain numeric values"),
                    .("<br>\u2022 Data has at least 2 complete rows"),
                    .("<br>\u2022 Variables have sufficient variance for statistical tests"),
                    .("<br>\u2022 No extreme outliers that might affect analysis"),
                    .("<br><hr>")
                )
                self$results$todo$setContent(error_msg)
            })

        }

        ,
        .plotGGPubr = function(image, ...) {
            # Validate inputs
            if (is.null(self$options$dep1) || is.null(self$options$dep2))
                return()

            # Skip if ggpubr plot not requested
            if (!self$options$addGGPubrPlot)
                return()

            tryCatch({
                # Prepare data - convert wide to long format
                deps <- c(self$options$dep1, self$options$dep2)
                if (!is.null(self$options$dep3)) deps <- c(deps, self$options$dep3)
                if (!is.null(self$options$dep4)) deps <- c(deps, self$options$dep4)

                # CRITICAL FIX: Paired analysis requires listwise deletion.
                # Only keep subjects with data for ALL selected measurements.
                # Index with RAW variable names (composeTerm/backtick-quoted
                # names break data.frame column access for names with spaces).
                mydata <- self$data
                mydata <- mydata[, deps, drop = FALSE]
                # is.finite(), matching .prepareData(): naOmit() drops NA and NaN
                # but NOT Inf. Without this the companion panel kept infinite
                # rows the primary analysis had already excluded, so the two
                # figures were drawn from different subjects.
                finite_rows <- Reduce(`&`, lapply(deps, function(v)
                    is.finite(jmvcore::toNumeric(mydata[[v]]))))
                mydata <- mydata[finite_rows, , drop = FALSE]
                mydata <- jmvcore::naOmit(mydata)

                # Check for empty data after filtering
                if (nrow(mydata) == 0) {
                     return() # Should be handled by main validation
                }

                # Create subject ID for paired analysis
                subject_ids <- seq_len(nrow(mydata))

                # Convert to long format using raw variable names
                long_data <- data.frame()
                for (i in seq_along(deps)) {
                    temp <- data.frame(
                        Subject_ID = subject_ids,
                        Measurement = deps[i],
                        Value = mydata[[deps[i]]]
                    )
                    long_data <- rbind(long_data, temp)
                }

                # Start Plot Construction
                palette <- self$options$ggpubrPalette

                # Create plot based on type
                if (self$options$ggpubrPlotType == "paired") {
                    # Paired plot with connecting lines
                    # `fill` (or `color` for the line plot) has to be mapped for
                    # the palette to have anything to colour. Without it every
                    # ggpubrPalette choice rendered a byte-identical figure.
                    args <- list(
                        data = long_data,
                        x = "Measurement",
                        y = "Value",
                        id = "Subject_ID",
                        fill = "Measurement",
                        palette = palette,
                        line.color = "gray",
                        line.size = 0.4,
                        label = NULL
                    )

                    if (!self$options$ggpubrShowLines) {
                        args$line.color <- NA
                    }

                    plot <- do.call(ggpubr::ggpaired, args)

                } else if (self$options$ggpubrPlotType == "boxplot") {
                    args <- list(
                        data = long_data,
                        x = "Measurement",
                        y = "Value",
                        fill = "Measurement",
                        palette = palette,
                        add = if (self$options$ggpubrAddPoints) "jitter" else NULL
                    )
                    plot <- do.call(ggpubr::ggboxplot, args)

                } else if (self$options$ggpubrPlotType == "violin") {
                    args <- list(
                        data = long_data,
                        x = "Measurement",
                        y = "Value",
                        fill = "Measurement",
                        palette = palette,
                        add = if (self$options$ggpubrAddPoints) "jitter" else NULL
                    )
                    plot <- do.call(ggpubr::ggviolin, args)

                } else if (self$options$ggpubrPlotType == "line") {
                    # ggpubr's `add = "mean_se"` builds
                    # stat_summary(fun.data = "mean_se_") and resolves that name
                    # from the SEARCH PATH at draw time. It therefore works in a
                    # session that has done library(ggpubr) and fails here and in
                    # jamovi, where ggpubr is only namespace-loaded:
                    #   Error in stat_summary(): object 'mean_se_' of mode
                    #   'function' was not found
                    # The failure surfaces in ggplot_build(), not at construction,
                    # so a "did print() error?" check reports success while the
                    # panel renders nothing. Summarise here instead, so the layer
                    # carries a real function rather than a name to look up.
                    #
                    # No colour aesthetic is mapped on purpose: this plot type
                    # draws a SINGLE mean trajectory, so a categorical palette
                    # has nothing to colour. The option description says so.
                    agg <- stats::aggregate(
                        Value ~ Measurement, data = long_data,
                        FUN = function(v) c(mean = mean(v),
                                            se = stats::sd(v) / sqrt(length(v))))
                    agg <- data.frame(
                        Measurement = agg$Measurement,
                        Value = agg$Value[, "mean"],
                        se    = agg$Value[, "se"])
                    agg$Measurement <- factor(agg$Measurement, levels = deps)

                    plot <- ggpubr::ggline(
                        agg, x = "Measurement", y = "Value",
                        group = 1, palette = palette) +
                        ggplot2::geom_errorbar(
                            ggplot2::aes(ymin = .data[["Value"]] - .data[["se"]],
                                         ymax = .data[["Value"]] + .data[["se"]]),
                            width = 0.1)
                }

                # Add statistical comparisons
                if (self$options$ggpubrAddStats && self$options$ggpubrPlotType != "line") {
                    # ggpubr::stat_compare_means can only express the tests base R
                    # exposes (t.test / wilcox.test), on TWO groups. It has no
                    # robust or Bayesian test and no paired omnibus test. Use it
                    # ONLY where it runs exactly the test the user selected;
                    # otherwise annotate with the p-value from the same engine the
                    # main figure uses, so the companion can never contradict it.
                    ggpubr_method <- if (length(deps) == 2)
                        switch(self$options$typestatistics,
                               "parametric"    = "t.test",
                               "nonparametric" = "wilcox.test",
                               NULL)
                    else
                        NULL

                    if (!is.null(ggpubr_method)) {
                        plot <- plot + ggpubr::stat_compare_means(
                            method = ggpubr_method,
                            paired = TRUE,
                            label = "p.signif"
                        )
                    } else {
                        # Pairwise t.test/wilcox.test cannot compare >2 groups and
                        # would error (previously swallowed by the empty handler).
                        # Use an omnibus test for a single global p-value.
                        # ggpubr::stat_compare_means has NO paired omnibus test.
                        # method = "anova" / "kruskal.test" run BETWEEN-subjects
                        # tests, which throw away the subject effect this whole
                        # analysis exists to control for. On a 40-subject example
                        # that printed "Anova, p = 0.13" (exactly
                        # stats::aov(y ~ time), pairing discarded) directly
                        # beneath a main panel reporting the correct
                        # F_Fisher(1.76, 68.5) = 14.26, p = 1.61e-05 - two
                        # p-values ~8000x apart in one output window.
                        #
                        # Annotate the CORRECT p-value instead, computed by the
                        # same engine the main figure uses. Reached for 3+
                        # measurements (no paired omnibus test in ggpubr) and for
                        # the robust / Bayesian choices at any number of
                        # measurements. Previously "robust" silently fell back to
                        # a paired t-test: on a 30-subject example with outliers -
                        # exactly why a user picks robust - the main panel showed
                        # Yuen p = 0.025 (*) while this companion printed t-test
                        # p = 0.35 (ns), two contradictory verdicts in one window.
                        stat_fn <- if (length(deps) > 2)
                            statsExpressions::oneway_anova
                        else
                            statsExpressions::two_sample_test

                        rm_res <- tryCatch(
                            rlang::inject(stat_fn(
                                data       = transform(long_data,
                                                       .m = factor(Measurement, levels = deps),
                                                       .s = factor(Subject_ID)),
                                x          = !!rlang::sym(".m"),
                                y          = !!rlang::sym("Value"),
                                subject.id = !!rlang::sym(".s"),
                                paired     = TRUE,
                                type       = self$options$typestatistics,
                                digits     = self$options$k,
                                conf.level = self$options$conflevel)),
                            error = function(e) NULL)

                        # as.data.frame first: `$` on an absent tibble column
                        # warns, and the Bayesian result carries no p.value.
                        if (!is.null(rm_res)) rm_res <- as.data.frame(rm_res)

                        if (!is.null(rm_res) && "p.value" %in% names(rm_res) &&
                            is.finite(rm_res$p.value[1])) {
                            plot <- plot + ggplot2::labs(subtitle = sprintf(
                                .("%s: p = %s (n = %d subjects)"),
                                private$.testLabel(self$options$typestatistics, length(deps)),
                                format.pval(rm_res$p.value[1], digits = 3, eps = 1e-4),
                                length(unique(long_data$Subject_ID))))
                        } else {
                            plot <- plot + ggplot2::labs(subtitle = sprintf(
                                .("%s - see the main figure for the test statistic"),
                                private$.testLabel(self$options$typestatistics, length(deps))))
                        }
                    }
                }

                # Apply theme. The subtitle is set here only if nothing more
                # informative was attached above - this labs() call used to be
                # unconditional and silently discarded the repeated-measures
                # statistic written into the subtitle a few lines earlier.
                plot <- plot + ggpubr::theme_pubr()
                if (is.null(plot$labels$subtitle))
                    plot <- plot + ggplot2::labs(subtitle = .("Descriptive Plot (ggpubr)"))

                print(plot)
                TRUE

            }, error = function(e) {
                # Surface the (html-escaped) error instead of failing silently.
                # ggpubr messages may embed user column-name fragments.
                error_msg <- paste0(
                    "<br>",
                    .fmt(
                        .("The ggpubr plot could not be created: {error}"),
                        error = private$.safeHtmlOutput(e$message)),
                    .("<br>The primary within-subjects plot above is unaffected.<br><hr>")
                )
                self$results$todo$setContent(error_msg)
            })
        }

    ), # End of private list
    public = list(
        #' @description
        #' Generate R source code for Within-Groups Statistics analysis
        #' @return Character string with R syntax for reproducible analysis
        asSource = function() {
            dep1 <- self$options$dep1
            dep2 <- self$options$dep2

            if (is.null(dep1) || is.null(dep2))
                return('')

            # Build the argument list in option-declaration order.
            #
            # Every variable-name option (dep1, dep2, dep3, dep4) is emitted as a
            # deparse()'d string literal. deparse() produces valid, fully-escaped
            # R for names containing spaces, quotes or backslashes (e.g.
            # `Tumor Grade`); jmvcore's default sourcify would emit these as bare,
            # unquoted symbols and yield invalid syntax. Detecting OptionVariable
            # by class (rather than by name) means any variable option added later
            # is escaped automatically.
            #
            # dep1..dep4 are NOT re-emitted through private$.asArgs() - doing so
            # previously duplicated the dep variables in the generated syntax (the
            # "double variables" bug). All non-variable options keep jmvcore's
            # per-option sourcify so formatting stays consistent with jamovi.
            args <- character(0)
            for (option in private$.options$options) {
                if (option$name == 'data')
                    next
                if (inherits(option, 'OptionVariable') || inherits(option, 'OptionVariables')) {
                    val <- option$value
                    if (!is.null(val))
                        args <- c(args, paste0(option$name, ' = ',
                                               paste0(deparse(val), collapse = '')))
                } else {
                    as <- private$.sourcifyOption(option)
                    if (!identical(as, ''))
                        args <- c(args, as)
                }
            }

            # Get package name dynamically
            pkg_name <- utils::packageName()
            if (is.null(pkg_name)) pkg_name <- "ClinicoPath"  # fallback

            # Build complete function call
            paste0(pkg_name, '::jjwithinstats(\n    data = data,\n    ',
                   paste(args, collapse = ',\n    '), ')')
        }
    ) # End of public list
)
