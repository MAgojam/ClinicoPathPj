#' @title Pie Charts
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @importFrom digest digest
#' @importFrom rlang sym
#' @importFrom glue glue
#'
#' @return An \code{R6} class generator object for the \code{jjpiestatsClass} backend; used internally by the jamovi analysis wrapper and not called directly.

jjpiestatsClass <- if (requireNamespace('jmvcore')) R6::R6Class(
    "jjpiestatsClass",
    inherit = jjpiestatsBase,
    private = list(

        # Cache for processed data and options to avoid redundant computation
        .processedData = NULL,
        .data_hash = NULL,
        .validation_passed = FALSE,
        .plotTheme = NULL,

        # Memoized Fisher's-exact decision, keyed on the same data+option hash
        # as .processedData so the chi-square assumption check (an independent
        # chisq.test) runs once per data/option state instead of once per plot.
        .fisherDecision = NULL,
        .fisherDecisionHash = NULL,

        # Notice collection helpers. A single Preformatted (plain-text) output item:
        # avoids BOTH the jmvcore::Notice serialization error from
        # self$results$insert(999, Notice) AND any HTML in notices (project convention:
        # notice content must be plain text). ====
        .noticeList = list(),

        .addNotice = function(type, title, content) {
            # De-duplicate: render functions may re-run without .run() (e.g. on a
            # plot resize), which would otherwise append the same notice again.
            already <- vapply(private$.noticeList, function(n) {
                identical(n$type, type) &&
                    identical(n$title, title) &&
                    identical(n$content, content)
            }, logical(1))
            if (!any(already)) {
                private$.noticeList[[length(private$.noticeList) + 1]] <- list(
                    type = type,
                    title = title,
                    content = content
                )
            }
            # Render immediately so early-return validation aborts still display the notice
            private$.renderNotices()
        },

        .renderNotices = function() {
            if (length(private$.noticeList) == 0) {
                self$results$notices$setContent("")
                return()
            }

            # Plain text only - notices avoid HTML by project convention; the Preformatted
            # output item renders this literally (no markup, no injection surface).
            blocks <- vapply(private$.noticeList, function(notice) {
                prefix <- switch(notice$type,
                    ERROR          = "ERROR: ",
                    STRONG_WARNING = "WARNING: ",
                    WARNING        = "WARNING: ",
                    "")
                paste0(prefix, notice$title, "\n", notice$content)
            }, character(1))

            self$results$notices$setContent(paste(blocks, collapse = "\n\n"))
        },

        # init ----

        .init = function() {

            self$results$plot1$setSize(650, 450)

            self$results$plot2$setSize(650, 450)


            if (!is.null(self$options$group) && !is.null(self$options$grvar)) {

                mydata <- self$data

                grvar <-  self$options$grvar

                num_levels <- nlevels(
                    as.factor(mydata[[grvar]])
                )

                group <-  self$options$group

                num_levels_group <- nlevels(
                    as.factor(mydata[[group]])
                )

                # self$results$plot3$setSize((num_levels + num_levels_group) * 600, 450)

                self$results$plot4$setSize((num_levels + num_levels_group) * 600, 450)

            }

        },

        # Clinical Enhancement Methods ----
        
        .effectiveOptionsList = function() {
            # Build a derived options list without mutating self$options
            opts <- list(
                dep = self$options$dep,
                group = self$options$group,
                grvar = self$options$grvar,
                typestatistics = self$options$typestatistics,
                counts = self$options$counts,
                raw_ratio = self$options$ratio,
                paired = self$options$paired %||% FALSE,
                label = self$options$label %||% "percentage",
                digits = self$options$digits %||% 2L,
                conflevel = self$options$conflevel %||% 0.95,
                proportiontest = self$options$proportiontest %||% FALSE,
                bfmessage = self$options$bfmessage %||% FALSE,
                messages = self$options$messages %||% FALSE,
                resultssubtitle = self$options$resultssubtitle,
                originaltheme = self$options$originaltheme,
                clinicalpreset = self$options$clinicalpreset %||% "custom"
            )

            preset <- opts$clinicalpreset
            if (!is.null(preset) && preset != "custom") {
                if (preset == "diagnostic") {
                    opts$resultssubtitle <- TRUE
                    opts$proportiontest <- TRUE
                    opts$conflevel <- 0.95
                } else if (preset == "treatment") {
                    opts$typestatistics <- "parametric"
                    opts$resultssubtitle <- TRUE
                    opts$proportiontest <- TRUE
                } else if (preset == "biomarker") {
                    opts$typestatistics <- "robust"
                    opts$resultssubtitle <- TRUE
                    opts$label <- "both"
                }
            }

            # Parse the ratio once. .parseRatio() coerces with as.numeric(), which
            # warns on non-numeric input; jamovi shows raw R warnings in the
            # undifferentiated Analysis Notes panel, so muffle them here. The
            # user-facing complaint is raised properly from .emitRunNotices(),
            # which re-derives the reason and states it in a notice.
            #
            # Assign through `[` rather than `$`: .parseRatio() returns NULL for an
            # empty or invalid ratio, and `opts$ratio <- NULL` would DELETE the
            # element, after which `opts$ratio` partial-matches the sibling
            # `raw_ratio` and yields "" instead of NULL.
            opts["ratio"] <- list(withCallingHandlers(
                private$.parseRatio(opts$raw_ratio),
                warning = function(w) invokeRestart("muffleWarning")
            ))

            opts
        },
        
        .getPlotTheme = function() {
            # Hash-based invalidation - without this, toggling `originaltheme`
            # between .run() invocations on the same R6 instance returns a stale theme.
            current_originaltheme <- isTRUE(self$options$originaltheme)
            if (is.null(private$.plotTheme) ||
                !identical(attr(private$.plotTheme, "originaltheme"), current_originaltheme)) {
                private$.plotTheme <- if (!current_originaltheme) {
                    ggplot2::theme_bw()
                } else {
                    ggstatsplot::theme_ggstatsplot()
                }
                attr(private$.plotTheme, "originaltheme") <- current_originaltheme
            }
            private$.plotTheme
        },
        
        .generateClinicalPanels = function() {
            # 'about' is always visible (r.yaml visible: true), so populate it
            # every run rather than only when 'showexplanations' is on. The old
            # early return here left the always-visible 'about' and 'report'
            # (visible: (dep)) panels empty by default, and also made the granular
            # showSummary/showAssumptions/showInterpretation toggles render empty
            # panels whenever 'showexplanations' was off. 'showexplanations' now
            # acts as a master switch that also reveals the granular panels.
            show_expl <- isTRUE(self$options$showexplanations)

            # Generate About content
            about_content <- private$.generateAboutContent()
            self$results$about$setContent(about_content)

            has_dep <- !is.null(self$options$dep)

            # Placeholder shown when a toggle is on but the outcome variable is
            # not yet selected, so an enabled panel never renders blank-but-titled.
            placeholder <- glue::glue(
                "<p><em>{msg}</em></p><hr>",
                msg = .('Select a dependent (outcome) variable to populate this panel.')
            )

            # Summary (needs the outcome variable)
            if (show_expl || isTRUE(self$options$showSummary)) {
                self$results$summary$setContent(
                    if (has_dep) private$.generateSummaryContent() else placeholder
                )
            }

            # Interpretation guidance
            if (show_expl || isTRUE(self$options$showInterpretation)) {
                self$results$interpretation$setContent(
                    if (has_dep) private$.generateInterpretationContent() else placeholder
                )
            }

            # Assumptions & warnings (works with or without a grouping variable;
            # the contingency-table checks are simply skipped when no group is set)
            if (show_expl || isTRUE(self$options$showAssumptions)) {
                self$results$assumptions$setContent(
                    if (has_dep) private$.generateAssumptionsContent() else placeholder
                )
            }

            # Copy-ready report (r.yaml gates visibility on dep, so only populate
            # when the outcome variable is present)
            if (has_dep) {
                self$results$report$setContent(private$.generateReportContent())
            }
        },
        
        .generateAboutContent = function() {
            preset_info <- switch(self$options$clinicalpreset %||% "custom",
                "diagnostic" = .('This analysis is optimized for diagnostic test evaluation, focusing on sensitivity, specificity, and predictive values.'),
                "treatment" = .('This analysis is optimized for treatment response comparison across multiple treatment groups.'), 
                "biomarker" = .('This analysis is optimized for biomarker distribution analysis with robust statistical methods.'),
                .('This analysis uses custom settings for pie chart generation with statistical testing.')
            )
            
            glue::glue(
                "<h3>{title}</h3>
                <p><strong>{what}:</strong> {description}</p>
                <p><strong>{when}:</strong> {usage}</p>
                <p><strong>{preset_label}:</strong> {preset_info}</p>
                <p><strong>{output_label}:</strong> {outputs}</p>
                <hr>",
                title = .('Pie Chart Analysis'),
                what = .('What this analysis does'),
                description = .('Generates pie charts with statistical analysis to compare categorical variables across groups. Performs chi-square tests, Fisher\'s exact tests, or other appropriate statistical tests based on your data.'),
                when = .('When to use'),
                usage = .('Use when you want to visualize proportions of categorical outcomes and test for significant differences between groups. Ideal for diagnostic test results, treatment responses, or biomarker categories.'),
                preset_label = .('Current configuration'),
                output_label = .('What you\'ll get'),
                outputs = .('Interactive pie charts with statistical test results, confidence intervals, and effect sizes. Optional grouped analysis for complex study designs.')
            )
        },
        
        .generateSummaryContent = function() {
            # Basic summary based on current selections
            dep_info <- if (!is.null(self$options$dep)) {
                paste(.('Analyzing variable:'), htmltools::htmlEscape(self$options$dep))
            } else { .('No outcome variable selected') }

            group_info <- if (!is.null(self$options$group) && self$options$group != "") {
                paste(.('Comparing across groups:'), htmltools::htmlEscape(self$options$group))
            } else { .('No grouping variable - single pie chart') }
            
            method_info <- paste(.('Statistical method:'), if (private$.effectiveOptionsList()$paired) 'McNemar' else tools::toTitleCase(private$.effectiveOptionsList()$typestatistics))
            
            glue::glue(
                "<h4>{summary_title}</h4>
                <p>\u2022 {dep_info}</p>
                <p>\u2022 {group_info}</p>
                <p>\u2022 {method_info}</p>
                <p>\u2022 {sample_info}</p>
                <hr>",
                summary_title = .('Analysis Configuration'),
                sample_info = paste(.('Sample size:'), nrow(self$data), .('input rows (before exclusions; frequencies may differ)'))
            )
        },
        
        .generateAssumptionsContent = function() {
            opts <- private$.effectiveOptionsList()
            if (isTRUE(opts$paired)) {
                pd <- private$.pairedDiscordant(self$data, self$options$dep,
                                                self$options$group, self$options$counts)
                detail <- if (!is.null(pd))
                    sprintf(.('Only %d of the %d pairs are discordant. McNemar\'s chi-square is an asymptotic test on the discordant pairs alone, so below about 25 of them it is anti-conservative. The exact binomial test on those pairs gives <b>%s</b>; quote that value.'),
                            pd$n_disc, pd$n_total, private$.fmtP(pd$p_exact))
                else
                    .('The McNemar chi-square reported by the plotting package is computed without a continuity correction, so it will not match the base R default.')
                return(paste0("<p>",
                    .('McNemar analysis requires paired categorical observations with matching category coding. Pairs must be independent of one another. An independent-samples Fisher test is not a replacement.'),
                    " ", detail, "</p>"))
            }
            if (identical(opts$typestatistics, "bayes"))
                return("<p>Bayesian contingency analysis assumes independent observations and valid case frequencies. Interpret the Bayes factor with its prior; Pearson expected-count diagnostics do not determine Bayesian validity.</p>")
            warnings_list <- c()

            # Check for small sample sizes
            if (!is.null(self$options$group) && self$options$group %in% names(self$data)) {
                tryCatch({
                    # CRITICAL FIX #4: Use weighted contingency table if counts variable present
                    counts_var <- self$options$counts
                    if (!is.null(counts_var) && counts_var != "" && counts_var %in% names(self$data)) {
                        # Weighted contingency table using xtabs
                        formula_str <- paste0(jmvcore::composeTerm(counts_var),
                                              " ~ ", jmvcore::composeTerm(self$options$dep),
                                              " + ", jmvcore::composeTerm(self$options$group))
                        contingency_table <- xtabs(jmvcore::asFormula(formula_str), data = self$data)
                    } else {
                        # Unweighted contingency table
                        contingency_table <- table(self$data[[self$options$dep]], self$data[[self$options$group]])
                    }
                    expected_counts <- suppressWarnings(chisq.test(contingency_table)$expected)
                    
                    if (any(expected_counts < 5)) {
                        # Do NOT tell the user to pick "nonparametric" to obtain a
                        # Fisher test - that option returns the identical Pearson
                        # chi-square (measured: chi2(1) = 4.47, p = 0.03 for
                        # parametric, nonparametric and robust alike, while
                        # fisher.test() on that table gives p = 0.0511, i.e. the
                        # other side of 0.05). Compute the exact test here and hand
                        # over the real number.
                        n_low <- sum(expected_counts < 5)

                        # Whether the chart subtitle was replaced with the exact
                        # test depends on the same conditions .exactSubtitle()
                        # checks. Keep this text in step with what is actually on
                        # the figure - a panel that contradicts the chart is the
                        # defect this whole fix is about.
                        swapped <- isTRUE(opts$resultssubtitle) && !is.null(private$.exactSubtitle(
                            self$data, self$options$dep, self$options$group,
                            self$options$counts, self$options$conflevel, self$options$digits))

                        # fisher.test() enumerates tables and can hang on a large
                        # sparse one; cap it and say so rather than freeze jamovi.
                        fisher_p <- if (prod(dim(contingency_table)) <= 30)
                            tryCatch(stats::fisher.test(contingency_table)$p.value,
                                     error = function(e) NA_real_)
                        else NA_real_

                        warnings_list <- c(warnings_list, paste0(
                            "",
                            sprintf(.('Chi-square is unreliable here: %d of %d expected cell counts are below 5.'),
                                    n_low, length(expected_counts)),
                            " ",
                            if (swapped)
                                .('The chart subtitle therefore reports Fisher\'s exact test instead of the chi-square.')
                            else if (!isTRUE(opts$resultssubtitle))
                                paste0("Statistical subtitles are disabled. Fisher's exact test on this table: ",
                                    if (is.finite(fisher_p)) private$.fmtP(fisher_p) else "not computed", ".")
                            else if (is.finite(fisher_p))
                                sprintf(.('The chart subtitle still reports an uncorrected Pearson chi-square - no statistic option changes that, as the plotting package offers no exact test. Fisher\'s exact test on this table gives <b>%s</b>; quote that value, not the subtitle.'),
                                        private$.fmtP(fisher_p))
                            else
                                .('The chart subtitle still reports an uncorrected Pearson chi-square. An exact test was not computed for a table of this size; consider collapsing sparse categories.')))
                    }
                    
                    if (any(contingency_table < 2)) {
                        warnings_list <- c(warnings_list,
                            paste("", .('Some categories have very few observations. Consider combining categories or collecting more data.'))
                        )
                    }
                }, error = function(e) {
                    # Silently continue if table creation fails
                })
            }
            
            # General assumptions
            assumptions <- c(
                paste("", .('Data should be categorical (factors or characters)')),
                paste("", .('Observations should be independent')),
                paste("", .('For statistical tests: adequate sample size in each category'))
            )
            
            warnings_section <- if (length(warnings_list) > 0) {
                paste0("<h5>", .('Warnings'), "</h5>\n<ul>\n",
                      paste0("<li>", warnings_list, "</li>", collapse = "\n"),
                      "\n</ul>\n")
            } else {
                paste0("<p> ", .('No issue was detected by these limited checks; study design and independence still require verification.'), "</p>\n")
            }
            
            glue::glue(
                "<h4>{assumptions_title}</h4>
                <h5>{general_title}</h5>
                <ul>
                {paste0('<li>', assumptions, '</li>', collapse = '\n')}
                </ul>
                {warnings_section}
                <hr>",
                assumptions_title = .('Statistical Assumptions & Warnings'),
                general_title = .('General Requirements')
            )
        },
        
        .generateInterpretationContent = function() {
            method_guidance <- switch(private$.effectiveOptionsList()$typestatistics,
                "parametric" = .('Chi-square test results show whether group differences are statistically significant. Look for p-values < 0.05 for significant associations. Example: \u03c7\u00b2(1) = 5.2, p = 0.023 indicates significant difference between groups.'),
                # For a contingency table, ggstatsplot computes the SAME Pearson
                # chi-square for parametric, nonparametric and robust - it offers no
                # exact test. Telling the user these buttons change the method sent
                # them to a "Fisher's exact test" that never ran.
                "nonparametric" = .('For contingency tables this option computes the same Pearson chi-square as Parametric - the plotting package provides no exact test. If expected cell counts are below 5, use the exact p-value reported in the Assumptions panel instead of the chart subtitle.'),
                "robust" = .('For contingency tables this option computes the same Pearson chi-square as Parametric. Robust estimation applies to continuous outcomes, not to counts.'),
                "bayes" = .('Bayesian analysis provides evidence for or against group differences. Bayes factors > 3 suggest evidence for differences. Example: BF\u2081\u2080 = 5.2 indicates data are 5.2 times more likely under alternative hypothesis than null.'),
                .('Statistical analysis will be performed based on your data characteristics.')
            )

            clinical_context <- switch(self$options$clinicalpreset %||% "custom",
                "diagnostic" = .('For diagnostic tests: Focus on sensitivity (true positive rate) and specificity (true negative rate). Example: Sensitivity = 85% means test correctly identifies 85 out of 100 diseased patients. Specificity = 92% means test correctly identifies 92 out of 100 healthy individuals. PPV and NPV depend on disease prevalence in your population.'),
                "treatment" = .('For treatment response: Look for significant differences between treatment arms. Example: 45% response in Treatment A vs 25% in Treatment B (p = 0.012, Cram\u00e9r\'s V = 0.31) indicates a moderate effect size. Whether a difference of this magnitude matters for patients is a judgement about the outcome, not a property of the statistic; on the count scale the same contrast is an absolute risk difference of 20 percentage points, i.e. a number needed to treat of 1/0.20 = 5.'),
                "biomarker" = .('For biomarker analysis: Examine distribution patterns across patient groups. Example: High biomarker expression in 65% of responders vs 30% in non-responders (p < 0.001, OR = 4.3, 95% CI 2.1 to 8.7) describes an association between expression and response in this sample. A cross-sectional association does not establish predictive value; that requires evaluation in an independent cohort.'),
                .('Interpret results in the context of your specific research question and clinical setting. Focus on effect sizes (Cram\u00e9r\'s V, odds ratios) alongside p-values for clinical significance assessment.')
            )

            # Effect size interpretation guide.
            #
            # The chart subtitle reports the BIAS-CORRECTED Cramer's V (Bergsma
            # 2013), which is what ggstatsplot/effectsize compute, while Cohen's
            # 0.10/0.30/0.50 landmarks were derived for the uncorrected statistic.
            # The correction shrinks V, so reading one against the other
            # under-calls the effect: measured on a 4x2 table with n = 200,
            # uncorrected V = 0.15 ("small") but corrected V = 0.08, which these
            # thresholds would dismiss as negligible. Say which one is on screen.
            effect_size_guide <- paste0(
                "<p><strong>", .('Effect Size Interpretation (Cram\u00e9r\'s V):'), "</strong></p>",
                "<ul>",
                "<li>", .('Small effect: V = 0.10 (subtle association, may require large samples to detect)'), "</li>",
                "<li>", .('Medium effect: V = 0.30 (noticeable association)'), "</li>",
                "<li>", .('Large effect: V = 0.50 (strong association)'), "</li>",
                "</ul>",
                "<p><em>", .('Note: the chart subtitle reports the bias-corrected Cram\u00e9r\'s V (Bergsma 2013), which is smaller than the classical statistic these landmarks describe - especially in small samples and larger tables. Treat the thresholds as approximate, and read the confidence interval next to V rather than the point estimate alone.'), "</em></p>"
            )

            glue::glue(
                "<h4>{interpretation_title}</h4>
                <p><strong>{method_title}:</strong> {method_guidance}</p>
                <p><strong>{clinical_title}:</strong> {clinical_context}</p>
                {effect_size_guide}
                <p><strong>{general_title}:</strong> {general_guidance}</p>
                <hr>",
                interpretation_title = .('How to Interpret Your Results'),
                method_title = .('Statistical Method'),
                clinical_title = .('Clinical Context'),
                general_title = .('General Guidance'),
                general_guidance = .('Pie charts show proportions visually - larger slices represent higher frequencies. A significance test reports how compatible the observed data are with the hypothesis of no group difference: a small p-value means data this extreme would be unusual if there were no difference. It is not the probability that the difference is due to chance, nor the probability that the null hypothesis is true, and a large p-value does not establish that the groups are the same. Report both the p-value and the effect size (Cram\u00e9r\'s V, odds ratios) for complete interpretation.')
            )
        },
        
        .generateReportContent = function() {
            # This sentence is offered as Methods text to paste into a manuscript,
            # so it must name the test that actually ran. It did not: measured on a
            # 2x2 with a low expected count, ggpiestats returns the SAME
            # uncorrected Pearson chi2(1) = 4.47, p = 0.03 for type = "parametric",
            # "nonparametric" AND "robust" - only "bayes" differs. Naming
            # "Fisher's exact test" therefore published a test that was never run,
            # and on that table Fisher gives p = 0.0511 - the other side of 0.05
            # from the number shown. statsExpressions::contingency_table() routes
            # every frequentist type to chi-square; there is no exact-test option.
            opts <- private$.effectiveOptionsList()
            method_name <- if (isTRUE(opts$paired)) {
                # statsExpressions runs mcnemar.test(correct = FALSE) while base R
                # defaults to correct = TRUE, so an unqualified "McNemar's test" does
                # not reproduce in base R. Name the correction, or the exact test
                # when that is what the chart now shows.
                if (isTRUE(opts$resultssubtitle) &&
                    !is.null(private$.exactSubtitle(self$data, opts$dep, opts$group,
                                                    opts$counts, opts$conflevel, opts$digits)))
                    .("McNemar's exact test, a binomial test on the discordant pairs")
                else
                    .("McNemar's test without continuity correction")
            }
            else if (identical(opts$typestatistics, "bayes"))
                .('a Bayesian contingency table analysis')
            else if (isTRUE(opts$resultssubtitle) &&
                     !is.null(private$.exactSubtitle(self$data, opts$dep, opts$group,
                                                    opts$counts, opts$conflevel, opts$digits)))
                .("Fisher's exact test for the sparse two-way chart")
            else .("Pearson's chi-squared test")
            if (!is.null(opts$grvar) && !isTRUE(opts$paired) &&
                !identical(opts$typestatistics, "bayes"))
                method_name <- paste0(method_name, .("; split panels use Pearson's chi-squared test"))

            
            # Interpolate the {outcome}/{groups}/{method} placeholders with glue.
            # (paste() only honors sep/collapse, so named args were previously
            # treated as positional values and the placeholders never filled.)
            sample_description <- if (!is.null(self$options$group) && self$options$group != "") {
                glue::glue(.('We compared {outcome} distributions across {groups} using {method}.'),
                     outcome = htmltools::htmlEscape(self$options$dep),
                     groups = htmltools::htmlEscape(self$options$group),
                     method = method_name)
            } else {
                glue::glue(.('We analyzed the distribution of {outcome} using descriptive statistics.'),
                     outcome = htmltools::htmlEscape(self$options$dep))
            }
            
            glue::glue(
                "<h4>{report_title}</h4>
                <div style='background-color: rgba(138, 155, 172, 0.06); padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; color: inherit;'>
                <p><strong>{methods_title}:</strong></p>
                <p>{sample_description} {additional_details}</p>
                <p><strong>{results_title}:</strong></p>
                <p>{results_placeholder}</p>
                </div>
                <p><small>{note}</small></p>
                <hr>",
                report_title = .('Copy-Ready Report Template'),
                methods_title = .('Methods'),
                results_title = .('Results'),
                additional_details = .('All analyses were performed using jamovi statistical software. Specify your prespecified significance threshold when reporting frequentist tests.'),
                results_placeholder = .('[Enter the test statistic, effect estimate, confidence interval and p-value or Bayes factor from the relevant chart.]'),
                note = .('Copy the text above and modify as needed for your manuscript or report.')
            )
        },
        
        # Helper Methods for Validation ----
        
        .validateVariables = function() {
            dep <- self$options$dep
            group <- self$options$group
            grvar <- self$options$grvar
            
            # Check if required variables exist
            all_vars <- c(dep, group, grvar)
            all_vars <- all_vars[!is.null(all_vars) & all_vars != ""]
            
            missing_vars <- all_vars[!all_vars %in% names(self$data)]
            if (length(missing_vars) > 0) {
                jmvcore::reject(.('Variables not found in data: {vars}'),
                                vars = paste(missing_vars, collapse = ', '))
            }
            
            # Validate that variables are appropriate for pie charts (categorical)
            for (var in all_vars) {
                if (!is.null(var) && var != "") {
                    var_class <- class(self$data[[var]])
                    if (!any(c("factor", "character", "logical") %in% var_class)) {
                        # Try to convert numeric to factor if it has few unique values
                        if (is.numeric(self$data[[var]])) {
                            unique_vals <- length(unique(self$data[[var]][!is.na(self$data[[var]])]))
                            if (unique_vals > 10) {
                                jmvcore::reject(
                                    .('Variable "{var}" appears to be continuous ({count} unique values). Pie charts are for categorical data. Consider converting to groups first.'),
                                    var = var, count = unique_vals
                                )
                            }
                        }
                    }
                }
            }
            
            # Enhanced validation for statistical tests
            private$.validateStatisticalRequirements(dep, group)

            # CRITICAL FIX #2: Validate counts variable
            counts_var <- self$options$counts
            if (!is.null(counts_var) && counts_var != "") {
                counts_validation <- private$.validateCounts(self$data, counts_var)
                if (!counts_validation$valid) {
                    jmvcore::reject(counts_validation$message)
                }
            }

            return(TRUE)
        },
        
        .validateStatisticalRequirements = function(dep, group) {
            # Check minimum group sizes for statistical tests when group variable is present
            if (!is.null(group) && group != "" && group %in% names(self$data)) {
                group_sizes <- table(self$data[[group]], useNA = "no")

                if (any(group_sizes < 5)) {
                }

                if (length(group_sizes) < 2) {
                    jmvcore::reject(.('Grouping variable must have at least 2 categories for comparison.'))
                }
            }

            # Check dependent variable has sufficient variation
            if (!is.null(dep) && dep != "" && dep %in% names(self$data)) {
                dep_levels <- table(self$data[[dep]], useNA = "no")
                if (length(dep_levels) < 2) {
                    jmvcore::reject(
                        .('Variable "{var}" has insufficient variation (only {count} level). Need at least 2 categories for meaningful pie chart.'),
                        var = dep, count = length(dep_levels)
                    )
                }
            }
        },

        .validateCounts = function(data, counts_var) {
            # CRITICAL FIX #2: Validate counts variable for aggregated data

            # Check if variable exists
            if (!counts_var %in% names(data)) {
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('Counts variable "%s" not found in data. Available variables: %s'),
                        counts_var,
                        paste(names(data), collapse = ", ")
                    )
                ))
            }

            # Check if variable is numeric
            if (!is.numeric(data[[counts_var]])) {
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('Counts variable "%s" must be numeric. Found type: %s. The counts variable should contain frequency counts for aggregated/tabulated data.'),
                        counts_var,
                        class(data[[counts_var]])[1]
                    )
                ))
            }

            # Check for negative values
            if (any(data[[counts_var]] < 0, na.rm = TRUE)) {
                neg_count <- sum(data[[counts_var]] < 0, na.rm = TRUE)
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('Counts variable "%s" contains %d negative values. Frequency counts must be non-negative (>= 0).'),
                        counts_var,
                        neg_count
                    )
                ))
            }

            # Check if all values are NA
            if (all(is.na(data[[counts_var]]))) {
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('Counts variable "%s" contains only missing values (NA). Cannot compute statistics with no valid counts.'),
                        counts_var
                    )
                ))
            }

            # Check if total count is zero after removing NAs
            total_count <- sum(data[[counts_var]], na.rm = TRUE)
            if (total_count == 0) {
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('Counts variable "%s" sums to zero. Need at least one observation with positive count.'),
                        counts_var
                    )
                ))
            }

            # All validations passed
            return(list(valid = TRUE, message = .('Counts variable validated successfully.')))
        },

        .checkFisherNeeded = function(data, dep_var, group_var, counts_var = NULL) {
            # Memoize on the current data+option hash (set by .getCachedData, which
            # every plot calls before this). The decision is a pure function of
            # data/dep/group/counts, all captured by .data_hash, so recomputing the
            # chi-square assumption check once per plot render is wasteful.
            cache_key <- private$.data_hash
            if (!is.null(cache_key) &&
                identical(private$.fisherDecisionHash, cache_key) &&
                !is.null(private$.fisherDecision)) {
                return(private$.fisherDecision)
            }

            result <- private$.computeFisherNeeded(data, dep_var, group_var, counts_var)

            if (!is.null(cache_key)) {
                private$.fisherDecision <- result
                private$.fisherDecisionHash <- cache_key
            }

            result
        },

        .computeFisherNeeded = function(data, dep_var, group_var, counts_var = NULL) {
            # CRITICAL FIX #5: Check if Fisher's exact test should be used
            # Returns list with use_fisher, low_count_cells, total_cells, pct_low

            if (is.null(group_var) || group_var == "") {
                return(list(use_fisher = FALSE, low_count_cells = 0, total_cells = 0, pct_low = 0))
            }

            tryCatch({
                # Create contingency table (weighted if counts present)
                if (!is.null(counts_var) && counts_var != "" && counts_var %in% names(data)) {
                    formula_str <- paste0(jmvcore::composeTerm(counts_var),
                                          " ~ ", jmvcore::composeTerm(dep_var),
                                          " + ", jmvcore::composeTerm(group_var))
                    cont_table <- xtabs(jmvcore::asFormula(formula_str), data = data)
                } else {
                    cont_table <- table(data[[dep_var]], data[[group_var]])
                }

                # Chi-square test requires at least 2x2 table
                if (nrow(cont_table) < 2 || ncol(cont_table) < 2) {
                    return(list(use_fisher = FALSE, low_count_cells = 0, total_cells = 0, pct_low = 0))
                }

                # Calculate expected counts
                expected <- suppressWarnings(chisq.test(cont_table)$expected)

                # Count cells with expected count < 5
                low_count_cells <- sum(expected < 5)
                total_cells <- length(expected)
                pct_low <- 100 * low_count_cells / total_cells

                # Fisher's exact recommended when >20% of cells have expected count < 5
                # For 2x2 tables, use if ANY cell < 5
                use_fisher <- if (total_cells == 4) {  # 2x2 table
                    low_count_cells > 0
                } else {
                    pct_low > 20
                }

                return(list(
                    use_fisher = use_fisher,
                    low_count_cells = low_count_cells,
                    total_cells = total_cells,
                    pct_low = pct_low
                ))

            }, error = function(e) {
                return(list(use_fisher = FALSE, low_count_cells = 0, total_cells = 0, pct_low = 0))
            })
        },

        # McNemar's chi-square is an asymptotic test on the DISCORDANT pairs alone,
        # so its validity is governed by b + c, not by the table total - and the
        # plotting package additionally runs it WITHOUT the continuity correction.
        # The old guard only rejected a total below 10, so a table with n = 206 and
        # just 6 discordant pairs passed and reported p = 0.10, where the exact
        # binomial test (the exact counterpart of McNemar) gives p = 0.22.
        #
        # Returns the exact result when the asymptotic test should not be trusted,
        # and NULL otherwise (no grouping variable, not 2x2, no discordant pairs at
        # all, or enough of them).
        .pairedDiscordant = function(data, dep_var, group_var, counts_var = NULL,
                                     min_discordant = 25L) {
            if (is.null(group_var) || !nzchar(group_var))
                return(NULL)
            tryCatch({
                if (!is.null(counts_var) && nzchar(counts_var) && counts_var %in% names(data)) {
                    formula_str <- paste0(jmvcore::composeTerm(counts_var), " ~ ",
                                          jmvcore::composeTerm(dep_var), " + ",
                                          jmvcore::composeTerm(group_var))
                    tb <- xtabs(jmvcore::asFormula(formula_str), data = data)
                } else {
                    tb <- table(data[[dep_var]], data[[group_var]])
                }
                if (!identical(dim(tb), c(2L, 2L)))
                    return(NULL)

                b <- tb[1L, 2L]
                cc <- tb[2L, 1L]
                n_disc <- b + cc
                if (n_disc == 0 || n_disc >= min_discordant)
                    return(NULL)

                list(b = b, c = cc, n_disc = n_disc, n_total = sum(tb),
                     p_exact = stats::binom.test(b, n_disc, 0.5)$p.value)
            }, error = function(e) NULL)
        },

        # "p = < 0.001" reads badly; the operator belongs to the number. Returns a
        # ready-to-embed string, e.g. "p = 0.051" or "p < 0.001". `html` picks the
        # entity form for the HTML panels (a bare "<" is fine in HTML5 text when
        # followed by a space, but the entity is unambiguous).
        .fmtP = function(p, html = TRUE) {
            if (!is.finite(p)) return("p = NA")
            if (p < 0.001) paste0("p ", if (html) "&lt;" else "<", " 0.001")
            else paste0("p = ", formatC(p, format = "f", digits = 3))
        },

        # Build a replacement subtitle carrying Fisher's exact test.
        #
        # ggstatsplot has no exact-test option, so on a sparse 2x2 the chart
        # subtitle showed an uncorrected Pearson chi-square that is not valid at
        # those expected counts - and the Assumptions panel had to tell the reader
        # to ignore the number printed on the figure. A figure that contradicts its
        # own caption travels badly: the chart gets pasted into a slide deck without
        # the panel. So compute the exact test here and put it ON the plot.
        #
        # Returns a plotmath expression in ggstatsplot's own idiom, or NULL when
        # the exact test does not apply (not 2x2, adequate expected counts, paired
        # data - where McNemar is already correct - or a Bayesian analysis).
        .exactSubtitle = function(data, dep_var, group_var, counts_var = NULL,
                                  conf_level = 0.95, digits = 2L) {
            if (is.null(group_var) || !nzchar(group_var))
                return(NULL)
            opts <- private$.effectiveOptionsList()
            if (identical(opts$typestatistics, "bayes"))
                return(NULL)

            # Paired data: Fisher assumes independent samples and is NOT the
            # alternative here. The exact counterpart of McNemar is a binomial
            # test on the discordant pairs, so put THAT on the chart when the
            # asymptotic McNemar cannot be trusted.
            if (isTRUE(opts$paired)) {
                pd <- private$.pairedDiscordant(data, dep_var, group_var, counts_var)
                if (is.null(pd))
                    return(NULL)
                d <- max(0L, as.integer(digits))
                p_txt <- if (pd$p_exact < 0.001) "< 0.001"
                         else formatC(pd$p_exact, format = "f", digits = max(3L, d))
                return(parse(text = sprintf(
                    'list(italic("p")["exact"] == "%s", italic("n")["discordant"] == "%d", italic("n")["obs"] == "%d")',
                    p_txt, pd$n_disc, pd$n_total))[[1]])
            }

            tryCatch({
                if (!is.null(counts_var) && nzchar(counts_var) && counts_var %in% names(data)) {
                    formula_str <- paste0(jmvcore::composeTerm(counts_var), " ~ ",
                                          jmvcore::composeTerm(dep_var), " + ",
                                          jmvcore::composeTerm(group_var))
                    tb <- xtabs(jmvcore::asFormula(formula_str), data = data)
                } else {
                    tb <- table(data[[dep_var]], data[[group_var]])
                }
                if (!identical(dim(tb), c(2L, 2L)))
                    return(NULL)

                expected <- suppressWarnings(chisq.test(tb)$expected)
                if (!any(expected < 5))
                    return(NULL)

                ft <- stats::fisher.test(tb, conf.level = conf_level)
                d  <- max(0L, as.integer(digits))
                fmt <- function(x) formatC(x, format = "f", digits = d)
                p_txt <- if (ft$p.value < 0.001) "< 0.001"
                         else formatC(ft$p.value, format = "f", digits = max(3L, d))

                # Odds ratio can be 0 or Inf on a zero cell; omit it rather than
                # print an uninterpretable bound.
                or <- unname(ft$estimate)
                has_or <- is.finite(or) && all(is.finite(ft$conf.int))

                txt <- if (has_or)
                    sprintf('list(italic("p")["Fisher"] == "%s", widehat(italic("OR")) == "%s", CI["%g%%"] ~ "[" * "%s", "%s" * "]", italic("n")["obs"] == "%d")',
                            p_txt, fmt(or), conf_level * 100,
                            fmt(ft$conf.int[1]), fmt(ft$conf.int[2]), sum(tb))
                else
                    sprintf('list(italic("p")["Fisher"] == "%s", italic("n")["obs"] == "%d")',
                            p_txt, sum(tb))

                parse(text = txt)[[1]]
            }, error = function(e) NULL)
        },

        .validatePairedData = function(data, dep_var, group_var) {
            # CRITICAL FIX #3: Validate paired data for McNemar test
            # McNemar test requires exactly 2x2 contingency table

            if (is.null(group_var) || group_var == "") {
                return(list(
                    valid = FALSE,
                    message = .('McNemar test requires a grouping variable (e.g., Pre vs Post, Treatment A vs B). No grouping variable specified.')
                ))
            }

            # Create contingency table (use weighted if counts variable present)
            counts_var <- self$options$counts
            if (!is.null(counts_var) && counts_var != "" && counts_var %in% names(data)) {
                # Weighted contingency table
                formula_str <- paste0(jmvcore::composeTerm(counts_var),
                                      " ~ ", jmvcore::composeTerm(dep_var),
                                      " + ", jmvcore::composeTerm(group_var))
                cross_table <- xtabs(jmvcore::asFormula(formula_str), data = data)
            } else {
                # Unweighted contingency table
                cross_table <- table(data[[dep_var]], data[[group_var]])
            }

            # Check if table is exactly 2x2
            if (!all(dim(cross_table) == c(2, 2))) {
                return(list(
                    valid = FALSE,
                    message = sprintf(
                        .('McNemar test requires a 2\u00d72 contingency table. Your data has %d\u00d7%d levels (%s: %d levels, %s: %d levels). For paired outcomes with more than two categories, use an appropriate test of marginal homogeneity. Do not substitute an independent-samples test or dichotomize solely to obtain this test.'),
                        nrow(cross_table), ncol(cross_table),
                        dep_var, nrow(cross_table),
                        group_var, ncol(cross_table)
                    )
                ))
            }

            # Check minimum sample size (McNemar requires at least 10 paired observations)
            total_n <- sum(cross_table)
            if (total_n < 10) {
                return(list(
                    valid = FALSE,
                    # Do NOT point at "the nonparametric option" for an exact
                    # test - that option returns the same chi-square. And Fisher's
                    # exact test is the wrong suggestion for PAIRED data anyway:
                    # it assumes independent samples. The exact counterpart of
                    # McNemar is a binomial test on the discordant pairs.
                    message = sprintf(
                        .('McNemar test requires at least 10 paired observations for reliable results. Your data has %d paired observations. Collect more data, or run an exact binomial test on the discordant pairs - the exact counterpart of McNemar. Note that Fisher\'s exact test is not an alternative here: it assumes independent samples, not paired ones.'),
                        total_n
                    )
                ))
            }

            # Check for zero marginals (can cause computational issues)
            row_sums <- rowSums(cross_table)
            col_sums <- colSums(cross_table)

            if (any(row_sums == 0) || any(col_sums == 0)) {
                return(list(
                    valid = FALSE,
                    message = .('McNemar test requires non-zero marginal totals. Your contingency table has at least one row or column with zero observations. Check your data for complete coverage of all category combinations.')
                ))
            }

            # All validations passed
            return(list(
                valid = TRUE,
                message = sprintf(
                    .('Data structure validated for McNemar test: 2\u00d72 table with %d paired observations.'),
                    total_n
                )
            ))
        },

        .getCachedData = function() {
            # CRITICAL FIX #1: Include actual data content in hash (not just dimensions/names)
            # CRITICAL FIX: Defensive check for dep variable
            if (is.null(self$options$dep) || length(self$options$dep) == 0 ||
                (length(self$options$dep) == 1 && self$options$dep == "")) {
                jmvcore::reject(.('Dependent variable is required but not properly set'))
            }

            opts <- private$.effectiveOptionsList()

            # Build list of relevant columns for hash
            relevant_cols <- c(opts$dep)
            if (!is.null(opts$group) && length(opts$group) > 0 && opts$group != "") {
                relevant_cols <- c(relevant_cols, opts$group)
            }
            if (!is.null(opts$grvar) && length(opts$grvar) > 0 && opts$grvar != "") {
                relevant_cols <- c(relevant_cols, opts$grvar)
            }
            if (!is.null(opts$counts) && length(opts$counts) > 0 && opts$counts != "") {
                relevant_cols <- c(relevant_cols, opts$counts)
            }

            # Filter to columns that actually exist
            relevant_cols <- relevant_cols[relevant_cols %in% names(self$data)]

            # Additional safety check
            if (length(relevant_cols) == 0) {
                jmvcore::reject(.('No valid analysis variables found in dataset. Please check variable names.'))
            }

            # Hash actual data content (not just structure)
            data_content_hash <- if (length(relevant_cols) > 0) {
                digest::digest(
                    self$data[, relevant_cols, drop = FALSE],
                    algo = "md5"
                )
            } else {
                digest::digest(dim(self$data), algo = "md5")
            }

            # Create hash of current data and options state
            current_hash <- digest::digest(list(
                data_dim = dim(self$data),
                data_names = names(self$data),
                data_content = data_content_hash,  #  NOW INCLUDES ACTUAL DATA VALUES
                options = opts
            ), algo = "md5")

            # Return cached data if hash matches and validation passed
            if (!is.null(private$.processedData) &&
                !is.null(private$.data_hash) &&
                private$.data_hash == current_hash &&
                private$.validation_passed) {
                return(private$.processedData)
            }

            # Validate and prepare fresh data
            # Checkpoint before validation (statistical requirements checking)
            private$.checkpoint(flush = FALSE)
            private$.validateVariables()
            private$.processedData <- private$.prepareData()
            private$.data_hash <- current_hash
            private$.validation_passed <- TRUE

            return(private$.processedData)
        },

        # Optimized data preparation with caching
        .prepareData = function(force_refresh = FALSE) {
            # CRITICAL FIX: Defensive check for dep variable
            if (is.null(self$options$dep) || length(self$options$dep) == 0 ||
                (length(self$options$dep) == 1 && self$options$dep == "")) {
                jmvcore::reject(.('Dependent variable is required but not properly set'))
            }

            # Prepare data with progress feedback
            self$results$todo$setContent(
                glue::glue("<br>{msg}<br><hr>", msg = .('Processing data for pie chart analysis...'))
            )

            mydata <- self$data

            # Selective NA omission - only remove rows with NAs in relevant variables
            # Build list of relevant columns
            relevant_cols <- c(self$options$dep)
            if (!is.null(self$options$group) && length(self$options$group) > 0 && self$options$group != "") {
                relevant_cols <- c(relevant_cols, self$options$group)
            }
            if (!is.null(self$options$grvar) && length(self$options$grvar) > 0 && self$options$grvar != "") {
                relevant_cols <- c(relevant_cols, self$options$grvar)
            }
            if (!is.null(self$options$counts) && length(self$options$counts) > 0 && self$options$counts != "") {
                relevant_cols <- c(relevant_cols, self$options$counts)
            }

            # Safety check
            if (length(relevant_cols) == 0) {
                jmvcore::reject(.('No valid analysis variables specified'))
            }

            # Remove rows with NAs only in relevant columns
            n_before <- nrow(mydata)
            private$.checkpoint()
            # Keep data as data.frame even when only one relevant column is present
            mydata <- mydata[complete.cases(mydata[relevant_cols]), , drop = FALSE]
            n_after <- nrow(mydata)

            # Report dropped rows
            if (n_before > n_after) {
                n_dropped <- n_before - n_after
                pct_dropped <- round(100 * n_dropped / n_before, 1)
                self$results$todo$setContent(
                    glue::glue(
                        "<br> <b>{info_title}:</b> {n_dropped} {rows_msg} ({pct_dropped}%) {excluded_msg} {vars_msg}: {var_list}.<br><hr>",
                        info_title = .('Info'),
                        rows_msg = ngettext(n_dropped, 'row', 'rows'),
                        excluded_msg = .('excluded due to missing values in'),
                        vars_msg = .('analysis variables'),
                        var_list = htmltools::htmlEscape(paste(relevant_cols, collapse = ', '))
                    )
                )
            }

            if (nrow(mydata) == 0 || nrow(mydata) < 3) {
                jmvcore::reject(.('No complete data rows available after handling missing values. Please check your data for the selected variables.'))
            }

            return(mydata)
        },

        # Helper method to parse ratio string
        .parseRatio = function(ratio_string) {
            if (is.null(ratio_string) || ratio_string == "") return(NULL)

            tryCatch({
                ratios <- as.numeric(strsplit(ratio_string, ",")[[1]])

                # ERROR: Non-numeric values
                if (any(is.na(ratios))) {
                    return(NULL)
                }

                # ERROR: Ratios don't sum to 1
                if (abs(sum(ratios) - 1) > 0.001) {
                    return(NULL)
                }

                # ERROR: Non-positive ratios
                if (any(ratios <= 0)) {
                    return(NULL)
                }

                return(ratios)
            }, error = function(e) {
                return(NULL)
            })
        },

        # Guard: expected proportions (ratio) must have one value per outcome
        # level. .parseRatio only validates numeric / sums-to-1 / positivity, not
        # length, so a mismatched vector (e.g. "0.5,0.5" for a 3-level outcome)
        # would otherwise be passed straight to ggpiestats(ratio=...) and error
        # inside the statsExpressions goodness-of-fit test. On mismatch, fall back
        # to NULL (equal theoretical proportions) and tell the user why.
        .applyRatioLengthGuard = function(ratio, data, dep) {
            if (is.null(ratio) || is.null(dep) || is.null(data[[dep]])) return(ratio)
            n_lev <- nlevels(droplevels(as.factor(data[[dep]])))
            if (length(ratio) != n_lev) {
                private$.addNotice(
                    "WARNING",
                    .('Expected proportions ignored'),
                    sprintf(
                        .('You supplied %d expected proportion(s), but the outcome variable has %d level(s). The number of expected proportions must match the number of outcome categories. Falling back to equal theoretical proportions.'),
                        length(ratio), n_lev
                    )
                )
                return(NULL)
            }
            ratio
        },

        # Optimized options preparation with caching
        .prepareOptions = function() {
            # Deliberately NOT cached. The previous `.processedOptions` cache had no
            # invalidation key (unlike .getCachedData(), which hashes data+options),
            # so once populated it returned the FIRST run's options for the life of
            # the R6 instance. jamovi reuses one instance across option changes - see
            # the note in .getPlotTheme() - so every renderer reading through here
            # silently ignored every later option change. Measured: after switching
            # to 5 digits and a Bayesian test, this still reported 2 and "parametric".
            # .effectiveOptionsList() is cheap and always current, so the cache bought
            # nothing and cost correctness.

            # Prepare options with progress feedback
            self$results$todo$setContent(
                glue::glue("<br>{msg}<br><hr>", msg = .('Preparing pie chart analysis options...'))
            )

            # Defensive validation: ensure dep is not zero-length
            if (is.null(self$options$dep) || length(self$options$dep) == 0 || (length(self$options$dep) == 1 && self$options$dep == "")) {
                jmvcore::reject(.('Dependent variable is not properly set'))
            }
            
            # Build effective options (includes preset and parsed ratio)
            private$.effectiveOptionsList()
        }



        # run ----
        ,
        # Every user-facing notice that depends on the data is raised from here,
        # called near the end of .run(). The plot functions cannot do it: notices
        # written during .plot() are discarded because jamovi has already composed
        # the results panel by then. That is why malformed "Expected proportions"
        # produced no message at all - the guard ran, in the wrong lifecycle phase.
        .emitRunNotices = function(prepared_data) {
            dep   <- self$options$dep
            group <- self$options$group

            # Expected proportions. .parseRatio silently returns NULL on bad
            # input (its four error messages were commented out during an
            # abandoned Notice-to-HTML migration), so re-derive the reason here.
            raw <- self$options$ratio
            if (!is.null(raw) && nzchar(trimws(raw))) {
                vals <- suppressWarnings(as.numeric(trimws(strsplit(raw, ",")[[1]])))
                ignored <- function(why)
                    private$.addNotice("WARNING", .('Expected proportions ignored'),
                        paste0(why, " ", .('Equal theoretical proportions were used instead.')))

                if (anyNA(vals))
                    ignored(sprintf(.('\'%s\' is not a list of numbers; expected comma-separated values such as "0.5,0.5".'), raw))
                else if (any(vals <= 0))
                    ignored(sprintf(.('\'%s\' contains a zero or negative proportion.'), raw))
                else if (abs(sum(vals) - 1) > 0.001)
                    ignored(sprintf(.('\'%s\' sums to %s, but expected proportions must sum to 1.'),
                                    raw, formatC(sum(vals), format = "f", digits = 3)))
                else
                    # Valid numbers: the remaining failure is a length mismatch,
                    # which .applyRatioLengthGuard reports.
                    invisible(private$.applyRatioLengthGuard(vals, prepared_data, dep))
            }

            # A pie chart encodes proportion as angle, which readers compare poorly
            # once the slices get thin; the existing guard only rejects a SINGLE
            # level, so a 90-level variable rendered 90 unreadable slivers without
            # comment. Warn rather than block - the numbers are still correct, and
            # the composition table remains usable.
            if (!is.null(dep) && dep %in% names(prepared_data)) {
                n_slices <- nlevels(droplevels(as.factor(prepared_data[[dep]])))
                if (n_slices > 7)
                    private$.addNotice("WARNING", .('Too many slices to read'),
                        sprintf(.('\'%s\' has %d categories, so the chart has %d slices. Pie charts become hard to read beyond about seven; consider collapsing rare categories, or use a bar chart, which compares lengths rather than angles.'),
                                dep, n_slices, n_slices))
            }

            # Split By draws one panel per level via grouped_ggpiestats, which
            # returns a combined patchwork - its per-panel subtitles cannot be
            # swapped the way plot2's single subtitle is. Where a panel's own 2x2
            # is too sparse for chi-square, give the exact p-value for that panel
            # here so the figure is not the only source.
            grvar <- self$options$grvar
            if (!is.null(grvar) && !is.null(group) && nzchar(grvar) &&
                grvar %in% names(prepared_data) && !isTRUE(self$options$paired) &&
                !identical(self$options$typestatistics, "bayes")) {

                lines <- character()
                for (lv in levels(droplevels(as.factor(prepared_data[[grvar]])))) {
                    sub_df <- prepared_data[!is.na(prepared_data[[grvar]]) &
                                            prepared_data[[grvar]] == lv, , drop = FALSE]
                    r <- tryCatch({
                        cv <- self$options$counts
                        tb <- if (!is.null(cv) && nzchar(cv)) {
                            f <- paste(jmvcore::composeTerm(cv), "~", jmvcore::composeTerm(dep),
                                       "+", jmvcore::composeTerm(group))
                            stats::xtabs(jmvcore::asFormula(f), data = sub_df)
                        } else table(sub_df[[dep]], sub_df[[group]])
                        if (!identical(dim(tb), c(2L, 2L))) NULL
                        else if (!any(suppressWarnings(chisq.test(tb)$expected) < 5)) NULL
                        else {
                            fp <- stats::fisher.test(tb)$p.value
                            sprintf("%s: %s", lv, private$.fmtP(fp, html = FALSE))
                        }
                    }, error = function(e) NULL)
                    if (!is.null(r)) lines <- c(lines, r)
                }

                if (length(lines))
                    private$.addNotice("WARNING", .('Split By panels: use these exact p-values'),
                        paste0(sprintf(.('In %d of the Split By panels the expected cell counts are too small for the chi-square shown on that panel. Fisher\'s exact test gives:'),
                                       length(lines)),
                               " ", paste(lines, collapse = "; "), "."))
            }

            # paired disables the single-variable chart; say so where it is seen.
            if (isTRUE(self$options$paired))
                private$.addNotice("WARNING", .('Single-variable pie chart not shown'),
                    .('The paired/repeated-measures option requires a two-way (grouped) comparison, so the single-variable pie chart cannot be drawn. Disable the "Paired" option to display this chart, or read the paired result from the grouped charts.'))

            # .validatePairedData ran only inside .plot2/.plot4, i.e. during
            # .plot(), so a paired request on a table that is not 2x2 drew
            # nothing and said nothing. Raise its verdict here as well.
            if (isTRUE(self$options$paired)) {
                v <- private$.validatePairedData(prepared_data, dep, group)
                if (!v$valid)
                    private$.addNotice("WARNING", .('Paired analysis not shown'), v$message)
            }

            # McNemar's validity rests on the discordant pairs, not the table total,
            # so a large study with few disagreements still gets an unreliable test.
            if (isTRUE(self$options$paired)) {
                pd <- private$.pairedDiscordant(prepared_data, dep, group, self$options$counts)
                if (!is.null(pd))
                    private$.addNotice("STRONG_WARNING", .('Too few discordant pairs for McNemar'),
                        sprintf(.('Only %d of the %d pairs disagree. McNemar\'s chi-square is an asymptotic test on the discordant pairs alone and is anti-conservative below about 25 of them, and the plotting package computes it without a continuity correction. The exact binomial test on the discordant pairs gives %s. %s'),
                                pd$n_disc, pd$n_total, private$.fmtP(pd$p_exact, html = FALSE),
                                if (isTRUE(self$options$resultssubtitle))
                                    .('The chart subtitle reports that exact value.')
                                else
                                    .('Enable "Statistical results" to show that exact value on the chart.')))
            }

            # A variable crossed with itself yields a perfectly diagonal table, so
            # the association test is a tautology: every off-diagonal cell is 0 and
            # the p-value is ~0 by construction, not by any finding in the data.
            if (!is.null(group) && !is.null(dep) && identical(dep, group))
                private$.addNotice("STRONG_WARNING", .('Variable compared with itself'),
                    sprintf(.('\'%s\' is used as both the outcome and the grouping variable. The contingency table is then diagonal by construction, so the association test reports a near-zero p-value that reflects the setup rather than the data. Choose a different grouping variable.'),
                            dep))

            if (isTRUE(self$options$messages)) {
                opts <- private$.effectiveOptionsList()
                private$.addNotice("INFO", .("Analysis settings"),
                    sprintf(.("Effective test type: %s. Paired: %s. Confidence level: %.1f%%."),
                            opts$typestatistics, opts$paired, 100 * opts$conflevel))
            }
            private$.renderNotices()
        },

        .run = function() {

            # Reset notices at the top of every run so stale messages from a
            # previous state (e.g. a paired-validation failure the user has since
            # fixed) are cleared; .emitRunNotices() re-populates and re-renders
            # near the end of the run.
            private$.noticeList <- list()
            private$.renderNotices()

            # Generate clinical interpretation panels
            private$.generateClinicalPanels()

            # Initial Message ----
            # CRITICAL FIX: Check for zero-length character vectors
            if ( is.null(self$options$dep) ||
                 length(self$options$dep) == 0 ||
                 (length(self$options$dep) == 1 && self$options$dep == "") ) {

                # TODO ----
                todo <- glue::glue(
                "<br>{welcome}
                <br><br>
                {description}
                <br><br>
                {documentation}
                <br>
                {citation}
                <br><hr>",
                welcome = .('Welcome to ClinicoPath'),
                description = .('This tool will help you generate Pie Charts with statistical analysis.'),
                documentation = .('This function uses ggplot2 and ggstatsplot packages. See documentations <a href = \'https://www.indrapatil.com/ggstatsplot/reference/ggpiestats.html\' target=\'_blank\'>ggpiestats</a> and <a href = \'https://www.indrapatil.com/ggstatsplot/reference/grouped_ggpiestats.html\' target=\'_blank\'>grouped_ggpiestats</a>.'),
                citation = .('Please cite jamovi and the packages as given below.')
                )

                self$results$todo$setContent(todo)
                return()

            } else {
                
                # Enhanced data validation with better error messages and caching
                tryCatch({
                    # Basic data check
                    if (nrow(self$data) == 0) {
                        jmvcore::reject(.('Dataset is empty. Please ensure your data contains observations.'))
                    }
                    
            # Use cached data validation and preparation
            start_time <- Sys.time()
            # Checkpoint before data validation and preparation
            private$.checkpoint()
            prepared_data <- private$.getCachedData()
            prep_time <- round(difftime(Sys.time(), start_time, units = "secs"), 2)
                    
                    # Enhanced success message with timing and caching info
                    cache_status <- if (private$.validation_passed && !is.null(private$.processedData)) {
                        " (cached)"
                    } else {
                        " (fresh validation)"
                    }
                    
                    # Performance warnings
                    perf_warning <- ""
                    if (self$options$typestatistics == "bayes") {
                        perf_warning <- paste0("<br> <b>", .('Performance Note:'), "</b> ", .('Bayesian analysis is computationally intensive.'), "<br>")
                    }
                    
                    # Build status message
                    dep_info <- paste(.('Variable:'), htmltools::htmlEscape(self$options$dep))
                    group_info <- if (!is.null(self$options$group) && self$options$group != "") {
                        paste(",", .('grouped by'), htmltools::htmlEscape(self$options$group))
                    } else { "" }
                    split_info <- if (!is.null(self$options$grvar) && self$options$grvar != "") {
                        paste(",", .('split by'), htmltools::htmlEscape(self$options$grvar))
                    } else { "" }
                    
                    todo <- glue::glue(
                        "<br>{ready_msg} {dep_info}{group_info}{split_info}.<br>
                        <br>{data_msg}: {nrow(prepared_data)} {obs_msg}{cache_status}.<br>
                        <br>{method_msg}: {if (private$.effectiveOptionsList()$paired) 'McNemar' else tools::toTitleCase(private$.effectiveOptionsList()$typestatistics)} {analysis_msg}.<br>
                        {perf_warning}
                        {if(prep_time > 0.1) paste0('<br>', prep_time_msg, ': ', prep_time, ' ', seconds_msg, '.<br>') else ''}
                        <hr>",
                        ready_msg = .('Pie chart analysis ready'),
                        data_msg = .('Data prepared'),
                        obs_msg = .('observations'),
                        method_msg = .('Statistical method'),
                        analysis_msg = .('analysis'),
                        prep_time_msg = .('Preparation time'),
                        seconds_msg = .('seconds')
                    )
                    
                    self$results$todo$setContent(todo)

                    # Emit the data-dependent notices HERE, in .run(). They were
                    # previously raised from .plot1/.plot2/.plot4, i.e. during
                    # .plot(), where jamovi has already composed the results panel
                    # and discards them - so every ratio complaint was invisible.
                    private$.emitRunNotices(prepared_data)

                }, error = function(e) {
                    # Reset cache on error
                    private$.processedData <- NULL
                    private$.validation_passed <- FALSE
                    
                    # Enhanced error reporting with more context
                    error_context <- ""
                    if (grepl("continuous", e$message, ignore.case = TRUE)) {
                        error_context <- paste0("<br> <b>", .('Tip:'), "</b> ", .('Use Data > Transform to create categorical groups from continuous variables.'), "<br>")
                    } else if (grepl("minimum|group size", e$message, ignore.case = TRUE)) {
                        error_context <- paste0("<br> <b>", .('Tip:'), "</b> ", .('Consider combining small categories or collecting more data.'), "<br>")
                    } else if (grepl("variation|level", e$message, ignore.case = TRUE)) {
                        error_context <- paste0("<br> <b>", .('Tip:'), "</b> ", .('Ensure your variables have multiple categories for meaningful pie charts.'), "<br>")
                    }
                    
                    error_msg <- glue::glue(
                        "<br> <b>{error_title}:</b><br>
                        <br>{htmltools::htmlEscape(e$message)}<br>
                        {error_context}
                        <br><b>{troubleshoot_title}:</b><br>
                        \u2022 {check1}<br>
                        \u2022 {check2}<br>
                        \u2022 {check3}<br>
                        \u2022 {check4}<br><hr>",
                        error_title = .('Error in Pie Chart Analysis'),
                        troubleshoot_title = .('General Troubleshooting'),
                        check1 = .('Ensure dependent variable is categorical'),
                        check2 = .('Check that selected variables exist in your dataset'),
                        check3 = .('Verify sufficient sample sizes in each category (\u22655 recommended)'),
                        check4 = .('Confirm variables have adequate variation (\u22652 categories)')
                    )
                    self$results$todo$setContent(error_msg)
                    stop(e)
                })
                
                # Add checkpoint for user feedback
                private$.checkpoint()
            }
        }


        # the plot1 function ----


        ,
        .plot1 = function(image, ggtheme, theme, ...) {

            # The Bayesian contingency test samples its posterior, and a frequentist run with
            # the Bayes factor message draws one too: seed them and name the seed.
            withr::local_seed(self$options$seed)

            # Validation ----
            # CRITICAL FIX: Check for zero-length character vectors
            if ( is.null(self$options$dep) ||
                 length(self$options$dep) == 0 ||
                 (length(self$options$dep) == 1 && self$options$dep == "") )
                return()

            # Use cached data for performance with error handling
            tryCatch({
                mydata <- private$.getCachedData()
            }, error = function(e) {
                stop(glue::glue('Data preparation failed in plot1: {e$message}'))
            })

            tryCatch({
                options_data <- private$.prepareOptions()
            }, error = function(e) {
                stop(glue::glue('Options preparation failed in plot1: {e$message}'))
            })

            dep <- options_data$dep


            # ggpiestats ----
            # https://www.indrapatil.com/ggstatsplot/reference/ggpiestats.html



            # Get counts variable if specified
            counts_var <- if (!is.null(options_data$counts) && options_data$counts != "") {
                options_data$counts
            } else {
                NULL
            }

            # CRITICAL FIX #3: Validate paired data before McNemar test
            if (options_data$paired) {
                # plot1 has no grouping variable (y=NULL), so paired doesn't apply.
                # Explain the empty plot instead of silently returning nothing.
                private$.addNotice(
                    "WARNING",
                    .('Single-variable pie chart not shown'),
                    .('The paired/repeated-measures option requires a two-way (grouped) comparison, so the single-variable pie chart cannot be drawn. Disable the "Paired" option to display this chart, or use the grouped charts for the paired analysis.')
                )
                return()
            }

            # Guard: expected proportions must match the number of outcome levels.
            # Keep the result in a LOCAL (as .plot2/.plot4 do). Assigning NULL back
            # into options_data would delete the element, and a later `$ratio` read
            # would then partial-match a sibling key instead of returning NULL.
            ratio_vec <- private$.applyRatioLengthGuard(options_data[["ratio"]], mydata, dep)

            # Checkpoint before expensive statistical computation
            private$.checkpoint()

            plot1 <-
                ggstatsplot::ggpiestats(
                    data = mydata,
                    x = !!rlang::sym(dep),
                    y = NULL,
                    counts = counts_var,
                    ratio = ratio_vec,
                    paired = FALSE,  # Always FALSE for single variable
                    type = options_data$typestatistics,
                    label = options_data$label,
                    label.args = list(alpha = 1, fill = "white"),
                    bf.message = options_data$bfmessage,
                    title = NULL,
                    subtitle = NULL,
                    caption = NULL,
                    conf.level = options_data$conflevel,
                    legend.title = NULL,
                    digits = options_data$digits,
                    proportion.test = options_data$proportiontest,
                    palette = "RColorBrewer::Dark2",
                    ggplot.component = NULL,
                    results.subtitle = options_data$resultssubtitle
                    )



            # Apply cached theme for better performance
            plot1 <- plot1 + private$.getPlotTheme()

            if (statsSeedMatters(self$options$typestatistics, "contingency") ||
                captionSeedMatters(self$options$typestatistics, "contingency", 2L, self$options$bfmessage))
                plot1 <- addSeedCaption(plot1, self, self$options$seed)

            # Print Plot1 ----

            print(plot1)
            TRUE

        }


        # the plot2 function ----


        , .plot2 = function(image, ggtheme, theme, ...) {

            # The Bayesian contingency test samples its posterior, and a frequentist run with
            # the Bayes factor message draws one too: seed them and name the seed.
            withr::local_seed(self$options$seed)

            # Validation ----
            # CRITICAL FIX: Check for zero-length character vectors
            if ( is.null(self$options$dep) || length(self$options$dep) == 0 ||
                 (length(self$options$dep) == 1 && self$options$dep == "") ||
                 is.null(self$options$group) || length(self$options$group) == 0 ||
                 (length(self$options$group) == 1 && self$options$group == "") )
                return()

            # Use cached data for performance with error handling
            tryCatch({
                mydata <- private$.getCachedData()
                options_data <- private$.prepareOptions()
            }, error = function(e) {
                stop(glue::glue('Plot preparation failed: {e$message}'))
            })
            
            dep <- options_data$dep
            group <- options_data$group



            # ggpiestats ----
            # https://www.indrapatil.com/ggstatsplot/reference/ggpiestats.html

            # Get counts variable if specified
            counts_var <- if (!is.null(options_data$counts) && options_data$counts != "") {
                options_data$counts
            } else {
                NULL
            }

            # Guard: expected proportions must match the number of outcome levels
            ratio_vec <- private$.applyRatioLengthGuard(options_data$ratio, mydata, dep)

            # CRITICAL FIX #3: Validate paired data before McNemar test
            if (options_data$paired) {
                validation <- private$.validatePairedData(mydata, dep, group)
                if (!validation$valid) {
                    # Explain the empty plot instead of silently returning nothing.
                    private$.addNotice(
                        "WARNING",
                        .('Paired analysis not shown'),
                        validation$message
                    )
                    return()
                }
            }

            # The old "auto-switch to Fisher's exact" rewrote the user's chosen type
            # to "nonparametric" on a sparse 2x2. It bought nothing: measured,
            # ggpiestats returns the identical uncorrected Pearson chi2(1) = 4.47,
            # p = 0.03 for parametric, nonparametric and robust alike, because
            # statsExpressions routes every frequentist type to chi-square. So the
            # switch silently changed what the user asked for, returned the same
            # number, and led the report to label it "Fisher's exact test" - a test
            # that never ran. The exact p-value is now given in the Assumptions panel.
            override_type <- options_data$typestatistics

            # Checkpoint before expensive statistical computation
            private$.checkpoint()

            # Additional checkpoint with timing for Bayesian analysis
            if (override_type == "bayes") {
                self$results$todo$setContent(
                    glue::glue("<br> {msg}<br><hr>", msg = .('Computing Bayesian analysis... This may take 30-60 seconds depending on data size.'))
                )
                private$.checkpoint(flush = TRUE)
            }

            # If the chi-square on the subtitle would be invalid, swap in Fisher's
            # exact test rather than printing a number the Assumptions panel then
            # has to disown.
            exact_sub <- if (isTRUE(options_data$resultssubtitle))
                private$.exactSubtitle(mydata, dep, group, counts_var,
                                       options_data$conflevel, options_data$digits) else NULL

            plot2 <-
                ggstatsplot::ggpiestats(
                    data = mydata,
                    x = !!rlang::sym(dep),
                    y = !!rlang::sym(group),
                    counts = counts_var,
                    ratio = ratio_vec,  # Use enhanced parsed ratio
                    paired = options_data$paired,
                    type = override_type,  # Use potentially overridden type
                    label = options_data$label,
                    label.args = list(alpha = 1, fill = "white"),
                    bf.message = options_data$bfmessage,
                    title = NULL,
                    subtitle = NULL,
                    caption = NULL,
                    conf.level = options_data$conflevel,
                    legend.title = NULL,
                    digits = options_data$digits,
                    proportion.test = options_data$proportiontest,
                    palette = "RColorBrewer::Dark2",
                    ggplot.component = NULL,
                    results.subtitle = options_data$resultssubtitle && is.null(exact_sub)
                )

            if (!is.null(exact_sub))
                plot2 <- plot2 + ggplot2::labs(subtitle = exact_sub)

            originaltheme <- options_data$originaltheme

            if (!originaltheme) {
                plot2 <- plot2 + ggtheme
            } else {
                plot2 <- plot2 + ggstatsplot::theme_ggstatsplot()
                # ggplot2::theme_bw()
            }


            if (statsSeedMatters(self$options$typestatistics, "contingency") ||
                captionSeedMatters(self$options$typestatistics, "contingency", 2L, self$options$bfmessage))
                plot2 <- addSeedCaption(plot2, self, self$options$seed)

            # Print Plot2 ----
            print(plot2)
            TRUE
        }


        # the plot4 function ----




        , .plot4 = function(image, ggtheme, theme, ...) {

            # The Bayesian contingency test samples its posterior, and a frequentist run with
            # the Bayes factor message draws one too: seed them and name the seed.
            withr::local_seed(self$options$seed)

            # Validation ----
            # CRITICAL FIX: Check for zero-length character vectors
            if ( is.null(self$options$dep) || length(self$options$dep) == 0 ||
                 (length(self$options$dep) == 1 && self$options$dep == "") ||
                 is.null(self$options$group) || length(self$options$group) == 0 ||
                 (length(self$options$group) == 1 && self$options$group == "") ||
                 is.null(self$options$grvar) || length(self$options$grvar) == 0 ||
                 (length(self$options$grvar) == 1 && self$options$grvar == "") )
                return()

            # Use cached data for performance with error handling
            tryCatch({
                mydata <- private$.getCachedData()
                options_data <- private$.prepareOptions()
            }, error = function(e) {
                stop(glue::glue('Grouped plot preparation failed: {e$message}'))
            })
            
            dep <- options_data$dep
            group <- options_data$group
            grvar <- options_data$grvar



            # grouped_ggpiestats ----
            # https://www.indrapatil.com/ggstatsplot/reference/grouped_ggpiestats.html

            if ( !is.null(grvar) ) {

                selected_theme <- private$.getPlotTheme()


                # Get counts variable if specified. Pass the column name as a
                # plain string (ggstatsplot captures `counts` with ensym, which
                # accepts a string) - matching plot1/plot2. Do NOT use `!!sym()`
                # here: rlang injection only works inside a data-masking call, so
                # `!!sym(x)` in this plain assignment parses as `!(!sym(x))` and
                # errors with "invalid argument type".
                counts_var <- if (!is.null(options_data$counts) && options_data$counts != "") {
                    options_data$counts
                } else {
                    NULL
                }

                # Guard: expected proportions must match the number of outcome levels
                ratio_vec <- private$.applyRatioLengthGuard(options_data$ratio, mydata, dep)

                # CRITICAL FIX #3: Validate paired data before McNemar test
                if (options_data$paired) {
                    validation <- private$.validatePairedData(mydata, dep, group)
                    if (!validation$valid) {
                        # Explain the empty plot instead of silently returning nothing.
                        private$.addNotice(
                            "WARNING",
                            .('Paired analysis not shown'),
                            validation$message
                        )
                        return()
                    }
                }

                # The old "auto-switch to Fisher's exact" rewrote the user's chosen type
                # to "nonparametric" on a sparse 2x2. It bought nothing: measured,
                # ggpiestats returns the identical uncorrected Pearson chi2(1) = 4.47,
                # p = 0.03 for parametric, nonparametric and robust alike, because
                # statsExpressions routes every frequentist type to chi-square. So the
                # switch silently changed what the user asked for, returned the same
                # number, and led the report to label it "Fisher's exact test" - a test
                # that never ran. The exact p-value is now given in the Assumptions panel.
                override_type <- options_data$typestatistics

                # Checkpoint before expensive grouped statistical computation
                private$.checkpoint()

                # Additional checkpoint with timing for Bayesian analysis
                if (override_type == "bayes") {
                    self$results$todo$setContent(
                        glue::glue("<br> {msg}<br><hr>", msg = .('Computing Bayesian analysis for grouped data... This may take 1-2 minutes depending on number of groups and data size.'))
                    )
                    private$.checkpoint(flush = TRUE)
                }

                plot4 <- ggstatsplot::grouped_ggpiestats(
                    data = mydata,
                    x = !!rlang::sym(dep),
                    y = !!rlang::sym(group),
                    counts = counts_var,
                    grouping.var = !!rlang::sym(grvar),
                    type = override_type,  # Use potentially overridden type
                    ratio = ratio_vec,  # Use enhanced parsed ratio
                    paired = options_data$paired,
                    label = options_data$label,
                    digits = options_data$digits,
                    conf.level = options_data$conflevel,
                    proportion.test = options_data$proportiontest,
                    bf.message = options_data$bfmessage,
                    results.subtitle = options_data$resultssubtitle,
                    ggtheme = selected_theme,
                    palette = "RColorBrewer::Dark2"
                )
            }


            if (statsSeedMatters(self$options$typestatistics, "contingency") ||
                captionSeedMatters(self$options$typestatistics, "contingency", 2L, self$options$bfmessage))
                plot4 <- addSeedCaption(plot4, self, self$options$seed)

            # Print Plot4 ----
            print(plot4)
            TRUE
        }

        , .plotDonut = function(image, ggtheme, theme, ...) {

            if (!self$options$addGGPubrDonut) return()
            # CRITICAL FIX: Check for zero-length character vectors
            if (is.null(self$options$dep) || length(self$options$dep) == 0 ||
                (length(self$options$dep) == 1 && self$options$dep == "")) return()

            # Use cached data
            tryCatch({
                mydata <- private$.getCachedData()
                options_data <- private$.prepareOptions()
            }, error = function(e) {
                stop(glue::glue('Donut plot preparation failed: {e$message}'))
            })
            
            dep <- options_data$dep
            group <- options_data$group
            
            # Prepare data for ggdonutchart (needs summary table)
            # Handle weighted counts if present
            if (!is.null(options_data$counts) && options_data$counts != "") {
                # Weighted aggregation
                formula_str <- paste0(jmvcore::composeTerm(options_data$counts),
                                      " ~ ", jmvcore::composeTerm(dep))
                if (!is.null(group) && group != "") {
                    formula_str <- paste0(formula_str, " + ", jmvcore::composeTerm(group))
                }

                # Use xtabs to sum counts
                agg_table <- xtabs(jmvcore::asFormula(formula_str), data = mydata)
                plot_data <- as.data.frame(agg_table, responseName = "count")
                # as.data.frame.table() runs make.names() on the dimension names,
                # so "Tumor Grade" came back as "Tumor.Grade" and ggdonutchart(label =
                # dep) could not find the column. Restore the raw names; xtabs keeps
                # the formula order (dep, then group).
                names(plot_data) <- c(dep, if (!is.null(group) && group != "") group, "count")
                
            } else {
                # Unweighted aggregation
                if (!is.null(group) && group != "") {
                    plot_data <- as.data.frame(table(mydata[[dep]], mydata[[group]]))
                    names(plot_data) <- c(dep, group, "count")
                } else {
                    plot_data <- as.data.frame(table(mydata[[dep]]))
                    names(plot_data) <- c(dep, "count")
                }
            }
            
            # Filter out zero counts to avoid plotting issues
            plot_data <- plot_data[plot_data$count > 0, ]
            
            # Create plot
            plot <- ggpubr::ggdonutchart(
                plot_data, 
                x = "count", 
                label = dep,
                fill = dep,
                color = "white",
                palette = self$options$ggpubrDonutPalette,
                lab.pos = "in", 
                lab.font = "white"
            )
            
            # Facet if grouped
            if (!is.null(group) && group != "") {
                plot <- plot + ggplot2::facet_wrap(jmvcore::asFormula(paste("~", jmvcore::composeTerm(group))))
            }
            
            print(plot)
            TRUE
        }

    ), # End of private list
    public = list(
        #' @description
        #' Generate R source code for Pie Chart Statistics analysis
        #' @return Character string with R syntax for reproducible analysis
        asSource = function() {
            # Build the argument list in option-declaration order.
            #
            # private$.asArgs() emitted variable names as BARE symbols, so a column
            # called `Tumor Grade ("high")` produced
            #     dep = Tumor Grade ("high")
            # which is not valid R - copying the syntax pane into a script raised
            # "unexpected symbol". Emit every variable-name option as a deparse()'d
            # string literal instead; deparse() escapes quotes and backslashes
            # correctly. Detecting the option by CLASS rather than by name means a
            # variable option added later is escaped automatically. Non-variable
            # options keep jmvcore's per-option sourcify so formatting matches the
            # rest of jamovi. Do NOT also call .asArgs() - emitting both duplicates
            # every variable in the generated call.
            args <- character(0)
            for (option in private$.options$options) {
                if (option$name == 'data')
                    next
                if (inherits(option, 'OptionVariable') || inherits(option, 'OptionVariables')) {
                    val <- option$value
                    if (!is.null(val) && length(val) > 0)
                        args <- c(args, paste0(option$name, ' = ',
                                               paste0(deparse(val), collapse = '')))
                } else {
                    as <- private$.sourcifyOption(option)
                    if (!identical(as, ''))
                        args <- c(args, as)
                }
            }

            # Get package name dynamically
            pkg_name <- utils::packageName()
            if (is.null(pkg_name)) pkg_name <- "ClinicoPath"  # fallback

            # Build complete function call
            paste0(pkg_name, '::jjpiestats(\n    data = data',
                   if (length(args)) paste0(',\n    ', paste(args, collapse = ',\n    ')) else '',
                   ')')
        }
    ) # End of public list
)
