#' @title Arc Diagram
#' @importFrom R6 R6Class
#' @importFrom jmvcore .
#' @importFrom igraph betweenness is_connected
#' @importFrom grDevices adjustcolor col2rgb rgb
#' @importFrom graphics par title legend
#' @return An \code{R6} class generator object for the \code{jjarcdiagramClass} backend; used internally by the jamovi analysis wrapper and not called directly.


jjarcdiagramClass <- if (requireNamespace('jmvcore')) R6::R6Class(
    "jjarcdiagramClass",
    inherit = jjarcdiagramBase,
    private = list(

        # Option overrides for clinical presets (jamovi options are read-only at runtime;
        # presets record overrides here and reads go through private$.option()).
        overrides = list(),
        .option = function(option) {
            if (option %in% names(private$overrides)) return(private$overrides[[option]])
            opt_obj <- self$options$option(option)
            if (!is.null(opt_obj)) return(opt_obj$value)
            return(NULL)
        },

        # Notice collection (single Preformatted plain-text output item; avoids the
        # jmvcore::Notice serialization error from self$results$insert(999, Notice)).
        .noticeList = list(),

        .addNotice = function(type, title, content) {
            entry <- list(type = type, title = title, content = content)
            # Idempotent by identity. Both .run() and .plot() call
            # .prepareNetworkData() on the SAME R6 instance, so the render pass
            # re-emits every network notice. Dropping an exact duplicate here is
            # what lets .prepareNetworkData() stop wiping the list -- and the wipe
            # was destroying notices raised OUTSIDE it (the summary-failure notice
            # in .run() is added after prepare, so the render pass deleted it and
            # the user never saw why the summary was missing).
            for (existing in private$.noticeList) {
                if (identical(existing, entry))
                    return(invisible(NULL))
            }
            private$.noticeList[[length(private$.noticeList) + 1]] <- entry
            private$.renderNotices()
        },

        .renderNotices = function() {
            if (length(private$.noticeList) == 0) {
                self$results$notices$setContent("")
                return()
            }
            blocks <- vapply(private$.noticeList, function(notice) {
                prefix <- switch(notice$type,
                    ERROR = "ERROR: ", STRONG_WARNING = "WARNING: ",
                    WARNING = "WARNING: ", "")
                paste0(prefix, notice$title, "\n", notice$content)
            }, character(1))
            self$results$notices$setContent(paste(blocks, collapse = "\n\n"))
        },

        # Init function
        .init = function() {
            # The Getting Started panel belongs to the UNCONFIGURED state. It used to
            # be written after the early return below, so it was empty exactly when a
            # user needed it and became permanent clutter once they no longer did.
            configured <- !is.null(self$options$source) && !is.null(self$options$target)
            self$results$instructions$setContent(
                if (configured) "" else private$.createInstructions())

            if (!configured)
                return()

            # Apply preset overrides BEFORE sizing: some presets (e.g. patient_network)
            # force a horizontal layout, and the canvas dimensions must reflect that
            # override. Reading .option("horizontal") before .configurePresets() sized a
            # forced-horizontal plot inside a portrait (600x800) canvas.
            private$.configurePresets()

            # Set plot size based on layout
            plot_width <- if (private$.option("horizontal")) 800 else 600
            plot_height <- if (private$.option("horizontal")) 600 else 800
            self$results$plot$setSize(plot_width, plot_height)

            # Set up assumptions panel conditionally
            private$.updateAssumptionsPanel()
        },

        # Run function
        .run = function() {

            private$.noticeList <- list()
            # This Html result persists on the R6 object across option changes.
            # Render the empty list immediately so a notice from the previous
            # run cannot survive when the new run has nothing to report.
            private$.renderNotices()

            # Check for required variables
            if (is.null(self$options$source) || is.null(self$options$target) || 
                length(self$options$source) == 0 || length(self$options$target) == 0) {
                todo <- paste(
                    .("<br>Welcome to ClinicoPath Arc Diagram"),
                    "<br><br>",
                    .("Create interactive network visualizations to explore relationships between entities."),
                    "<br><br>",
                    .("<b>Required:</b>"),
                    .("<li>Source Node: Starting point of connections</li>"),
                    .("<li>Target Node: Endpoint of connections</li>"),
                    "<br>",
                    .("<b>Optional:</b>"),
                    .("<li>Edge Weight: Strength of connections</li>"),
                    .("<li>Node Groups: Categories for color coding</li>"),
                    "<br><hr>",
                    sep = "\n"
                )
                self$results$todo$setContent(todo)
                # Clear report sentence when no variables selected
                self$results$reportSentence$setContent("")
                return()
            }


            if (is.null(self$data) || nrow(self$data) == 0)
                return()

            private$.checkpoint()
            private$.configurePresets()
            # Update assumptions panel when variables change
            private$.updateAssumptionsPanel()

            # Prepare and validate the network data
            private$.checkpoint()  # Before expensive network data processing
            network_data <- private$.prepareNetworkData()
            
            if (is.null(network_data)) {
                return()
            }
            
            # Generate network statistics
            if (self$options$showStats) {
                private$.checkpoint()  # Before statistical calculations
                private$.generateNetworkStats(network_data)
            }
            
            # Generate copy-ready report sentence with error handling (visible only when showSummary=TRUE)
            if (self$options$showSummary) {
                tryCatch({
                    private$.generateReportSentence(network_data)
                }, error = function(e) {
                    # jamovi does not surface base warning() output, so the reason the
                    # summary is missing goes to the notices item the user can see.
                    private$.addNotice(
                        "WARNING",
                        .("Summary could not be generated"),
                        paste0(conditionMessage(e),
                               ". The network plot and statistics above are unaffected."))
                    # Set fallback content
                    fallback_html <- paste(
                        .("<h3> Analysis Summary</h3>"),
                        "<div style='background-color: rgba(255, 202, 33, 0.23); padding: 10px; border-left: 4px solid #ffc107; color: inherit;'>",
                        .("<p><strong>Status:</strong> Network analysis completed successfully.</p>"),
                        .("<p><strong>Note:</strong> Detailed summary generation encountered an issue. Basic network visualization is available above.</p>"),
                        "</div>",
                        sep = "\n"
                    )
                    self$results$reportSentence$setContent(fallback_html)
                })
            }

            # Generate glossary if requested (visible only when showGlossary=TRUE)
            if (self$options$showGlossary) {
                private$.generateGlossary()
            }

            # Update todo with processing status
            todo <- paste(
                .("<br>Network Analysis Complete"),
                sprintf(.("<br>Nodes: %d"), network_data$n_nodes),
                sprintf(.("<br>Edges: %d"), network_data$n_edges),
                sprintf(.("<br>Density: %.3f"), network_data$density),
                "<br><hr>",
                sep = "\n"
            )
            self$results$todo$setContent(todo)
        },

        # Plot function
        .plot = function(image, ggtheme, theme, ...) {
            # Check for required variables - don't attempt plot without them
            if (is.null(self$options$source) || is.null(self$options$target)  || 
                length(self$options$source) == 0 || length(self$options$target) == 0)
                return()

            # Check for data availability
            if (is.null(self$data) || nrow(self$data) == 0)
                return()  # Simply return without error when no data

            # Prepare network data
            private$.checkpoint()  # Before network data preparation in plot
            network_data <- private$.prepareNetworkData()
            if (is.null(network_data)) return()

            # Create the plot with proper error handling
            private$.checkpoint()  # Before expensive plot creation
            tryCatch({
                private$.createArcPlot(network_data, theme)
            }, error = function(e) {
                private$.addNotice('ERROR', 'Plot Creation Error', paste('Error creating plot:', e$message))
                stop(e$message)
            })

            TRUE
        },

        # Helper method to escape variable names for safe igraph handling
        .escapeVar = function(x) {
            x_char <- as.character(x)
            safe <- make.names(x_char)
            safe <- gsub("\\.", "_", safe)
            # Enforce uniqueness AFTER the dot substitution. Running make.names(unique=TRUE)
            # first and gsub second let distinct originals ('HLA.A' and 'HLA_A') both collapse
            # to 'HLA_A', silently merging two entities into one node. Uniqueness must be the
            # final operation so any post-substitution collisions get re-suffixed.
            safe <- make.names(safe, unique = TRUE)
            return(safe)
        },

        # Map make.names-escaped node key(s) back to the original display label(s).
        # Falls back to the key itself when unmapped so nothing is dropped.
        .toDisplayLabel = function(escaped, network_data) {
            if (is.null(escaped) || length(escaped) == 0) return(escaped)
            lbl <- network_data$escaped_to_label[escaped]
            lbl[is.na(lbl)] <- escaped[is.na(lbl)]
            unname(lbl)
        },

        # Helper method to create user instructions
        .createInstructions = function() {
            # Get preset-specific guidance
            preset_guidance <- private$.getPresetGuidance()
            
            instructions <- paste(
                .("<h3> Arc Diagram Network Visualization</h3>"),
                preset_guidance,
                
                .("<h4> Getting Started:</h4>"),
                "<ul>",
                .("<li><strong>Source Node:</strong> Select the variable representing connection origins</li>"),
                .("<li><strong>Target Node:</strong> Select the variable representing connection destinations</li>"),
                .("<li><strong>Edge Weight:</strong> Optional numeric variable for connection strength</li>"),
                .("<li><strong>Node Groups:</strong> Optional categorical variable for color coding</li>"),
                "</ul>",
                
                .("<h4> Customization Options:</h4>"),
                "<ul>",
                .("<li><strong>Layout:</strong> Choose horizontal or vertical arrangement</li>"),
                .("<li><strong>Node Sizing:</strong> Fixed size or proportional to degree centrality</li>"),
                .("<li><strong>Node Sorting:</strong> Arrange by name, degree, or group</li>"),
                .("<li><strong>Arc Styling:</strong> Fixed width or proportional to weights</li>"),
                .("<li><strong>Color Schemes:</strong> Multiple palettes for different node groups</li>"),
                "</ul>",
                
                .("<h4> Network Metrics:</h4>"),
                "<ul>",
                .("<li><strong>Density:</strong> Measure of network connectivity</li>"),
                .("<li><strong>Centrality:</strong> Node importance in the network</li>"),
                .("<li><strong>Communities:</strong> Group structure detection</li>"),
                "</ul>",
                
                .("<p><em> Tip: Arc diagrams are ideal for visualizing hierarchical or sequential relationships with minimal visual clutter.</em></p>"),
                sep = "\n"
            )
            return(instructions)
        },
        
        # Helper method to get preset-specific guidance
        .getPresetGuidance = function() {
            preset <- self$options$analysisPreset
            
            guidance <- switch(preset,
                "gene_interaction" = paste(
                    "<div style='background-color: rgba(33, 159, 33, 0.1); padding: 10px; margin: 10px 0; border-left: 4px solid #4CAF50; color: inherit;'>",
                    .("<h4> Gene Interaction Network Analysis</h4>"),
                    .("<p><strong>Optimized for:</strong> Gene regulatory relationships, protein interactions, pathway analysis</p>"),
                    .("<p><strong>Recommendations:</strong> Use gene symbols as nodes, interaction scores as weights, pathways/functions as groups</p>"),
                    .("<p><strong>Suggested Settings:</strong> Sort by group, enable statistics, use degree-based node sizing</p>"),
                    "</div>",
                    sep = "\n"
                ),
                "patient_network" = paste(
                    "<div style='background-color: rgba(33, 152, 239, 0.13); padding: 10px; margin: 10px 0; border-left: 4px solid #2196F3; color: inherit;'>",
                    .("<h4> Patient Similarity Network Analysis</h4>"),
                    .("<p><strong>Optimized for:</strong> Patient similarity, treatment response, clinical outcomes</p>"),
                    .("<p><strong>Recommendations:</strong> Use patient IDs as nodes, similarity scores as weights, clinical subtypes as groups</p>"),
                    .("<p><strong>Suggested Settings:</strong> Sort by group, enable statistics, use horizontal layout</p>"),
                    "</div>",
                    sep = "\n"
                ),
                "pathway_network" = paste(
                    "<div style='background-color: rgba(255, 169, 33, 0.14); padding: 10px; margin: 10px 0; border-left: 4px solid #ff9800; color: inherit;'>",
                    .("<h4> Biological Pathway Network Analysis</h4>"),
                    .("<p><strong>Optimized for:</strong> Pathway interactions, biological processes, functional modules</p>"),
                    .("<p><strong>Recommendations:</strong> Use pathway names as nodes, interaction strength as weights, functional categories as groups</p>"),
                    .("<p><strong>Suggested Settings:</strong> Sort by degree, enable statistics, use weight-based arc widths</p>"),
                    "</div>",
                    sep = "\n"
                ),
                "comorbidity_network" = paste(
                    "<div style='background-color: rgba(230, 33, 99, 0.12); padding: 10px; margin: 10px 0; border-left: 4px solid #e91e63; color: inherit;'>",
                    .("<h4> Disease Co-occurrence Network Analysis</h4>"),
                    .("<p><strong>Optimized for:</strong> Disease associations, comorbidity patterns, epidemiological analysis</p>"),
                    .("<p><strong>Recommendations:</strong> Use disease codes/names as nodes, co-occurrence frequency as weights, disease categories as groups</p>"),
                    .("<p><strong>Suggested Settings:</strong> Sort by degree, enable statistics, use weight-based arc widths</p>"),
                    "</div>",
                    sep = "\n"
                ),
                "" # Default: no specific guidance
            )
            
            return(guidance)
        },
        
        # Helper method to update assumptions panel conditionally
        .updateAssumptionsPanel = function() {
            # The panel is hidden by .r.yaml `visible: (showAssumptions)`, so building
            # its HTML when the option is off is work nobody ever sees. glossary and
            # reportSentence are already gated this way in .run(); this matches them.
            if (!self$options$showAssumptions ||
                is.null(self$options$source) || is.null(self$options$target) ||
                length(self$options$source) == 0 || length(self$options$target) == 0) {
                self$results$assumptions$setContent("")
                return()
            }
            self$results$assumptions$setContent(private$.createAssumptions())
        },
        
        # Helper method to configure analysis presets
        .configurePresets = function() {
            preset <- self$options$analysisPreset

            # Rebuild from scratch every call. jamovi reuses this R6 instance across
            # option changes, so an override left from a previously selected preset
            # otherwise persists forever: switching back to "Custom Network" kept the
            # forced horizontal layout, and once gene_interaction had set plotTitle
            # the user's own title was ignored on every subsequent run.
            private$overrides <- list()

            # Apply preset-specific optimizations
            switch(preset,
                "gene_interaction" = {
                    if (is.null(private$.option("plotTitle")) || private$.option("plotTitle") == "") {
                        private$overrides[["plotTitle"]] <- "Gene Interaction Network"
                    }
                },
                "patient_network" = {
                    private$overrides[["horizontal"]] <- TRUE
                },
                "pathway_network" = {
                    private$overrides[["sortNodes"]] <- "degree"
                },
                "comorbidity_network" = {
                    private$overrides[["sortNodes"]] <- "degree"
                }
            )
        },
        
        # Helper method to prepare network data
        .prepareNetworkData = function() {
            # NOTE: deliberately does NOT reset the notice list. It used to, because
            # both .run() and .plot() call this method on the same R6 instance and the
            # render pass would otherwise duplicate every warning. That reset also
            # destroyed notices raised outside this method -- the summary-failure
            # notice added later in .run() vanished as soon as the plot drew.
            # Duplication is now prevented in .addNotice() instead, which ignores an
            # exact repeat. A fresh .run() still clears the list at its top.

            mydata <- self$data

            if (nrow(mydata) == 0) {
                private$.addNotice('ERROR', 'No Data Available', 'No data available. Please load a dataset and re-run the analysis.')
                return(NULL)
            }

            # Get variable names
            source_var <- self$options$source
            target_var <- self$options$target
            weight_var <- self$options$weight
            group_var <- self$options$group

            # Validate required columns exist
            if (!source_var %in% names(mydata) || !target_var %in% names(mydata)) {
                private$.addNotice('ERROR', 'Variables Not Found', 'Source or target variables not found in the dataset.')
                return(NULL)
            }

            # Build list of columns to check for NAs (only those actually used)
            required_cols <- c(source_var, target_var)
            if (!is.null(weight_var) && weight_var %in% names(mydata)) {
                required_cols <- c(required_cols, weight_var)
            }
            if (!is.null(group_var) && group_var %in% names(mydata)) {
                required_cols <- c(required_cols, group_var)
            }

            # SELECTIVE NA OMISSION: Only drop rows with NAs in required columns
            complete_rows <- complete.cases(mydata[required_cols])
            mydata_clean <- mydata[complete_rows, , drop = FALSE]

            if (nrow(mydata_clean) == 0) {
                private$.addNotice('ERROR', 'No Complete Rows', 'No complete rows after removing missing values. Check your data for NA values in source, target, weight, or group variables.')
                return(NULL)
            }

            # Dropped rows are dropped EDGES, and every number this analysis reports
            # - density, degree, betweenness, the "most central" node - is computed
            # on what survives. Previously only the all-rows-dropped case said
            # anything, so losing half a network to NA weights was silent.
            n_dropped <- nrow(mydata) - nrow(mydata_clean)
            if (n_dropped > 0) {
                private$.addNotice('WARNING', 'Rows Excluded',
                    sprintf(.('%d of %d rows (%.1f%%) were excluded because of missing values in %s. The network below, and every statistic computed from it, describes the remaining %d edges only.'),
                            n_dropped, nrow(mydata), 100 * n_dropped / nrow(mydata),
                            paste(required_cols, collapse = ", "), nrow(mydata_clean)))
            }

            # Build a SINGLE escape mapping across BOTH source and target columns so
            # that the same node value always maps to the same safe name and distinct
            # values never collide. make.names(unique = TRUE) must be applied to the
            # *combined unique* node set: applying it per-row (as before) appended
            # suffixes to repeated nodes (GeneA, GeneA_1, GeneA_2, ...), turning each
            # occurrence into a phantom distinct node and silently breaking degree,
            # edge aggregation, self-loop detection and group assignment.
            node_labels <- unique(c(as.character(mydata_clean[[source_var]]),
                                    as.character(mydata_clean[[target_var]])))
            node_map <- setNames(private$.escapeVar(node_labels), node_labels)

            # Create edge data frame with escaped names + original labels
            edge_df <- data.frame(
                source = unname(node_map[as.character(mydata_clean[[source_var]])]),
                target = unname(node_map[as.character(mydata_clean[[target_var]])]),
                stringsAsFactors = FALSE
            )

            # Add weights if specified
            if (!is.null(weight_var) && weight_var %in% names(mydata_clean)) {
                raw_weights <- jmvcore::toNumeric(mydata_clean[[weight_var]])
                if (!is.numeric(raw_weights) || any(!is.finite(raw_weights))) {
                    private$.addNotice("ERROR", "Invalid edge weights",
                        .("Weights must be finite numeric values on every row."))
                    return(NULL)
                }
                # Shortest-path centrality is undefined on negative edge lengths, and
                # igraph enforces that at the C level: it aborts the whole analysis with
                # "Weight vector must be positive. Invalid value / centrality/
                # betweenness.c:437" and no usable explanation. Negative weights are not
                # exotic here - this option is documented for correlations and
                # fold-changes, both routinely negative - so catch them with a message
                # that says what to do instead.
                #
                # This must run BEFORE edge aggregation. The same check used to sit after
                # the igraph object was built, where it was unreachable (the combined
                # guard above had already rejected negatives with a generic message that
                # dropped all of this guidance), and where the counts it reported would
                # have been of summed weights rather than of the user's own rows.
                if (any(raw_weights < 0)) {
                    private$.addNotice("ERROR", "Negative Edge Weights",
                        sprintf(.("%d of %d edge weights in '%s' are negative, and network centrality is undefined on negative edge lengths. Weights must be non-negative on every row. If these are correlations, use their absolute value, or rescale to a non-negative strength such as (1 + r) / 2. If they are log fold-changes, use the absolute value."),
                                sum(raw_weights < 0), length(raw_weights), weight_var))
                    return(NULL)
                }
                edge_df$weight <- raw_weights
            } else {
                edge_df$weight <- 1
            }

            if (nrow(edge_df) == 0) {
                private$.addNotice('ERROR', 'No Edge Data', 'No valid edge data available after processing. Ensure source and target variables have overlapping values.')
                return(NULL)
            }

            # Robust escaped -> original-label map built from the full node set
            # (node_map maps original -> escaped; invert it). Order-independent, so it stays
            # valid through self-loop removal and edge aggregation below. Display labels are
            # (re)derived from the FINAL edgelist after aggregation, never from this stale
            # pre-aggregation edge_df (which caused length/order mismatches with arcplot).
            escaped_to_label <- setNames(names(node_map), unname(node_map))
            has_weight_var <- !is.null(weight_var) && weight_var %in% names(mydata_clean)

            # Remove self-loops before aggregation
            self_loops <- sum(edge_df$source == edge_df$target)
            if (self_loops > 0) {
                edge_df <- edge_df[edge_df$source != edge_df$target, , drop = FALSE]
            }

            # ONE canonical edge key, computed once and used by both the aggregate
            # and the warn-only branch below. Previously each branch built its own:
            # the aggregate branch normalised A-B/B-A for undirected graphs, the
            # warn-only branch did not, so an undirected dataset carrying both
            # A->B and B->A rows got NO duplicate warning while igraph still
            # treated them as parallel edges inflating degree and strength.
            #
            # pmin/pmax is the vectorised equivalent of the row-wise
            # apply(..., 1, sort) this used to do -- verified to produce an
            # identical key -- without one R-level closure call and one sort()
            # per edge, which was the dominant cost at the documented
            # 50,000-edge ceiling.
            edge_key <- if (self$options$directed) {
                paste(edge_df$source, edge_df$target, sep = "~~~")
            } else {
                paste(pmin(edge_df$source, edge_df$target),
                      pmax(edge_df$source, edge_df$target), sep = "~~~")
            }
            duplicates <- sum(duplicated(edge_key))

            aggregation_warnings <- c()
            if (self$options$aggregateEdges) {
                if (duplicates > 0) {
                    aggregation_warnings <- c(aggregation_warnings,
                        sprintf(.("Note: %d duplicate edge(s) aggregated by summing weights"), duplicates))
                }

                # Aggregate by summing weights for duplicate edges
                if (!self$options$directed) {
                    # For undirected networks, treat A->B and B->A as the same edge
                    edge_df$edge_key <- edge_key
                    edge_agg <- aggregate(weight ~ edge_key, data = edge_df, FUN = sum)

                    # Split edge_key back into source and target
                    edge_split <- strsplit(edge_agg$edge_key, "~~~")
                    edge_df <- data.frame(
                        source = sapply(edge_split, `[`, 1),
                        target = sapply(edge_split, `[`, 2),
                        weight = edge_agg$weight,
                        stringsAsFactors = FALSE
                    )
                } else {
                    # For directed networks, only aggregate identical source->target pairs
                    edge_agg <- aggregate(weight ~ source + target, data = edge_df, FUN = sum)
                    edge_df <- edge_agg
                }
            } else {
                # Warn if there are duplicates but aggregation is disabled
                if (duplicates > 0) {
                    aggregation_warnings <- c(aggregation_warnings,
                        sprintf(.("Warning: %d duplicate edge(s) detected but not aggregated. Network metrics may be inflated. Enable 'Duplicate edge aggregation' for accurate statistics."), duplicates))
                }
            }

            # Create edge list matrix from aggregated data
            edgelist <- as.matrix(edge_df[, c("source", "target")])
            weights <- edge_df$weight

            # Calculate network metrics after aggregation.
            # Canonical node order MUST match arcplot AND igraph, both of which derive nodes
            # as unique(as.vector(t(edgelist))) (row-major, first appearance). The previous
            # column-major unique(c(col1, col2)) produced a DIFFERENT order, so per-node
            # aesthetics (labels, fills, sizes) and orderings were silently paired with the
            # wrong nodes. Recomputing display labels here (post self-loop removal AND
            # aggregation) also guarantees length(vlabels_display) == num_nodes, avoiding
            # arcplot's hard "Length of labels differs from number of nodes" stop.
            vlabels <- unique(as.vector(t(edgelist)))
            vlabels_display <- unname(escaped_to_label[vlabels])
            n_nodes <- length(vlabels)
            n_edges <- nrow(edgelist)

            # Display self-loops warning as Notice
            if (self_loops > 0) {
                private$.addNotice('WARNING', 'Self-Loops Removed', sprintf('%d self-loop(s) detected and removed from the network.', self_loops))
            }

            # Display aggregation warnings as Notices
            if (length(aggregation_warnings) > 0) {
                for (i in seq_along(aggregation_warnings)) {
                    # Remove the "Warning: " prefix from the message since the notice type already indicates it's a warning
                    msg <- sub("^Warning: ", "", aggregation_warnings[i])
                    private$.addNotice('WARNING', 'Edge Aggregation', msg)
                }
            }

            # Check for small/large networks with tiered warnings
            if (n_nodes < 3) {
                private$.addNotice('STRONG_WARNING', 'Trivial Network', 'Network has fewer than 3 nodes. Centrality measures are not meaningful for networks this small. Consider adding more entities or combining data.')
            } else if (n_nodes < 5) {
                private$.addNotice('STRONG_WARNING', 'Very Small Network', 'Network has fewer than 5 nodes. Centrality measures may be unreliable. Interpret with caution and consider qualitative assessment instead of quantitative metrics.')
            } else if (n_nodes < 10) {
                private$.addNotice('WARNING', 'Small Network', 'Small network (< 10 nodes). Centrality measures may show limited variation. Results should be interpreted cautiously.')
            }

            if (n_edges > 10000) {
                private$.addNotice('INFO', 'Large Network', 'Large network detected. Analysis may take longer.')
            }

            if (n_edges > 50000) {
                private$.addNotice('ERROR', 'Network Too Large', 'Network too large (> 50,000 edges after aggregation). Consider filtering or sampling data first.')
                stop('Network too large (> 50,000 edges after aggregation). Consider filtering or sampling data first.')
            }

            # NODE-LEVEL GROUP HANDLING: Build proper node-to-group mapping with conflict detection
            # Groups should be node attributes, not edge-level
            # escaped_to_label was already built (robustly, order-independently) above.

            node_groups <- NULL
            group_conflicts <- c()
            if (!is.null(group_var) && group_var %in% names(mydata_clean)) {
                # Create a mapping from ESCAPED node labels to groups
                node_groups <- setNames(rep(NA, length(vlabels)), vlabels)

                for (i in seq_along(vlabels)) {
                    node_escaped <- vlabels[i]
                    node_original <- escaped_to_label[node_escaped]
                    # Look for this node's ORIGINAL name in both source and target columns
                    source_match <- which(as.character(mydata_clean[[source_var]]) == node_original)
                    target_match <- which(as.character(mydata_clean[[target_var]]) == node_original)
                    all_matches <- c(source_match, target_match)

                    if (length(all_matches) > 0) {
                        # Get all unique groups for this node
                        groups_for_node <- unique(as.character(mydata_clean[[group_var]][all_matches]))
                        groups_for_node <- groups_for_node[!is.na(groups_for_node)]

                        if (length(groups_for_node) > 1) {
                            # CONFLICT DETECTED: Node appears with multiple groups
                            group_conflicts <- c(group_conflicts,
                                sprintf(.("Warning: Node '%s' has conflicting groups (%s). Using first occurrence: '%s'"),
                                    node_original, paste(groups_for_node, collapse = ", "), groups_for_node[1]))
                            node_groups[node_escaped] <- groups_for_node[1]
                        } else if (length(groups_for_node) == 1) {
                            node_groups[node_escaped] <- groups_for_node[1]
                        }
                    }
                }

                # Display group conflict warnings as Notices
                if (length(group_conflicts) > 0) {
                    for (i in seq_along(group_conflicts)) {
                        # Remove the "Warning: " prefix from the message
                        msg <- sub("^Warning: ", "", group_conflicts[i])
                        private$.addNotice('WARNING', 'Group Conflict', msg)
                    }
                }
            }

            # Create igraph object for analysis
            private$.checkpoint(flush = FALSE)  # Before igraph creation
            g <- tryCatch({
                igraph::graph_from_edgelist(edgelist, directed = self$options$directed)
            }, error = function(e) {
                private$.addNotice('ERROR', 'Invalid Edge Structure', 'Invalid edge structure detected. Check for duplicate or self-referencing edges.')
                return(NULL)
            })

            if (is.null(g)) return(NULL)

            # INJECT EDGE WEIGHTS into igraph object for centrality calculations
            igraph::E(g)$weight <- weights

            # Negative weights were already rejected before aggregation, above.
            if (!is.null(weight_var) && weight_var %in% names(mydata_clean)) {
                w_vals <- igraph::E(g)$weight
                # A zero DISTANCE means two nodes occupy the same point, which
                # igraph also rejects. A zero STRENGTH is meaningful (no connection)
                # and is handled below by mapping it to an infinite distance.
                if (identical(self$options$weightMode, "distance") &&
                    any(w_vals == 0, na.rm = TRUE)) {
                    private$.addNotice('ERROR', 'Zero Edge Distances',
                        sprintf(.('%d of %d edge weights in \'%s\' are zero. In Distance mode a weight is a path length, and a zero-length edge is undefined. Remove those edges, or switch Edge Weight Interpretation to Strength.'),
                                sum(w_vals == 0, na.rm = TRUE), length(w_vals), weight_var))
                    return(NULL)
                }
            }

            # INJECT NODE GROUPS into igraph object as vertex attribute
            if (!is.null(node_groups)) {
                igraph::V(g)$group <- node_groups[igraph::V(g)$name]
            }

            # Get vertex attributes with WEIGHTED degree if weights provided
            private$.checkpoint(flush = FALSE)  # Before degree calculation
            if (!is.null(weight_var) && weight_var %in% names(mydata_clean)) {
                # Use weighted degree (strength)
                degrees <- igraph::strength(g, weights = igraph::E(g)$weight)
            } else {
                # Use unweighted degree
                degrees <- igraph::degree(g)
            }

            # Calculate network density
            private$.checkpoint(flush = FALSE)  # Before density calculation
            g_simple <- igraph::simplify(g, remove.multiple = TRUE, remove.loops = TRUE)
            density <- igraph::edge_density(g_simple)
            # Density counts DISTINCT node pairs; n_edges counts rows in the edge
            # list. With parallel edges the two differ, and the statistics panel
            # reported both without saying so -- a reader who divided the printed
            # edge count by the possible pairs could not reproduce the printed
            # density.
            n_edges_distinct <- igraph::gsize(g_simple)

            # Domain-specific network density warnings
            if (density > 0.7) {
                private$.addNotice('WARNING', 'High Network Density', 'Network density is very high (>70%). Consider filtering weak connections or using different visualization methods for clearer interpretation.')
            }

            # A fragmented network invalidates the hub language used by BOTH the
            # statistics panel and the copy-ready summary. This used to be written
            # into the statistics HTML, so a user with "Network statistics" switched
            # off was told which entity was the "most highly connected hub" with no
            # hint that the graph was in pieces.
            if (n_nodes > 1 && !igraph::is_connected(g)) {
                private$.addNotice('WARNING', 'Disconnected Network',
                    .('This network contains isolated components. Betweenness is computed only within a component, so nodes unreachable from others are assigned zero centrality and the reported hub describes its own component rather than the whole network.'))
            }

            # Info for sparse networks (helpful guidance, not a problem)
            if (density < 0.05 && n_nodes > 20) {
                private$.addNotice('INFO', 'Sparse Network', 'Network is sparse (density <5%). Arc diagram is well-suited for visualizing sparse network structures.')
            }

            return(list(
                edgelist = edgelist,
                weights = weights,
                node_groups = node_groups,
                g = g,
                vlabels = vlabels,              # Escaped names for igraph
                vlabels_display = vlabels_display,  # Original for plotting
                escaped_to_label = escaped_to_label,  # Escaped -> original for stats/report
                has_weight_var = has_weight_var,      # TRUE only if a real weight var supplied
                degrees = degrees,
                n_nodes = n_nodes,
                n_edges = n_edges,
                n_edges_distinct = n_edges_distinct,
                degrees_unweighted = igraph::degree(g),
                density = density
            ))
        },
        
        # Helper method to create the arc plot
        .createArcPlot = function(network_data, theme = NULL) {
            # jamovi renders results in a light or a dark theme and hands the plot
            # the active palette. Everything here used to be hardcoded light --
            # black node borders, near-black arcs, arcplot's own "gray55" labels --
            # so on the dark theme the diagram was drawn in near-invisible ink.
            # theme$color[[1]] is the foreground the rest of the results use.
            fg <- tryCatch(theme$color[[1]], error = function(e) NULL)
            if (is.null(fg) || length(fg) != 1 || is.na(fg) || !nzchar(fg))
                fg <- par("fg")

            # Set up margins and plotting parameters
            oldpar <- par(mar = c(2, 2, 3, 2), fg = fg, col = fg,
                          col.axis = fg, col.lab = fg, col.main = fg)
            on.exit(par(oldpar))

            # Calculate node ordering
            private$.checkpoint(flush = FALSE)  # Before node calculations
            ord <- private$.calculateNodeOrdering(network_data)
            
            # Calculate node sizes
            node_sizes <- private$.calculateNodeSizes(network_data)
            
            # Calculate arc widths
            arc_widths <- private$.calculateArcWidths(network_data)
            
            # Get colors
            colors <- private$.getColors(network_data, fg)

            # Create the plot using the vendored arcplot (see R/jjarcdiagram-arcplot.R);
            # arcdiagram is GitHub-only and cannot be installed by jamovi, so it is bundled.
            private$.checkpoint(flush = FALSE)  # Before arcplot rendering
            arcplot(
                network_data$edgelist,
                ordering = ord,
                horizontal = private$.option("horizontal"),
                labels = network_data$vlabels_display,
                show.nodes = self$options$showNodes,
                col.nodes = colors$node_border,
                bg.nodes = colors$node_fill,
                cex.nodes = node_sizes,
                pch.nodes = 21,
                lwd.nodes = 1.5,
                col.arcs = colors$arc_color,
                lwd.arcs = arc_widths,
                cex.labels = self$options$labelSize,
                col.labels = fg
            )
            
            # Add title if specified
            if (private$.option("plotTitle") != "") {
                title(main = private$.option("plotTitle"), cex.main = 1.2)
            }
            
            # Add legend if groups are specified and color by group is enabled
            if (!is.null(network_data$node_groups) && self$options$colorByGroup && self$options$showLegend) {
                private$.addLegend(colors, fg)
            }
        },
        
        # Helper method to calculate node ordering
        .calculateNodeOrdering = function(network_data) {
            vlabels <- network_data$vlabels
            vlabels_display <- network_data$vlabels_display
            degrees <- network_data$degrees
            node_groups <- network_data$node_groups

            ord <- switch(private$.option("sortNodes"),
                "none" = seq_along(vlabels),
                "name" = order(vlabels_display, decreasing = self$options$sortDecreasing),
                "degree" = order(degrees, decreasing = self$options$sortDecreasing),
                "group" = {
                    if (!is.null(node_groups)) {
                        # node_groups is already a named vector mapping node labels to groups
                        if (all(is.na(node_groups))) {
                            seq_along(vlabels)
                        } else {
                            order(node_groups, decreasing = self$options$sortDecreasing, na.last = TRUE)
                        }
                    } else {
                        seq_along(vlabels)
                    }
                }
            )

            return(ord)
        },
        
        # Helper method to calculate node sizes
        .calculateNodeSizes = function(network_data) {
            if (self$options$nodeSize == "fixed") {
                node_sizes <- rep(self$options$nodeSizeValue, length(network_data$vlabels))
            } else {
                # Size by degree centrality
                node_sizes <- log(network_data$degrees + 1) * self$options$nodeSizeValue / 2 + 0.5
                node_sizes <- pmax(node_sizes, 0.5)  # Minimum size
            }
            return(node_sizes)
        },
        
        # Helper method to calculate arc widths
        .calculateArcWidths = function(network_data) {
            if (self$options$arcWidth == "fixed") {
                arc_widths <- rep(self$options$arcWidthValue, length(network_data$weights))
            } else {
                # Scale by weight
                if (all(network_data$weights == network_data$weights[1])) {
                    # All weights are the same
                    arc_widths <- rep(self$options$arcWidthValue, length(network_data$weights))
                } else {
                    arc_widths <- scales::rescale(network_data$weights, 
                                                to = c(0.3, self$options$arcWidthValue * 2))
                }
            }
            return(arc_widths)
        },
        
        # Helper method to get color schemes
        .getColors = function(network_data, fg = par("fg")) {
            node_groups <- network_data$node_groups  # Now using node-level groups
            vlabels <- network_data$vlabels

            if (!is.null(node_groups) && self$options$colorByGroup) {
                # Get unique groups (node-level)
                unique_groups <- unique(node_groups)
                unique_groups <- unique_groups[!is.na(unique_groups)]
                n_groups <- length(unique_groups)

                # Get color palette (color-blind safe)
                # Use viridis-based palettes for better accessibility
                if (n_groups <= 8) {
                    # viridis "turbo" palette - excellent for categorical data, CB-safe
                    group_colors <- viridisLite::turbo(n_groups, begin = 0.1, end = 0.9)
                } else if (n_groups <= 12) {
                    # Extend to 12 colors with viridis
                    group_colors <- viridisLite::viridis(n_groups, option = "H")
                } else if (n_groups <= 24) {
                    # Use HCL-based palette for many groups
                    group_colors <- grDevices::hcl.colors(n_groups, palette = "Dark 3")
                } else {
                    # For very large number of groups, use polychrome approach
                    group_colors <- grDevices::hcl.colors(n_groups, palette = "Zissou 1")
                }
                names(group_colors) <- unique_groups

                # Assign colors to vertices using node_groups directly
                # node_groups is already a named vector mapping node labels to groups
                node_fill <- group_colors[node_groups]
                node_fill[is.na(node_fill)] <- "lightgray"
                node_border <- fg

                # Arc colors: Support multiple coloring modes
                edgelist <- network_data$edgelist
                source_groups <- node_groups[edgelist[, 1]]
                target_groups <- node_groups[edgelist[, 2]]

                arc_color_mode <- self$options$arcColorMode

                if (arc_color_mode == "source") {
                    # Color arcs by SOURCE node's group
                    arc_colors <- group_colors[source_groups]
                    arc_colors[is.na(arc_colors)] <- "gray50"
                } else if (arc_color_mode == "target") {
                    # Color arcs by TARGET node's group
                    arc_colors <- group_colors[target_groups]
                    arc_colors[is.na(arc_colors)] <- "gray50"
                } else if (arc_color_mode == "gradient") {
                    # Gradient: Blend source and target colors
                    arc_colors <- character(nrow(edgelist))
                    for (i in seq_len(nrow(edgelist))) {
                        src_color <- group_colors[source_groups[i]]
                        tgt_color <- group_colors[target_groups[i]]

                        if (!is.na(src_color) && !is.na(tgt_color)) {
                            # Blend the two colors (simple average in RGB space)
                            src_rgb <- col2rgb(src_color) / 255
                            tgt_rgb <- col2rgb(tgt_color) / 255
                            blended_rgb <- (src_rgb + tgt_rgb) / 2
                            arc_colors[i] <- rgb(blended_rgb[1], blended_rgb[2], blended_rgb[3])
                        } else if (!is.na(src_color)) {
                            arc_colors[i] <- src_color
                        } else if (!is.na(tgt_color)) {
                            arc_colors[i] <- tgt_color
                        } else {
                            arc_colors[i] <- "gray50"
                        }
                    }
                } else {
                    # Default to source mode
                    arc_colors <- group_colors[source_groups]
                    arc_colors[is.na(arc_colors)] <- "gray50"
                }

                # Apply transparency to arc colors
                arc_color <- adjustcolor(arc_colors, alpha.f = self$options$arcTransparency)

            } else {
                # Default colors
                node_fill <- "lightblue"
                node_border <- fg
                arc_color <- adjustcolor(fg, alpha.f = self$options$arcTransparency)
                group_colors <- NULL
            }

            return(list(
                node_fill = node_fill,
                node_border = node_border,
                arc_color = arc_color,
                group_colors = group_colors
            ))
        },
        
        # Helper method to add legend
        .addLegend = function(colors, fg = par("fg")) {
            if (!is.null(colors$group_colors)) {
                legend("topright", 
                      legend = names(colors$group_colors),
                      fill = colors$group_colors,
                      cex = 0.8,
                      text.col = fg,
                      border = fg,
                      title.col = fg,
                      title = .("Groups"))
            }
        },
        
        # Helper method to generate network statistics
        .generateNetworkStats = function(network_data) {
            g <- network_data$g
            
            # Basic network metrics with clinical interpretations
            density_interp <- ifelse(network_data$density > 0.5, .("highly"), ifelse(network_data$density > 0.2, .("moderately"), .("sparsely")))
            connectivity_interp <- ifelse(igraph::is_connected(g), .("connected network"), .("network with isolated components"))
            
            stats_text <- paste(
                .("<h3> Network Statistics</h3>"),
                .("<h4>Basic Metrics:</h4>"),
                "<ul>",
                paste(.("<li><strong>Number of Nodes:</strong>"), network_data$n_nodes, "</li>"),
                if (!is.null(network_data$n_edges_distinct) &&
                    network_data$n_edges_distinct != network_data$n_edges) {
                    sprintf(.("<li><strong>Number of Edges:</strong> %d (%d distinct node pairs; density below is computed on the distinct pairs)</li>"),
                            network_data$n_edges, network_data$n_edges_distinct)
                } else {
                    sprintf(.("<li><strong>Number of Edges:</strong> %d</li>"), network_data$n_edges)
                },
                paste(.("<li><strong>Network Density:</strong>"), round(network_data$density, 4), sprintf(.("(%s connected)"), density_interp), "</li>"),
                paste(.("<li><strong>Is Connected:</strong>"), ifelse(igraph::is_connected(g), .("Yes"), .("No")), sprintf(.("(%s)"), connectivity_interp), "</li>"),
                "</ul>",
                sep = "\n"
            )
            
            # Add clinical interpretation summary
            clinical_summary <- paste(
                .("<h4> Clinical Interpretation:</h4>"),
                "<div style='background-color: rgba(33, 152, 255, 0.07); padding: 10px; margin: 10px 0; border-left: 4px solid #4CAF50; color: inherit;'>",
                # density_interp is an ADVERB ("moderately connected"); it cannot also
                # modify a noun, which produced "showing moderately connectivity".
                sprintf(.("<p><strong>Network Overview:</strong> This network contains %d entities with %d relationships, and is %s connected (density = %.3f).</p>"),
                        network_data$n_nodes, network_data$n_edges, density_interp, network_data$density),
                # Must use the SAME cut-points as density_interp above. They used to
                # differ (0.1/0.5 here against 0.2/0.5 there), so a density of 0.19
                # printed "is sparsely connected" and then "Moderate connectivity
                # suggests a balanced network" in the very next sentence.
                .("<p>Density is the proportion of distinct possible edges observed. It does not establish shared biological pathways, causation, or clinical importance.</p>"),
                "</div>",
                sep = "\n"
            )
            
            stats_text <- paste(stats_text, clinical_summary, sep = "\n")
            
            # Centrality measures with clinical context
            if (network_data$n_nodes > 1) {
                private$.checkpoint(flush = FALSE)  # Before expensive centrality calculations

                # WEIGHTED CENTRALITY: Handle weight semantics correctly.
                # Base this on whether a REAL weight variable was supplied, not on
                # E(g)$weight != 1: with aggregateEdges=TRUE and no weight variable, edge
                # multiplicity counts are summed into E(g)$weight (>1), which would falsely
                # flag the network as weighted and mislabel unweighted degree as "strength".
                has_weights <- isTRUE(network_data$has_weight_var)

                if (has_weights) {
                    # Determine weight interpretation
                    if (self$options$weightMode == "strength") {
                        # STRENGTH MODE: higher weight = stronger tie. igraph reads
                        # weights as DISTANCES, so a strength has to be converted.
                        #
                        # The conversion is the RECIPROCAL, 1/w - the standard for
                        # weighted betweenness and closeness (Opsahl, Agneessens &
                        # Skvoretz 2010; igraph's own documentation), and the only
                        # one under which a path's length is the sum of the inverse
                        # tie strengths along it.
                        #
                        # This previously used a linear reflection,
                        # max(w) - w + min(w), which is not an inversion and gives
                        # different answers. It charges a fixed toll per edge, so it
                        # favours short hop counts over strong ties. Measured on
                        # weights (10, 10, 7, 1): the reflection routes S->T through
                        # M and calls M the most central node; the reciprocal routes
                        # S->T directly and calls T the most central. It also broke
                        # outright whenever min(w) was 0, because the strongest edge
                        # then mapped to distance 0 and igraph rejects that.
                        #
                        # w = 0 means no connection, so 1/0 = Inf, which igraph
                        # correctly treats as unreachable. Negative weights are
                        # rejected earlier, before the graph is analysed.
                        inv_weights <- 1 / igraph::E(g)$weight

                        betweenness <- igraph::betweenness(g, weights = inv_weights)
                        degree_label <- .("weighted strength")
                    } else {
                        # DISTANCE MODE: Higher weights = longer paths (igraph default)
                        betweenness <- igraph::betweenness(g, weights = igraph::E(g)$weight)
                        degree_label <- .("weighted distance")
                    }
                } else {
                    # Unweighted network
                    betweenness <- igraph::betweenness(g)
                    degree_label <- .("connections")
                }

                # HANDLE DISCONNECTED GRAPHS: Filter out Inf/NA values
                betweenness[is.infinite(betweenness) | is.na(betweenness)] <- 0

                # A disconnected graph is reported once, as a notice raised in
                # .prepareNetworkData(), so that it reaches the user whether or not
                # this panel is switched on.

                # Get key nodes for clinical interpretation (after filtering invalid values)
                valid_degrees <- network_data$degrees[is.finite(network_data$degrees) & !is.na(network_data$degrees)]
                valid_betweenness <- betweenness[is.finite(betweenness) & !is.na(betweenness)]

                if (length(valid_degrees) > 0 && length(valid_betweenness) > 0) {
                    # Display ORIGINAL labels, not make.names-escaped keys ('Gene A' not 'Gene_A')
                    highest_degree_node <- private$.toDisplayLabel(names(which.max(network_data$degrees)), network_data)
                    highest_betweenness_node <- private$.toDisplayLabel(names(which.max(betweenness)), network_data)
                    max_degree <- max(network_data$degrees)
                    max_betweenness <- max(betweenness)
                } else {
                    # Fallback if no valid centrality values
                    stats_text <- paste(stats_text,
                        "<div style='background-color: rgba(216, 33, 50, 0.18); padding: 8px; margin: 8px 0; border-left: 4px solid #dc3545; color: inherit;'>",
                        .("<p><strong> Error:</strong> Could not calculate valid centrality measures. Network may be too disconnected or contain invalid data.</p>"),
                        "</div>",
                        sep = "\n"
                    )
                    self$results$networkStats$setContent(stats_text)
                    return()
                }

                stats_text <- paste(stats_text,
                    .("<h4>Centrality Measures:</h4>"),
                    "<ul>",
                    paste(.("<li><strong>Highest Degree:</strong>"), htmltools::htmlEscape(highest_degree_node), " (", round(max_degree, 2), " ", degree_label, ")</li>"),
                    if (max_betweenness > 0) {
                        paste(.("<li><strong>Highest Betweenness:</strong>"), htmltools::htmlEscape(highest_betweenness_node), " (", round(max_betweenness, 2), ")</li>")
                    } else {
                        .("<li><strong>Highest Betweenness:</strong> none (no node lies on a shortest path between two others)</li>")
                    },
                    "</ul>",
                    sep = "\n"
                )

                # Add centrality interpretation
                centrality_interp <- paste(
                    "<div style='background-color: rgba(255, 88, 88, 0.06); padding: 8px; margin: 8px 0; border-left: 4px solid #FF6B6B; color: inherit;'>",
                    if (has_weights && identical(self$options$weightMode, "distance")) {
                        sprintf(.("<p><strong>Key Players:</strong> '%s' has the largest summed edge distance (%.2f). Because weights are read as distances here, that marks the most peripheral entity rather than a stronger hub.</p>"),
                                htmltools::htmlEscape(highest_degree_node), max_degree)
                    } else {
                        sprintf(.("<p><strong>Key Players:</strong> '%s' has the largest summed edge metric (%.2f %s).</p>"),
                                htmltools::htmlEscape(highest_degree_node), max_degree, degree_label)
                    },
                    if (max_betweenness == 0) {
                        .("<p><strong>Bridging:</strong> Betweenness is zero for every node, so no entity acts as a bridge here: each pair of connected entities is already joined by its own shortest path.</p>")
                    } else if (highest_betweenness_node != highest_degree_node) {
                        sprintf(.("<p><strong> Bridge Entity:</strong> '%s' has the highest betweenness centrality, indicating it serves as an important bridge between different network regions.</p>"),
                                htmltools::htmlEscape(highest_betweenness_node))
                    } else {
                        .("<p><strong> Central Hub:</strong> The same entity serves as both the most connected node and the main bridge in the network.</p>")
                    },
                    "</div>",
                    sep = "\n"
                )

                stats_text <- paste(stats_text, centrality_interp, sep = "\n")
            }

            # NODE-LEVEL Group statistics if available
            if (!is.null(network_data$node_groups)) {
                # Count nodes per group (not edges)
                group_counts <- table(network_data$node_groups, useNA = "no")
                stats_text <- paste(stats_text,
                    .("<h4>Group Distribution (Node Counts):</h4>"),
                    "<ul>",
                    paste("<li><strong>", htmltools::htmlEscape(names(group_counts)), ":</strong>", group_counts, .(" nodes"), "</li>", collapse = ""),
                    "</ul>",
                    sep = "\n"
                )
            }
            
            self$results$networkStats$setContent(stats_text)
        },
        
        # Helper method to create assumptions and guidelines
        .createAssumptions = function() {
            assumptions <- paste(
                .("<h3> Network Analysis Assumptions & Guidelines</h3>"),
                "<div style='background-color: rgba(155, 155, 155, 0.06); padding: 15px; margin: 10px 0; border-radius: 5px; color: inherit;'>",

                .("<h4> Data Requirements:</h4>"),
                "<ul style='margin-left: 20px;'>",
                .("<li><strong>Data Format:</strong> Each row represents one relationship/connection</li>"),
                .("<li><strong>Node Variables:</strong> Source and Target must be categorical (factors)</li>"),
                .("<li><strong>Edge Weights:</strong> Optional numeric values for connection strength</li>"),
                .("<li><strong>Missing Data:</strong> Rows with missing source/target values are automatically excluded</li>"),
                "</ul>",

                .("<h4> Network Analysis Guidelines:</h4>"),
                "<ul style='margin-left: 20px;'>",
                .("<li><strong>Network Size:</strong> Optimal range is 10-1000 nodes for meaningful analysis</li>"),
                .("<li><strong>Self-loops:</strong> Connections from a node to itself are automatically detected and removed</li>"),
                .("<li><strong>Duplicate Edges:</strong> When 'Duplicate edge aggregation' is enabled (recommended), parallel edges are combined by summing weights for accurate density/centrality calculations</li>"),
                .("<li><strong>Edge Weight Mode:</strong> 'Strength' mode (default) treats higher weights as stronger connections, suitable for correlations/scores. 'Distance' mode treats higher weights as longer paths, suitable for costs/distances</li>"),
                .("<li><strong>Isolated Nodes:</strong> Entities with no connections appear only if referenced; unreachable nodes get zero centrality</li>"),
                "</ul>",

                .("<h4> Interpretation Notes:</h4>"),
                "<ul style='margin-left: 20px;'>",
                .("<li><strong>Network Density:</strong> 0-0.2 (sparse), 0.2-0.5 (moderate), >0.5 (dense). Density is computed on distinct node pairs, so it is always between 0 and 1</li>"),
                .("<li><strong>Degree Centrality:</strong> Number of direct connections (hub identification). For weighted networks, uses strength (sum of weights)</li>"),
                .("<li><strong>Betweenness Centrality:</strong> Importance as a bridge between network regions. Accounts for weight interpretation mode</li>"),
                                .("<li><strong>Connected Components:</strong> Isolated subnetworks may indicate distinct functional modules. Warnings issued for disconnected graphs</li>"),
                "</ul>",

                .("<h4> Common Pitfalls & Important Notes:</h4>"),
                "<ul style='margin-left: 20px;'>",
                .("<li><strong>Small Networks:</strong> Centrality measures less reliable with < 10 nodes (warning issued)</li>"),
                .("<li><strong>Duplicate Edges:</strong> If not aggregated, parallel edges inflate degree and strength. Density is unaffected because it is computed on distinct node pairs. Enable 'Duplicate edge aggregation' to fix the centrality measures</li>"),
                .("<li><strong>Weight Interpretation:</strong> Ensure 'Edge weight interpretation' matches your data. Most biological/clinical networks use 'Strength' mode</li>"),
                .("<li><strong>Group Conflicts:</strong> If a node appears with multiple group labels, warnings are issued and the first occurrence is used</li>"),
                .("<li><strong>Arc Coloring:</strong> Choose 'Source', 'Target', or 'Gradient' mode to control how arcs are colored when grouping is enabled</li>"),
                .("<li><strong>Directed Networks:</strong> When 'Directed network' is enabled, statistics respect edge direction but the arc diagram visualization does NOT display arrows. This is a limitation of the arc plot style</li>"),
                .("<li><strong>Disconnected Graphs:</strong> Closeness/betweenness may be unreliable. Inf/NA values are auto-filtered and warnings are issued</li>"),
                .("<li><strong>Clinical Relevance:</strong> High connectivity doesn't always imply biological significance. Consider domain knowledge when interpreting results</li>"),
                "</ul>",

                "</div>",
                sep = "\n"
            )
            return(assumptions)
        },
        
        # Helper method to generate copy-ready report sentence
        .generateReportSentence = function(network_data) {
            # Get analysis type for context
            analysis_type <- switch(self$options$analysisPreset,
                "gene_interaction" = .("gene interaction"),
                "patient_network" = .("patient similarity"),
                "pathway_network" = .("biological pathway"),
                "comorbidity_network" = .("disease co-occurrence"),
                .("network")
            )
            
            # Generate density interpretation
            density_desc <- ifelse(network_data$density > 0.5, .("highly connected"), 
                                 ifelse(network_data$density > 0.2, .("moderately connected"), .("sparsely connected")))
            
            # Create the copy-ready sentence
            report_html <- paste(
                .("<h3> Copy-Ready Analysis Summary</h3>"),
                "<div style='background-color: rgba(33, 159, 33, 0.1); padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #4CAF50; color: inherit;'>",
                
                sprintf(.("<p><strong>Network Summary:</strong> Arc diagram analysis of a %s network revealed %d entities connected by %d relationships, with a network density of %.3f indicating %s structure.</p>"),
                        analysis_type, network_data$n_nodes, network_data$n_edges, network_data$density, density_desc),
                
                if (network_data$n_nodes > 1) {
                    # Get centrality information if available (map escaped key -> original label)
                    highest_degree_node <- private$.toDisplayLabel(names(which.max(network_data$degrees)), network_data)
                    max_degree <- max(network_data$degrees)
                    # Use appropriate label for weighted vs unweighted (real weight var only,
                    # not incidental aggregation multiplicity counts)
                    if (isTRUE(network_data$has_weight_var) &&
                        identical(self$options$weightMode, "distance")) {
                        # Under a distance reading, a node's summed edge weight is its
                        # total path length, so the LARGEST value marks the most
                        # PERIPHERAL entity. This block is explicitly offered for
                        # pasting into manuscripts, and it used to call that node "the
                        # most highly connected hub ... suggesting its central role" --
                        # the opposite of what the data say. Report the connection
                        # count, which is well defined however weights are read.
                        top_label <- private$.toDisplayLabel(
                            names(which.max(network_data$degrees_unweighted)), network_data)
                        sprintf(.("<p><strong>Key Findings:</strong> The entity '%s' has the most connections (%.0f). Edge weights were interpreted as distances, so they describe path length rather than tie strength and do not rank hubs; see the network statistics panel for betweenness-based centrality.</p>"),
                                htmltools::htmlEscape(top_label), max(network_data$degrees_unweighted))
                    } else if (isTRUE(network_data$has_weight_var)) {
                        sprintf(.("<p><strong>Key Findings:</strong> The entity '%s' emerged as the most highly connected hub with %.2f weighted connections, suggesting its central role in the network.</p>"),
                                htmltools::htmlEscape(highest_degree_node), max_degree)
                    } else {
                        sprintf(.("<p><strong>Key Findings:</strong> The entity '%s' emerged as the most highly connected hub with %.0f direct connections, suggesting its central role in the network.</p>"),
                                htmltools::htmlEscape(highest_degree_node), max_degree)
                    }
                } else {
                    ""
                },

                if (!is.null(network_data$node_groups)) {
                    # Count unique NODE groups (not edge groups)
                    group_count <- length(unique(network_data$node_groups[!is.na(network_data$node_groups)]))
                    sprintf(.("<p><strong>Grouping:</strong> %d nodes were categorized into %d distinct groups, with color-coding revealing potential functional clusters or classifications.</p>"),
                            sum(!is.na(network_data$node_groups)), group_count)
                } else {
                    ""
                },
                
                .("<p><em> Tip: Copy the text above for use in reports, presentations, or publications.</em></p>"),
                "</div>",
                sep = "\n"
            )
            
            self$results$reportSentence$setContent(report_html)
        },

        # Helper method to generate glossary panel
        .generateGlossary = function() {
            glossary_html <- paste(
                .("<h3> Network Analysis Glossary</h3>"),
                "<div style='background-color: rgba(155, 155, 155, 0.06); padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #2196F3; color: inherit;'>",

                "<dl style='margin: 0;'>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Node (Vertex)"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("An entity or element in the network (e.g., gene, patient, disease, protein). Nodes are the fundamental building blocks of networks, representing the items being studied."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Edge (Arc)"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("A connection or relationship between two nodes (e.g., regulatory link, similarity score, co-occurrence). In arc diagrams, edges are visualized as curved arcs connecting nodes."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Degree Centrality"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("Number of direct connections a node has. High-degree nodes are 'hubs' that interact with many other entities. <strong>Clinical interpretation:</strong> A gene with high degree might be a master regulator; a patient with high degree might share characteristics with many others."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Betweenness Centrality"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("Measures how often a node lies on shortest paths between other nodes. High betweenness indicates the node serves as a 'bridge' connecting different network regions. <strong>Clinical interpretation:</strong> Entities with high betweenness may be critical bottlenecks or gateways in biological pathways."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Closeness Centrality"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("Average distance from a node to all other nodes in the network. Higher closeness means the node can reach others more quickly. <strong>Note:</strong> May be infinite (Inf) for disconnected graphs."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Network Density"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("Proportion of actual connections vs. all possible connections (0-1 scale). <strong>Interpretation:</strong> 0-0.2 = sparse (selective relationships), 0.2-0.5 = moderate (balanced), >0.5 = dense (highly interconnected). Dense networks may indicate shared mechanisms or pathways."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Weighted Network"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("A network where edges have numerical values representing connection strength, correlation, distance, or other quantitative measures. Weights influence how centrality measures are calculated."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Directed vs. Undirected"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("<strong>Directed:</strong> Edges have direction (A\u2192B is different from B\u2192A), suitable for regulatory relationships or causal pathways. <strong>Undirected:</strong> Edges are bidirectional (A-B same as B-A), suitable for similarity or co-occurrence networks. <strong>Note:</strong> Arc diagrams do not display arrows even for directed networks."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Isolated Node"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("A node with degree = 0 (no connections). Isolated nodes appear in the diagram but have zero centrality measures. May indicate rare or independent entities."),
                "</dd>",

                "<dt style='font-weight: bold; margin-top: 10px;'>", .("Connected Component"), "</dt>",
                "<dd style='margin-left: 20px; margin-bottom: 8px;'>",
                .("A subgroup of nodes where every node can reach every other node in that subgroup. Disconnected networks have multiple separate components, which may represent distinct functional modules or pathways."),
                "</dd>",

                "</dl>",

                "<p style='margin-top: 15px; font-style: italic; opacity: 0.75;'>",
                .(" Tip: Use this glossary as a quick reference when interpreting network statistics and visualizations."),
                "</p>",

                "</div>",
                sep = "\n"
            )

            self$results$glossary$setContent(glossary_html)
        }
    )
)
